import { useCallback } from 'react'
import { useAuth } from '@/store/auth'
import { hasAnyPermission, hasPermission } from '@/utils/permission'
import type { PermissionCode } from '@/types/navigation'

export function usePermission() {
  const { user } = useAuth()
  const permissions = user?.permissions ?? []
  const can = useCallback((required?: PermissionCode | PermissionCode[]) => hasPermission(permissions, required), [permissions])
  const canAny = useCallback((required: PermissionCode[]) => hasAnyPermission(permissions, required), [permissions])
  return { permissions, can, canAny }
}
