import type { PropsWithChildren, ReactNode } from 'react'
import { usePermission } from '@/hooks/usePermission'
import type { PermissionCode } from '@/types/navigation'

interface PermissionProps extends PropsWithChildren {
  code?: PermissionCode | PermissionCode[]
  any?: boolean
  fallback?: ReactNode
}

/** 操作级权限：无权限默认不渲染，也可通过 fallback 展示禁用态。 */
export function Permission({ code, any = false, fallback = null, children }: PermissionProps) {
  const { can, canAny } = usePermission()
  const allowed = any ? canAny(Array.isArray(code) ? code : code ? [code] : []) : can(code)
  return allowed ? children : fallback
}
