import { useEffect, useMemo, useState } from 'react'
import { App as AntdApp, Avatar, Badge, Button, Dropdown, Input, Modal, Tag } from 'antd'
import {
  BellOutlined,
  DownOutlined,
  ExpandOutlined,
  LogoutOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  SearchOutlined,
  UserOutlined,
} from '@ant-design/icons'
import { useLocation, useNavigate } from 'react-router-dom'
import type { NavNode } from '@/types/navigation'
import { buildDomainEntries, buildMenuSearchIndex, getDomainOf, searchMenu } from '@/config/menu'
import { useAuth } from '@/store/auth'

interface HeaderBarProps {
  visibleTree: NavNode[]
  collapsed: boolean
  isMobile: boolean
  onToggle: () => void
}

export function HeaderBar({ visibleTree, collapsed, isMobile, onToggle }: HeaderBarProps) {
  const { user, logout } = useAuth()
  const { modal } = AntdApp.useApp()
  const navigate = useNavigate()
  const location = useLocation()
  const [searchOpen, setSearchOpen] = useState(false)
  const [keyword, setKeyword] = useState('')
  const domains = useMemo(() => buildDomainEntries(visibleTree), [visibleTree])
  const searchIndex = useMemo(() => buildMenuSearchIndex(visibleTree), [visibleTree])
  const results = useMemo(() => searchMenu(searchIndex, keyword), [searchIndex, keyword])
  const currentDomain = getDomainOf(location.pathname)

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setSearchOpen(true)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  const go = (path: string) => {
    navigate(path)
    setSearchOpen(false)
    setKeyword('')
  }

  const confirmLogout = () => {
    modal.confirm({
      title: '确认退出登录？',
      content: '退出后需要重新验证身份才能进入管理平台。',
      okText: '退出登录',
      cancelText: '取消',
      onOk: async () => {
        await logout()
        navigate('/login', { replace: true })
      },
    })
  }

  return (
    <div className="app-header__row">
      <div className="app-header__left">
        <Button
          type="text"
          className="header-icon-button"
          aria-label={collapsed ? '展开侧边栏' : '收起侧边栏'}
          icon={isMobile ? <MenuUnfoldOutlined /> : collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
          onClick={onToggle}
        />
        {!isMobile && <span className="app-header__divider" />}
        <Dropdown
          menu={{
            items: domains.map((domain) => ({
              key: domain.entryPath,
              icon: domain.icon,
              label: <span className="domain-menu-item">{domain.label}<small>{domain.leafCount} 项</small></span>,
            })),
            onClick: ({ key }) => navigate(key),
          }}
          trigger={['click']}
        >
          <Button type="text" className="domain-switcher">
            <span>{currentDomain?.key === 'dashboard' || !currentDomain ? '业务导航' : currentDomain.label}</span>
            <DownOutlined />
          </Button>
        </Dropdown>
      </div>

      <div className="app-header__actions">
        <button className="global-search-trigger" onClick={() => setSearchOpen(true)} aria-label="全局菜单搜索">
          <SearchOutlined />
          {!isMobile && <><span>搜索菜单与功能</span><kbd>Ctrl K</kbd></>}
        </button>
        {!isMobile && <Button type="text" className="header-icon-button desktop-only" icon={<ExpandOutlined />} title="全屏显示" onClick={() => {
          if (document.fullscreenElement) void document.exitFullscreen()
          else void document.documentElement.requestFullscreen()
        }} />}
        <Dropdown
          trigger={['click']}
          dropdownRender={() => (
            <div className="notification-panel">
              <div className="notification-panel__title">待办提醒 <Tag color="orange">3 项</Tag></div>
              <div className="notification-item"><i className="dot dot--orange" /><div><strong>访客预约待审核</strong><span>有 2 条新的访客预约申请</span></div></div>
              <div className="notification-item"><i className="dot dot--blue" /><div><strong>设备离线提醒</strong><span>一号食堂消费机连接异常</span></div></div>
              <div className="notification-item"><i className="dot dot--green" /><div><strong>数据同步完成</strong><span>今日考勤数据已完成同步</span></div></div>
            </div>
          )}
        >
          <Badge count={3} size="small" offset={[-3, 4]}>
            <Button type="text" className="header-icon-button" aria-label="待办通知" icon={<BellOutlined />} />
          </Badge>
        </Dropdown>
        <span className="app-header__divider app-header__divider--right" />
        <Dropdown
          menu={{
            items: [
              { key: 'profile', icon: <UserOutlined />, label: `${user?.roleName ?? '操作员'} · ${user?.deptName ?? ''}`, disabled: true },
              { type: 'divider' },
              { key: 'logout', icon: <LogoutOutlined />, label: '退出登录', danger: true },
            ],
            onClick: ({ key }) => { if (key === 'logout') confirmLogout() },
          }}
          trigger={['click']}
        >
          <button className="user-entry">
            <Avatar size={34} className="user-entry__avatar">{user?.displayName.slice(0, 1) ?? '用'}</Avatar>
            {!isMobile && <span className="user-entry__meta"><strong>{user?.displayName}</strong><small>{user?.roleName}</small></span>}
            <DownOutlined className="user-entry__arrow" />
          </button>
        </Dropdown>
      </div>

      <Modal
        open={searchOpen}
        onCancel={() => { setSearchOpen(false); setKeyword('') }}
        footer={null}
        closable={false}
        width={620}
        className="menu-search-modal"
        destroyOnClose
      >
        <Input
          autoFocus
          size="large"
          prefix={<SearchOutlined />}
          placeholder="输入页面名称、业务域或路径"
          value={keyword}
          onChange={(event) => setKeyword(event.target.value)}
        />
        <div className="menu-search-results">
          {keyword && results.length === 0 && <div className="menu-search-empty">没有找到相关功能，请换个关键词</div>}
          {!keyword && <div className="menu-search-empty">可搜索“人员档案”“消费流水”“角色管理”等功能</div>}
          {results.map((item) => (
            <button key={item.path} className="menu-search-result" onClick={() => go(item.path)}>
              <span><strong>{item.title}</strong><small>{item.trail}</small></span>
              <Tag>{item.domain}</Tag>
            </button>
          ))}
        </div>
        <div className="menu-search-footer">仅显示当前角色有权限访问的功能</div>
      </Modal>
    </div>
  )
}
