import { useEffect, useMemo, useState } from 'react'
import { Input, Menu } from 'antd'
import type { MenuProps } from 'antd'
import { SearchOutlined } from '@ant-design/icons'
import { useLocation, useNavigate } from 'react-router-dom'
import type { NavNode } from '@/types/navigation'
import { findNodeByPath, flattenMenu, getOpenKeys } from '@/config/menu'

interface SideMenuProps {
  nodes: NavNode[]
  collapsed?: boolean
  onNavigate?: () => void
}

function toMenuItems(nodes: NavNode[]): MenuProps['items'] {
  return nodes.map((node) => ({
    key: node.key,
    icon: node.icon,
    label: node.label,
    children: node.children ? toMenuItems(node.children) : undefined,
  }))
}

function filterByKeyword(nodes: NavNode[], keyword: string): NavNode[] {
  const value = keyword.trim().toLowerCase()
  if (!value) return nodes
  return nodes.reduce<NavNode[]>((result, node) => {
    if (node.children?.length) {
      const children = filterByKeyword(node.children, value)
      if (children.length) result.push({ ...node, children })
    } else if (`${node.label} ${node.path ?? ''}`.toLowerCase().includes(value)) {
      result.push(node)
    }
    return result
  }, [])
}

export function SideMenu({ nodes, collapsed = false, onNavigate }: SideMenuProps) {
  const location = useLocation()
  const navigate = useNavigate()
  const [keyword, setKeyword] = useState('')
  const [openKeys, setOpenKeys] = useState<string[]>(getOpenKeys(location.pathname))
  const filtered = useMemo(() => filterByKeyword(nodes, keyword), [nodes, keyword])
  const items = useMemo(() => toMenuItems(filtered), [filtered])
  const selectedKey = findNodeByPath(location.pathname)?.key

  useEffect(() => {
    setOpenKeys((current) => Array.from(new Set([...current, ...getOpenKeys(location.pathname)])))
  }, [location.pathname])

  useEffect(() => {
    if (collapsed) setKeyword('')
    if (keyword) {
      const keys: string[] = []
      const collect = (list: NavNode[]) => list.forEach((node) => {
        if (node.children?.length) { keys.push(node.key); collect(node.children) }
      })
      collect(filtered)
      setOpenKeys(keys)
    }
  }, [collapsed, keyword, filtered])

  const onClick: MenuProps['onClick'] = ({ key }) => {
    const node = flattenMenu(nodes).find((item) => item.key === key)
    if (node?.path) {
      navigate(node.path)
      setKeyword('')
      onNavigate?.()
    }
  }

  return (
    <div className="side-menu">
      {!collapsed && (
        <div className="side-menu__search">
          <Input
            allowClear
            size="small"
            prefix={<SearchOutlined />}
            placeholder="筛选当前菜单"
            value={keyword}
            onChange={(event) => setKeyword(event.target.value)}
          />
        </div>
      )}
      <Menu
        mode="inline"
        theme="dark"
        items={items}
        selectedKeys={selectedKey ? [selectedKey] : []}
        openKeys={collapsed ? undefined : openKeys}
        onOpenChange={(keys) => setOpenKeys(keys as string[])}
        inlineCollapsed={collapsed}
        onClick={onClick}
      />
      {items?.length === 0 && <div className="side-menu__empty">未找到匹配菜单</div>}
    </div>
  )
}
