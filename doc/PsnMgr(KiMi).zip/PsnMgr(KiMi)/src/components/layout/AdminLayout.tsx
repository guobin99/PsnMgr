import { useEffect, useMemo, useState } from 'react'
import { Breadcrumb, Drawer, Grid, Layout } from 'antd'
import { Link, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '@/store/auth'
import { useTabs } from '@/store/tabs'
import { filterMenuByPermission, findNodeByPath, getBreadcrumbs, navTree } from '@/config/menu'
import { readStorage, storageKeys, writeStorage } from '@/utils/storage'
import { Brand } from './Brand'
import { SideMenu } from './SideMenu'
import { HeaderBar } from './HeaderBar'
import { TabsBar } from './TabsBar'

const { Header, Sider, Content } = Layout

export default function AdminLayout() {
  const { user } = useAuth()
  const location = useLocation()
  const screens = Grid.useBreakpoint()
  const isMobile = !screens.lg
  const [collapsed, setCollapsed] = useState(() => readStorage(storageKeys.collapsed) === 'true')
  const [mobileOpen, setMobileOpen] = useState(false)
  const { openTab, setActivePath } = useTabs()
  const authorizedTree = useMemo(
    () => filterMenuByPermission(navTree, user?.permissions ?? []),
    [user?.permissions],
  )
  const breadcrumbs = getBreadcrumbs(location.pathname)

  useEffect(() => {
    if (findNodeByPath(location.pathname)) {
      openTab(location.pathname)
      setActivePath(location.pathname)
    }
  }, [location.pathname, openTab, setActivePath])

  useEffect(() => {
    if (!isMobile) setMobileOpen(false)
  }, [isMobile])

  const toggle = () => {
    if (isMobile) setMobileOpen(true)
    else setCollapsed((value) => {
      writeStorage(storageKeys.collapsed, String(!value))
      return !value
    })
  }

  return (
    <Layout className="app-shell">
      {!isMobile && (
        <Sider width={240} collapsedWidth={64} collapsed={collapsed} trigger={null} className="app-sider">
          <Brand collapsed={collapsed} />
          <SideMenu nodes={authorizedTree} collapsed={collapsed} />
        </Sider>
      )}
      <Drawer
        open={isMobile && mobileOpen}
        onClose={() => setMobileOpen(false)}
        placement="left"
        width={280}
        closable={false}
        className="mobile-nav-drawer"
        styles={{ body: { padding: 0 } }}
      >
        <Brand />
        <SideMenu nodes={authorizedTree} onNavigate={() => setMobileOpen(false)} />
      </Drawer>
      <Layout className="app-main">
        <Header className="app-header">
          <HeaderBar visibleTree={authorizedTree} collapsed={collapsed} isMobile={isMobile} onToggle={toggle} />
        </Header>
        <TabsBar />
        <Content className="app-content">
          <Breadcrumb
            className="app-breadcrumb"
            items={breadcrumbs.map((item, index) => ({
              title: item.path && index < breadcrumbs.length - 1 ? <Link to={item.path}>{item.label}</Link> : item.label,
            }))}
          />
          <div className="app-page" key={location.key}><Outlet /></div>
          <footer className="app-footer">人脸通 BS 一体化管理平台 · 与 CS 系统数据同源</footer>
        </Content>
      </Layout>
    </Layout>
  )
}

