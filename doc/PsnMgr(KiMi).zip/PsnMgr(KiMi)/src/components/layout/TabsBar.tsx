import { Dropdown, Tabs } from 'antd'
import { CloseOutlined, MoreOutlined, ReloadOutlined } from '@ant-design/icons'
import { useLocation, useNavigate } from 'react-router-dom'
import { useTabs } from '@/store/tabs'

export function TabsBar() {
  const { tabs, activePath, closeTab, closeOthers, closeAll } = useTabs()
  const navigate = useNavigate()
  const location = useLocation()

  const remove = (path: string) => {
    const fallback = closeTab(path)
    if (fallback) navigate(fallback)
  }

  return (
    <div className="app-tabs">
      <Tabs
        type="editable-card"
        hideAdd
        activeKey={activePath}
        items={tabs.map((tab) => ({
          key: tab.path,
          label: tab.title,
          closable: tab.closable,
          closeIcon: <CloseOutlined aria-label={`关闭${tab.title}`} />,
        }))}
        onChange={(path) => navigate(path)}
        onEdit={(key, action) => {
          if (action === 'remove' && typeof key === 'string') remove(key)
        }}
      />
      <Dropdown
        menu={{
          items: [
            { key: 'refresh', icon: <ReloadOutlined />, label: '刷新当前页' },
            { key: 'others', label: '关闭其他页签', disabled: activePath === '/dashboard' },
            { key: 'all', label: '关闭全部页签' },
          ],
          onClick: ({ key }) => {
            if (key === 'refresh') navigate(location.pathname, { replace: true, state: { refresh: Date.now() } })
            if (key === 'others') navigate(closeOthers(activePath))
            if (key === 'all') navigate(closeAll())
          },
        }}
      >
        <button className="tabs-more" aria-label="页签操作"><MoreOutlined /></button>
      </Dropdown>
    </div>
  )
}
