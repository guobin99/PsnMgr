import { ScanOutlined } from '@ant-design/icons'

export function Brand({ collapsed = false }: { collapsed?: boolean }) {
  return (
    <div className={`app-brand${collapsed ? ' app-brand--collapsed' : ''}`}>
      <div className="app-brand__mark"><ScanOutlined /></div>
      {!collapsed && (
        <div className="app-brand__text">
          <strong>人脸通</strong>
          <span>一体化管理平台</span>
        </div>
      )}
    </div>
  )
}
