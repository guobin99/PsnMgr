import type { PermissionCode } from '@/types/navigation'

/** 支持精确匹配、全局 * 及 card:* / card:person:* 等前缀通配。 */
export function matchesPermission(granted: PermissionCode, required: PermissionCode): boolean {
  if (granted === '*') return true
  if (granted === required) return true
  if (!granted.endsWith('*')) return false
  return required.startsWith(granted.slice(0, -1))
}

export function hasPermission(
  granted: PermissionCode[] | undefined,
  required?: PermissionCode | PermissionCode[],
): boolean {
  if (!required || (Array.isArray(required) && required.length === 0)) return true
  if (!granted || granted.length === 0) return false
  const requiredList = Array.isArray(required) ? required : [required]
  return requiredList.every((code) => granted.some((item) => matchesPermission(item, code)))
}

export function hasAnyPermission(
  granted: PermissionCode[] | undefined,
  required: PermissionCode[],
): boolean {
  if (required.length === 0) return true
  if (!granted) return false
  return required.some((code) => granted.some((item) => matchesPermission(item, code)))
}
