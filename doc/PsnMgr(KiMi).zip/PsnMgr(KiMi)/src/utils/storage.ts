const PREFIX = 'psnmgr.'

export const storageKeys = {
  token: `${PREFIX}auth.token`,
  user: `${PREFIX}auth.user`,
  collapsed: `${PREFIX}layout.collapsed`,
  loginUserName: `${PREFIX}login.userName`,
} as const

export function readStorage(key: string): string | null {
  try {
    return window.localStorage.getItem(key)
  } catch {
    return null
  }
}

export function readJson<T>(key: string): T | null {
  const value = readStorage(key)
  if (!value) return null
  try {
    return JSON.parse(value) as T
  } catch {
    removeStorage(key)
    return null
  }
}

export function writeStorage(key: string, value: string): void {
  try {
    window.localStorage.setItem(key, value)
  } catch {
    // 隐私模式或存储空间不足时保持内存态可用。
  }
}

export function writeJson<T>(key: string, value: T): void {
  writeStorage(key, JSON.stringify(value))
}

export function removeStorage(key: string): void {
  try {
    window.localStorage.removeItem(key)
  } catch {
    // 存储不可用时无需阻断退出流程。
  }
}
