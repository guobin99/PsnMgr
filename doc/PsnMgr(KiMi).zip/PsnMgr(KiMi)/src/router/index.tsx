import { lazy, Suspense } from 'react'
import type { ReactNode } from 'react'
import { Navigate, Route, Routes, useParams } from 'react-router-dom'
import { DASHBOARD_PATH, filterMenuByPermission, flattenLeaves, navTree, resolveDomainEntry } from '@/config/menu'
import { useAuth } from '@/store/auth'
import { PermissionGate, RequireAuth } from './guards'
import AdminLayout from '@/components/layout/AdminLayout'
import PageLoading from '@/pages/PageLoading'
import ForbiddenPage from '@/pages/ForbiddenPage'

const LoginPage = lazy(() => import('@/pages/LoginPage'))
const DashboardPage = lazy(() => import('@/pages/DashboardPage'))
const ModulePage = lazy(() => import('@/pages/ModulePage'))
const NotFoundPage = lazy(() => import('@/pages/NotFoundPage'))

function load(page: ReactNode) {
  return <Suspense fallback={<PageLoading />}>{page}</Suspense>
}

function DomainRedirect() {
  const { domainKey = '' } = useParams()
  const { user } = useAuth()
  const visibleTree = filterMenuByPermission(navTree, user?.permissions ?? [])
  return <Navigate to={resolveDomainEntry(domainKey, visibleTree)} replace />
}

export default function AppRoutes() {
  const leaves = flattenLeaves().filter((node) => node.path !== DASHBOARD_PATH)
  const domains = navTree.filter((node) => node.children?.length)
  return (
    <Routes>
      <Route path="/login" element={load(<LoginPage />)} />
      <Route path="/" element={<Navigate to={DASHBOARD_PATH} replace />} />
      <Route element={<RequireAuth><AdminLayout /></RequireAuth>}>
        <Route path={DASHBOARD_PATH} element={<PermissionGate permission="dashboard:view">{load(<DashboardPage />)}</PermissionGate>} />
        {domains.map((domain) => <Route key={domain.key} path={`/${domain.key}`} element={<DomainRedirect />} />)}
        {leaves.map((node) => (
          <Route
            key={node.path}
            path={node.path}
            element={<PermissionGate permission={node.permission}>{load(<ModulePage />)}</PermissionGate>}
          />
        ))}
        <Route path="/403" element={load(<ForbiddenPage />)} />
      </Route>
      <Route path="*" element={load(<NotFoundPage />)} />
    </Routes>
  )
}
