import type { PropsWithChildren } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '@/store/auth'
import { usePermission } from '@/hooks/usePermission'
import ForbiddenPage from '@/pages/ForbiddenPage'

export function RequireAuth({ children }: PropsWithChildren) {
  const { isAuthenticated } = useAuth()
  const location = useLocation()
  if (!isAuthenticated) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />
  return children
}

export function PermissionGate({ permission, children }: PropsWithChildren<{ permission?: string }>) {
  const { can } = usePermission()
  const location = useLocation()
  if (!can(permission)) return <ForbiddenPage required={permission} from={location.pathname} />
  return children
}
