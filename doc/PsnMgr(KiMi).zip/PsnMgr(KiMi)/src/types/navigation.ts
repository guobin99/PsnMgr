import type { ReactNode } from 'react'

export type PermissionCode = string

export interface NavNode {
  key: string
  label: string
  path?: string
  icon?: ReactNode
  permission?: PermissionCode
  description?: string
  children?: NavNode[]
}

export interface CrumbItem {
  key: string
  label: string
  path?: string
}

export interface DomainMeta {
  key: string
  label: string
  icon?: ReactNode
  description: string
  entryPath: string
  leafCount: number
}

export type ModuleKind = 'master' | 'record' | 'report' | 'setting'

export interface ModulePageMeta {
  path: string
  title: string
  domainKey: string
  domainLabel: string
  groupLabel: string
  description: string
  primaryAction: string
  permission: PermissionCode
  resource: string
  kind: ModuleKind
}

export interface TabItem {
  key: string
  path: string
  title: string
  domain: string
  closable: boolean
}

export interface SessionUser {
  userId: string
  userName: string
  displayName: string
  roleNo: string
  roleName: string
  deptName: string
  permissions: PermissionCode[]
  isDemo?: boolean
}

export interface LoginPayload {
  userName: string
  password: string
}

export interface LoginResult {
  token: string
  user: SessionUser
}

export interface MenuSearchItem {
  path: string
  title: string
  domain: string
  trail: string
  depth: number
}

export interface ApiResult<T> {
  code: number | string
  message?: string
  data: T
}
