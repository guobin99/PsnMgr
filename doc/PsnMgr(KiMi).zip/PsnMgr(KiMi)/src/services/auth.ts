import http, { RequestError } from './http'
import type { LoginPayload, LoginResult, SessionUser } from '@/types/navigation'
import { buildDemoUser, DEMO_PASSWORD, findDemoAccount, isDemoLoginEnabled, resolveDevelopmentPermissions } from '@/config/roles'

type UnknownRecord = Record<string, unknown>

function asRecord(value: unknown): UnknownRecord {
  return value && typeof value === 'object' ? value as UnknownRecord : {}
}

function pick(record: UnknownRecord, keys: string[]): unknown {
  for (const key of keys) {
    if (record[key] !== undefined && record[key] !== null) return record[key]
  }
  return undefined
}

function text(value: unknown, fallback = ''): string {
  return typeof value === 'string' || typeof value === 'number' ? String(value) : fallback
}

function normalizeSession(payload: unknown): LoginResult {
  const body = asRecord(payload)
  const token = text(pick(body, ['token', 'access_token', 'accessToken']))
  const source = asRecord(pick(body, ['user', 'st_userinfo', 'st_UserInfo', 'userInfo']))
  const userName = text(pick(source, ['userName', 'User_No', 'user_No']))
  if (!token || !userName) throw new RequestError('服务返回异常，请稍后重试', 'business')

  const rawPermissions = pick(source, ['permissions', 'Permissions', 'permissionCodes'])
  let permissions = Array.isArray(rawPermissions)
    ? rawPermissions.filter((item): item is string => typeof item === 'string')
    : []
  if (!permissions.length && isDemoLoginEnabled()) permissions = resolveDevelopmentPermissions(userName)
  const roleNo = text(pick(source, ['roleNo', 'Role_No', 'role_No']), 'UNKNOWN')
  const user: SessionUser = {
    userId: text(pick(source, ['userId', 'User_No', 'user_No']), userName),
    userName,
    displayName: text(pick(source, ['displayName', 'User_Name', 'user_Name']), userName),
    roleNo,
    roleName: text(pick(source, ['roleName', 'Role_Name', 'role_Name']), roleNo === 'UNKNOWN' ? '操作员' : roleNo),
    deptName: text(pick(source, ['deptName', 'Dept_Name', 'dept_Name']), '未分配部门'),
    permissions,
  }
  return { token, user }
}

export async function loginRequest(payload: LoginPayload): Promise<LoginResult> {
  try {
    const response = await http.post('/auth/login', {
      UserNo: payload.userName,
      Password: payload.password,
      userName: payload.userName,
      password: payload.password,
    })
    return normalizeSession(response.data)
  } catch (error) {
    const account = findDemoAccount(payload.userName)
    const canFallback = error instanceof RequestError
      && (error.kind === 'network' || (error.status ?? 0) >= 500)
      && isDemoLoginEnabled()
      && account
      && payload.password === DEMO_PASSWORD
    if (canFallback && account) {
      return {
        token: `demo-session-${account.userName}`,
        user: buildDemoUser(account),
      }
    }
    if (error instanceof RequestError && error.status === 401) {
      throw new RequestError('账号或密码错误，请重试', 'http', 401)
    }
    throw error
  }
}

export async function logoutRequest(): Promise<void> {
  await http.post('/auth/logout')
}
