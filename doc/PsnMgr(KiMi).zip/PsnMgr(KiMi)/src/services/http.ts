import axios, { AxiosError } from 'axios'
import { readStorage, storageKeys } from '@/utils/storage'

export const UNAUTHORIZED_EVENT = 'psnmgr:unauthorized'

export type RequestErrorKind = 'network' | 'http' | 'business'

export class RequestError extends Error {
  status?: number
  kind: RequestErrorKind

  constructor(message: string, kind: RequestErrorKind, status?: number) {
    super(message)
    this.name = 'RequestError'
    this.kind = kind
    this.status = status
  }
}

const successCodes = new Set([0, 200, '0', '200', 'SUCCESS', 'OK'])

const http = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  timeout: 20_000,
  headers: { 'Content-Type': 'application/json' },
})

http.interceptors.request.use((config) => {
  const token = readStorage(storageKeys.token)
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

http.interceptors.response.use(
  (response) => {
    const body = response.data
    if (body && typeof body === 'object' && 'code' in body && 'data' in body) {
      if (!successCodes.has(body.code)) {
        throw new RequestError(body.message || '业务处理失败', 'business')
      }
      response.data = body.data
    }
    return response
  },
  (error: AxiosError<{ message?: string }>) => {
    const status = error.response?.status
    const isAuthEntry = error.config?.url?.includes('/auth/login') || error.config?.url?.includes('/auth/logout')
    if (status === 401 && !isAuthEntry) window.dispatchEvent(new CustomEvent(UNAUTHORIZED_EVENT))
    if (!error.response) return Promise.reject(new RequestError('网络异常或服务不可用', 'network'))
    const message = status === 401
      ? '登录状态已失效，请重新登录'
      : status === 403
        ? '无权限访问该资源'
        : error.response.data?.message || `服务请求失败（${status}）`
    return Promise.reject(new RequestError(message, 'http', status))
  },
)

export default http
