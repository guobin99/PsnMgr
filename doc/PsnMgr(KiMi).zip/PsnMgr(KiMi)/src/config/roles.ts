import type { SessionUser } from '@/types/navigation'

export const DEMO_PASSWORD = '123456'

export interface RoleDefinition {
  roleNo: string
  roleName: string
  deptName: string
  permissions: string[]
  summary: string
}

export const DEMO_ROLES: RoleDefinition[] = [
  { roleNo: 'R_ADMIN', roleName: '系统管理员', deptName: '信息中心', permissions: ['*'], summary: '全部业务域与全部操作权限' },
  {
    roleNo: 'R_CASHIER', roleName: '卡务出纳', deptName: '财务处',
    permissions: ['dashboard:view', 'card:*', 'consume:record:*', 'consume:report:*', 'consume:summary:*', 'report:*', 'system:log:*'],
    summary: '卡务、消费流水与报表中心',
  },
  {
    roleNo: 'R_HR', roleName: '人事考勤', deptName: '人力资源部',
    permissions: ['dashboard:view', 'attendance:*', 'card:person:view', 'card:dept:view', 'card:face:view', 'card:report:roster', 'visitor:*', 'report:overview', 'report:attendance'],
    summary: '考勤、人员档案与访客管理',
  },
  {
    roleNo: 'R_SECURITY', roleName: '门禁安保', deptName: '保卫处',
    permissions: ['dashboard:view', 'access:*', 'visitor:*', 'card:person:view', 'card:face:view', 'report:overview', 'report:access'],
    summary: '门禁、访客与相关报表',
  },
  {
    roleNo: 'R_CANTEEN', roleName: '食堂消费', deptName: '后勤服务集团',
    permissions: ['dashboard:view', 'consume:*', 'meal:*', 'card:person:view', 'report:overview', 'report:consume', 'report:meal'],
    summary: '消费、订餐与相关报表',
  },
  {
    roleNo: 'R_VIEWER', roleName: '运营查看', deptName: '校务办公室',
    permissions: ['dashboard:view', 'report:*'],
    summary: '仅工作台与报表中心',
  },
]

export interface DemoAccount {
  userName: string
  displayName: string
  roleNo: string
}

export const DEMO_ACCOUNTS: DemoAccount[] = [
  { userName: 'admin', displayName: '系统管理员', roleNo: 'R_ADMIN' },
  { userName: 'cashier', displayName: '张明', roleNo: 'R_CASHIER' },
  { userName: 'hr', displayName: '李慧', roleNo: 'R_HR' },
  { userName: 'security', displayName: '王强', roleNo: 'R_SECURITY' },
  { userName: 'canteen', displayName: '赵磊', roleNo: 'R_CANTEEN' },
  { userName: 'viewer', displayName: '陈婷', roleNo: 'R_VIEWER' },
]

export function isDemoLoginEnabled(): boolean {
  return import.meta.env.DEV && import.meta.env.VITE_ENABLE_DEMO_LOGIN === 'true'
}

export function findDemoAccount(userName: string): DemoAccount | undefined {
  const value = userName.trim().toLowerCase()
  return DEMO_ACCOUNTS.find((account) => account.userName === value)
}

export function buildDemoUser(account: DemoAccount): SessionUser {
  const role = DEMO_ROLES.find((item) => item.roleNo === account.roleNo) ?? DEMO_ROLES[5]
  return {
    userId: `DEMO-${account.userName.toUpperCase()}`,
    userName: account.userName,
    displayName: account.displayName,
    roleNo: role.roleNo,
    roleName: role.roleName,
    deptName: role.deptName,
    permissions: [...role.permissions],
    isDemo: true,
  }
}

/** 仅开发环境为同名演示账号补齐权限，生产环境完全信任后端下发。 */
export function resolveDevelopmentPermissions(userName: string): string[] {
  const account = findDemoAccount(userName)
  const role = DEMO_ROLES.find((item) => item.roleNo === account?.roleNo)
  return role ? [...role.permissions] : []
}
