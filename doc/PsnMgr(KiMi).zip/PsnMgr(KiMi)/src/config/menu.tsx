import { DashboardOutlined } from '@ant-design/icons'
import type { CrumbItem, DomainMeta, MenuSearchItem, ModulePageMeta, NavNode, PermissionCode } from '@/types/navigation'
import { hasPermission } from '@/utils/permission'
import { cardDomain } from './menu/card'
import { consumeDomain } from './menu/consume'
import { attendanceDomain } from './menu/attendance'
import { accessDomain } from './menu/access'
import { mealDomain } from './menu/meal'
import { visitorDomain } from './menu/visitor'
import { utilityDomain } from './menu/utility'
import { reportDomain } from './menu/report'
import { systemDomain } from './menu/system'

export const DASHBOARD_PATH = '/dashboard'

export const dashboardNode: NavNode = {
  key: 'dashboard',
  label: '工作台',
  path: DASHBOARD_PATH,
  icon: <DashboardOutlined />,
  permission: 'dashboard:view',
  description: '经营概览、待办事项与常用功能入口',
}

/** 菜单、路由、面包屑、搜索与页签的唯一数据源。 */
export const navTree: NavNode[] = [
  dashboardNode,
  cardDomain,
  consumeDomain,
  attendanceDomain,
  accessDomain,
  mealDomain,
  visitorDomain,
  utilityDomain,
  reportDomain,
  systemDomain,
]

const leafIndex = new Map<string, NavNode>()
const trailIndex = new Map<string, NavNode[]>()

function indexNodes(nodes: NavNode[], trail: NavNode[]): void {
  nodes.forEach((node) => {
    const nextTrail = [...trail, node]
    if (node.children?.length) indexNodes(node.children, nextTrail)
    else if (node.path) {
      leafIndex.set(node.path, node)
      trailIndex.set(node.path, nextTrail)
    }
  })
}
indexNodes(navTree, [])

export function flattenMenu(nodes: NavNode[] = navTree): NavNode[] {
  return nodes.flatMap((node) => [node, ...(node.children ? flattenMenu(node.children) : [])])
}

export function flattenLeaves(nodes: NavNode[] = navTree): NavNode[] {
  return flattenMenu(nodes).filter((node) => Boolean(node.path))
}

export function findNodeByPath(path: string): NavNode | undefined {
  return leafIndex.get(path)
}

export function getMenuTrail(path: string): NavNode[] {
  return trailIndex.get(path) ?? []
}

export function getDomainOf(path: string): NavNode | undefined {
  return getMenuTrail(path)[0]
}

export function getBreadcrumbs(path: string): CrumbItem[] {
  const trail = getMenuTrail(path)
  if (path === DASHBOARD_PATH) return [{ key: 'home', label: '首页' }, { key: 'dashboard', label: '工作台' }]
  return [
    { key: 'home', label: '首页', path: DASHBOARD_PATH },
    ...trail.map((node) => ({ key: node.key, label: node.label, path: node.path })),
  ]
}

export function getOpenKeys(path: string): string[] {
  return getMenuTrail(path).slice(0, -1).map((node) => node.key)
}

export function filterMenuByPermission(nodes: NavNode[], permissions: PermissionCode[]): NavNode[] {
  return nodes.reduce<NavNode[]>((result, node) => {
    if (node.children?.length) {
      const children = filterMenuByPermission(node.children, permissions)
      if (children.length) result.push({ ...node, children })
    } else if (hasPermission(permissions, node.permission)) {
      result.push(node)
    }
    return result
  }, [])
}

export function buildDomainEntries(visibleTree: NavNode[]): DomainMeta[] {
  return visibleTree
    .filter((node) => node.key !== 'dashboard')
    .map((node) => {
      const leaves = flattenLeaves([node])
      return {
        key: node.key,
        label: node.label,
        icon: node.icon,
        description: node.description ?? '',
        entryPath: leaves[0]?.path ?? '',
        leafCount: leaves.length,
      }
    })
    .filter((entry) => Boolean(entry.entryPath))
}

const reportWords = ['报表', '明细', '汇总', '统计', '总览', '台账']
const recordWords = ['记录', '日志', '流水', '查询', '审计']
const settingWords = ['设置', '参数', '规则', '配置', '维护', '清理', '备份', '授权', '定义']

export function getModulePageMeta(path: string): ModulePageMeta | undefined {
  const node = findNodeByPath(path)
  if (!node) return undefined
  const trail = getMenuTrail(path)
  const kind: ModulePageMeta['kind'] = reportWords.some((word) => node.label.includes(word))
    ? 'report'
    : recordWords.some((word) => node.label.includes(word))
      ? 'record'
      : settingWords.some((word) => node.label.includes(word))
        ? 'setting'
        : 'master'
  const permission = node.permission ?? ''
  return {
    path,
    title: node.label,
    domainKey: trail[0]?.key ?? '',
    domainLabel: trail[0]?.label ?? '',
    groupLabel: trail[1]?.label ?? '',
    description: node.description ?? `${node.label}的查询、核对与维护`,
    primaryAction: kind === 'report' || kind === 'record' ? '导出数据' : `新增${node.label}`,
    permission,
    resource: permission.replace(/:view$/, ''),
    kind,
  }
}

export function buildMenuSearchIndex(visibleTree: NavNode[]): MenuSearchItem[] {
  const items: MenuSearchItem[] = []
  const visit = (nodes: NavNode[], labels: string[], domain: string): void => {
    nodes.forEach((node) => {
      const nextLabels = [...labels, node.label]
      if (node.children?.length) visit(node.children, nextLabels, labels.length === 0 ? node.label : domain)
      else if (node.path) items.push({
        path: node.path,
        title: node.label,
        domain: domain || nextLabels[0],
        trail: nextLabels.join(' / '),
        depth: nextLabels.length,
      })
    })
  }
  visit(visibleTree, [], '')
  return items
}

export function searchMenu(index: MenuSearchItem[], keyword: string, limit = 10): MenuSearchItem[] {
  const value = keyword.trim().toLowerCase()
  if (!value) return []
  return index
    .filter((item) => `${item.title} ${item.trail} ${item.path}`.toLowerCase().includes(value))
    .sort((a, b) => a.depth - b.depth || a.title.length - b.title.length)
    .slice(0, limit)
}

export function resolveDomainEntry(domainKey: string, visibleTree: NavNode[]): string {
  const domain = visibleTree.find((node) => node.key === domainKey)
  return domain ? flattenLeaves([domain])[0]?.path ?? DASHBOARD_PATH : DASHBOARD_PATH
}
