import type { ReactNode } from 'react'
import type { NavNode } from '@/types/navigation'

export type LeafTuple = [label: string, path: string, permission: string]

export interface GroupInput {
  key: string
  title: string
  leaves: LeafTuple[]
}

export interface DomainInput {
  key: string
  label: string
  icon: ReactNode
  permission: string
  description: string
  groups: GroupInput[]
}

export function pathToKey(path: string): string {
  return path.replace(/^\//, '').replace(/\//g, '-')
}

export function defineDomain(input: DomainInput): NavNode {
  return {
    key: input.key,
    label: input.label,
    icon: input.icon,
    permission: input.permission,
    description: input.description,
    children: input.groups.map((group) => ({
      key: `${input.key}-${group.key}-group`,
      label: group.title,
      children: group.leaves.map(([label, path, permission]) => ({
        key: pathToKey(path),
        label,
        path,
        permission,
        description: `${group.title} · ${label}：提供${label}的查询、核对与业务维护能力。`,
      })),
    })),
  }
}
