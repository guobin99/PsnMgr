import { Button, Result } from 'antd'
import { useNavigate } from 'react-router-dom'

export default function NotFoundPage() {
  const navigate = useNavigate()
  return <Result status="404" title="页面不存在" subTitle="您访问的地址有误，或该功能尚未加入导航。" extra={<Button type="primary" onClick={() => navigate('/dashboard', { replace: true })}>返回工作台</Button>} />
}
