import { Spin } from 'antd'

export default function PageLoading() {
  return <div className="page-loading"><Spin size="large" /><span>页面加载中…</span></div>
}
