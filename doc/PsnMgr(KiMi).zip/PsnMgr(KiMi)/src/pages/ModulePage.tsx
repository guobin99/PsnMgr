import { useMemo, useState } from 'react'
import { App as AntdApp, Button, Card, DatePicker, Input, Select, Space, Table, Tag } from 'antd'
import { DownloadOutlined, PlusOutlined, ReloadOutlined, SearchOutlined } from '@ant-design/icons'
import { useLocation } from 'react-router-dom'
import { getModulePageMeta } from '@/config/menu'
import { Permission } from '@/components/auth/Permission'
import NotFoundPage from './NotFoundPage'

interface DemoRow {
  key: string
  code: string
  name: string
  department: string
  updatedAt: string
  status: string
}

const names = ['陈晓', '李慧', '王强', '赵磊', '刘洋', '周敏', '张明', '陈婷']

export default function ModulePage() {
  const location = useLocation()
  const meta = getModulePageMeta(location.pathname)
  const { message } = AntdApp.useApp()
  const [keyword, setKeyword] = useState('')
  const [status, setStatus] = useState<string>('all')
  const [query, setQuery] = useState({ keyword: '', status: 'all' })

  const rows = useMemo<DemoRow[]>(() => names.map((name, index) => ({
    key: `${location.pathname}-${index}`,
    code: `${meta?.domainKey.toUpperCase() ?? 'BS'}-${String(index + 1).padStart(4, '0')}`,
    name: meta?.kind === 'master' ? name : `${meta?.title ?? '业务'}记录 ${index + 1}`,
    department: ['信息中心', '人力资源部', '财务处', '后勤服务集团'][index % 4],
    updatedAt: `2026-11-${String(16 - (index % 5)).padStart(2, '0')} ${String(8 + index).padStart(2, '0')}:30`,
    status: index === 5 ? '待审核' : index === 7 ? '已停用' : '正常',
  })), [location.pathname, meta])

  const filteredRows = useMemo(() => rows.filter((row) => {
    const matchesKeyword = !query.keyword || `${row.code} ${row.name} ${row.department}`.toLowerCase().includes(query.keyword.toLowerCase())
    return matchesKeyword && (query.status === 'all' || row.status === query.status)
  }), [rows, query])

  if (!meta) return <NotFoundPage />
  const operation = meta.kind === 'report' || meta.kind === 'record' ? 'export' : 'edit'
  const operationCode = `${meta.resource}:${operation}`

  return (
    <div className="module-page">
      <div className="module-heading">
        <div><div className="module-heading__tags"><Tag color="green">{meta.domainLabel}</Tag><span>{meta.groupLabel}</span></div><h1>{meta.title}</h1><p>{meta.description}</p></div>
        <Permission code={operationCode}>
          <Button type="primary" icon={operation === 'export' ? <DownloadOutlined /> : <PlusOutlined />} onClick={() => message.success(`${meta.primaryAction}操作已触发（界面演示）`)}>{meta.primaryAction}</Button>
        </Permission>
      </div>

      <Card className="query-card">
        <div className="query-form">
          <div className="query-field query-field--keyword"><label>关键词</label><Input allowClear placeholder={`搜索${meta.title}名称或编号`} value={keyword} onChange={(event) => setKeyword(event.target.value)} onPressEnter={() => setQuery({ keyword, status })} /></div>
          <div className="query-field"><label>状态</label><Select value={status} onChange={setStatus} options={[{ value: 'all', label: '全部状态' }, { value: '正常', label: '正常' }, { value: '待审核', label: '待审核' }, { value: '已停用', label: '已停用' }]} /></div>
          <div className="query-field query-field--date"><label>业务日期</label><DatePicker.RangePicker /></div>
          <div className="query-actions"><Button type="primary" icon={<SearchOutlined />} onClick={() => setQuery({ keyword, status })}>查询</Button><Button icon={<ReloadOutlined />} onClick={() => { setKeyword(''); setStatus('all'); setQuery({ keyword: '', status: 'all' }) }}>重置</Button></div>
        </div>
      </Card>

      <Card className="data-card">
        <div className="data-card__header"><div><strong>{meta.title}列表</strong><span>共 {filteredRows.length} 条界面演示数据</span></div><Permission code={`${meta.resource}:export`}><Button icon={<DownloadOutlined />} onClick={() => message.success('导出任务已创建（界面演示）')}>导出</Button></Permission></div>
        <Table<DemoRow>
          rowKey="key"
          dataSource={filteredRows}
          scroll={{ x: 860 }}
          pagination={{ pageSize: 8, showSizeChanger: false, showTotal: (total) => `共 ${total} 条` }}
          columns={[
            { title: '业务编号', dataIndex: 'code', width: 150, render: (value: string) => <span className="table-code">{value}</span> },
            { title: meta.kind === 'master' ? '姓名 / 名称' : '业务事项', dataIndex: 'name', width: 200 },
            { title: '所属部门', dataIndex: 'department', width: 170 },
            { title: '更新时间', dataIndex: 'updatedAt', width: 180 },
            { title: '状态', dataIndex: 'status', width: 110, render: (value: string) => <Tag color={value === '正常' ? 'success' : value === '待审核' ? 'warning' : 'default'}>{value}</Tag> },
            { title: '操作', key: 'action', fixed: 'right', width: 140, render: () => <Space><Button type="link" size="small" onClick={() => message.info('详情面板将在业务开发阶段接入')}>查看</Button><Permission code={`${meta.resource}:edit`}><Button type="link" size="small" onClick={() => message.info('编辑表单将在业务开发阶段接入')}>编辑</Button></Permission></Space> },
          ]}
        />
      </Card>
      <div className="module-stage-note">当前交付范围为布局、导航与权限骨架；本页数据结构及操作将在对应业务模块开发时接入 .NET RESTful API。</div>
    </div>
  )
}
