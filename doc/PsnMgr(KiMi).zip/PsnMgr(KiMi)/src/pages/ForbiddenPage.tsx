import { Button, Result, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'

export default function ForbiddenPage({ required, from }: { required?: string; from?: string }) {
  const navigate = useNavigate()
  return (
    <Result
      status="403"
      title="暂无访问权限"
      subTitle={<span>当前角色无法访问该功能。{required && <>所需权限码：<Typography.Text code>{required}</Typography.Text></>}{from && <span className="forbidden-from"> 请求路径：{from}</span>}</span>}
      extra={<Button type="primary" onClick={() => navigate('/dashboard', { replace: true })}>返回工作台</Button>}
    />
  )
}
