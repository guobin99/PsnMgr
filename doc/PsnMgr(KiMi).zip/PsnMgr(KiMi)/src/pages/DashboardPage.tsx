import { useMemo } from 'react'
import { Button, Card, Col, Progress, Row, Table, Tag } from 'antd'
import {
  ArrowRightOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  CoffeeOutlined,
  IdcardOutlined,
  RiseOutlined,
  SafetyCertificateOutlined,
  ScheduleOutlined,
  TeamOutlined,
} from '@ant-design/icons'
import dayjs from 'dayjs'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/store/auth'
import { buildDomainEntries, filterMenuByPermission, navTree } from '@/config/menu'

const consumeTrend = [
  { day: '周一', value: 62, amount: '18,420' }, { day: '周二', value: 72, amount: '21,360' },
  { day: '周三', value: 66, amount: '19,580' }, { day: '周四', value: 84, amount: '24,960' },
  { day: '周五', value: 78, amount: '23,140' }, { day: '周六', value: 55, amount: '16,320' },
  { day: '今日', value: 96, amount: '28,640' },
]

const recentRows = [
  { key: '1', time: '10:26:32', person: '陈晓', type: '消费', place: '一号食堂', result: '消费成功', amount: '¥ 12.50' },
  { key: '2', time: '10:24:18', person: '王强', type: '门禁', place: '行政楼东门', result: '正常通行', amount: '—' },
  { key: '3', time: '10:21:06', person: '李慧', type: '考勤', place: '考勤机 01', result: '签到成功', amount: '—' },
  { key: '4', time: '10:18:45', person: '赵磊', type: '订餐', place: '二号食堂', result: '午餐预订', amount: '¥ 18.00' },
  { key: '5', time: '10:12:11', person: '刘洋', type: '访客', place: '园区访客中心', result: '预约通过', amount: '—' },
]

export default function DashboardPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const hour = dayjs().hour()
  const greeting = hour < 11 ? '上午好' : hour < 14 ? '中午好' : hour < 18 ? '下午好' : '晚上好'
  const domains = useMemo(
    () => buildDomainEntries(filterMenuByPermission(navTree, user?.permissions ?? [])),
    [user?.permissions],
  )

  return (
    <div className="dashboard-page">
      <section className="dashboard-welcome">
        <div>
          <h1>{greeting}，{user?.displayName}</h1>
          <p>今天是 {dayjs().format('YYYY 年 M 月 D 日 dddd')}，欢迎回到人脸通管理平台。</p>
        </div>
        <div className="dashboard-welcome__badge"><CheckCircleOutlined /> 系统运行正常 <span>·</span> {user?.roleName}</div>
      </section>

      <Row gutter={[16, 16]} className="stat-grid">
        <Col xs={24} sm={12} xl={6}>
          <Card className="stat-card"><div className="stat-card__top"><span className="stat-icon stat-icon--green"><CoffeeOutlined /></span><Tag color="success">今日</Tag></div><span className="stat-label">今日消费金额</span><strong className="stat-value stat-value--money">¥ 28,640.50</strong><div className="stat-trend"><RiseOutlined /> <b>12.5%</b><span>较昨日</span></div></Card>
        </Col>
        <Col xs={24} sm={12} xl={6}>
          <Card className="stat-card"><div className="stat-card__top"><span className="stat-icon stat-icon--blue"><ScheduleOutlined /></span><Tag color="processing">实时</Tag></div><span className="stat-label">今日出勤率</span><strong className="stat-value">98.6<small>%</small></strong><div className="stat-card__progress"><Progress percent={98.6} showInfo={false} strokeColor="#3478f6" size="small" /></div></Card>
        </Col>
        <Col xs={24} sm={12} xl={6}>
          <Card className="stat-card"><div className="stat-card__top"><span className="stat-icon stat-icon--purple"><SafetyCertificateOutlined /></span><Tag color="purple">门禁</Tag></div><span className="stat-label">今日通行人次</span><strong className="stat-value">1,286<small>次</small></strong><div className="stat-trend stat-trend--muted"><CheckCircleOutlined /> 正常率 99.8%</div></Card>
        </Col>
        <Col xs={24} sm={12} xl={6}>
          <Card className="stat-card"><div className="stat-card__top"><span className="stat-icon stat-icon--orange"><TeamOutlined /></span><Tag color="warning">待办</Tag></div><span className="stat-label">待审核访客</span><strong className="stat-value">12<small>项</small></strong><div className="stat-trend stat-trend--muted"><ClockCircleOutlined /> 最早待办 32 分钟前</div></Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} className="dashboard-main-row">
        <Col xs={24} xl={16}>
          <Card className="dashboard-card trend-card" title="本周消费趋势" extra={<Button type="link" onClick={() => navigate('/consume/records')}>查看消费流水 <ArrowRightOutlined /></Button>}>
            <div className="trend-summary"><span>本周累计<strong>¥ 132,440.50</strong></span><Tag color="success">同比 +8.2%</Tag></div>
            <div className="bar-chart">
              {consumeTrend.map((item) => <div className="bar-chart__item" key={item.day}><span className="bar-chart__amount">¥{item.amount}</span><div className="bar-chart__track"><div className={item.day === '今日' ? 'bar-chart__bar bar-chart__bar--today' : 'bar-chart__bar'} style={{ height: `${item.value}%` }} /></div><span>{item.day}</span></div>)}
            </div>
          </Card>
        </Col>
        <Col xs={24} xl={8}>
          <Card className="dashboard-card status-card" title="系统运行状态" extra={<span className="live-indicator">实时</span>}>
            {[
              ['数据库服务', 'SQL Server · 数据同源', 100],
              ['消费通讯服务', '终端连接稳定', 96],
              ['人脸识别服务', '运行正常', 98],
              ['数据同步服务', '最近同步 2 分钟前', 92],
            ].map(([name, description, value]) => <div className="service-status" key={String(name)}><div><strong>{name}</strong><span>{description}</span></div><Progress type="circle" size={42} percent={Number(value)} strokeColor="#1c7c68" format={() => <CheckCircleOutlined />} /></div>)}
          </Card>
        </Col>
      </Row>

      <Card className="dashboard-card quick-card" title="常用功能" extra={<span className="card-extra-note">根据当前角色权限显示</span>}>
        <div className="quick-grid">
          {domains.slice(0, 6).map((domain, index) => (
            <button key={domain.key} onClick={() => navigate(domain.entryPath)} className={`quick-entry quick-entry--${index % 6}`}>
              <span>{domain.icon}</span><div><strong>{domain.label}</strong><small>{domain.description}</small></div><ArrowRightOutlined />
            </button>
          ))}
          {domains.length === 0 && <div className="quick-empty"><IdcardOutlined /> 当前角色暂无业务域权限</div>}
        </div>
      </Card>

      <Card className="dashboard-card recent-card" title="最新业务动态" extra={<Tag>界面原型数据</Tag>}>
        <Table
          size="middle"
          pagination={false}
          dataSource={recentRows}
          scroll={{ x: 700 }}
          columns={[
            { title: '时间', dataIndex: 'time', width: 110 },
            { title: '人员', dataIndex: 'person', width: 100 },
            { title: '业务类型', dataIndex: 'type', render: (value: string) => <Tag color={value === '消费' ? 'green' : value === '门禁' ? 'blue' : 'default'}>{value}</Tag> },
            { title: '位置 / 设备', dataIndex: 'place' },
            { title: '结果', dataIndex: 'result' },
            { title: '金额', dataIndex: 'amount', align: 'right' },
          ]}
        />
      </Card>
    </div>
  )
}
