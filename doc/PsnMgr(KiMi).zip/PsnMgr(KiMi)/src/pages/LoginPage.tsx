import { useState } from 'react'
import { App as AntdApp, Button, Checkbox, Form, Input, Tag } from 'antd'
import { LockOutlined, ScanOutlined, SafetyCertificateOutlined, UserOutlined } from '@ant-design/icons'
import { useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '@/store/auth'
import { useTabs } from '@/store/tabs'
import { DEMO_ACCOUNTS, DEMO_PASSWORD, isDemoLoginEnabled } from '@/config/roles'
import { readStorage, removeStorage, storageKeys, writeStorage } from '@/utils/storage'
import type { LoginPayload } from '@/types/navigation'

interface LoginForm extends LoginPayload {
  remember: boolean
}

export default function LoginPage() {
  const [form] = Form.useForm<LoginForm>()
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const { resetTabs } = useTabs()
  const { message } = AntdApp.useApp()
  const navigate = useNavigate()
  const location = useLocation()
  const remembered = readStorage(storageKeys.loginUserName)
  const demoEnabled = isDemoLoginEnabled()

  const submit = async (values: LoginForm) => {
    setLoading(true)
    try {
      const user = await login({ userName: values.userName.trim(), password: values.password })
      if (values.remember) writeStorage(storageKeys.loginUserName, values.userName.trim())
      else removeStorage(storageKeys.loginUserName)
      resetTabs()
      message.success(`欢迎回来，${user.displayName}`)
      const from = (location.state as { from?: string } | null)?.from
      navigate(from || '/dashboard', { replace: true })
    } catch (error) {
      message.error(error instanceof Error ? error.message : '登录失败，请稍后重试')
    } finally {
      setLoading(false)
      form.setFieldValue('password', '')
    }
  }

  const selectDemo = (userName: string) => {
    form.setFieldsValue({ userName, password: DEMO_PASSWORD, remember: false })
  }

  return (
    <main className="login-page">
      <section className="login-showcase">
        <div className="login-showcase__glow login-showcase__glow--one" />
        <div className="login-showcase__glow login-showcase__glow--two" />
        <div className="login-showcase__brand"><span><ScanOutlined /></span>人脸通</div>
        <div className="login-showcase__content">
          <Tag className="login-version">BS 一体化管理平台</Tag>
          <h1>一个平台，连接<br />每一处智慧场景</h1>
          <p>统一承载卡务、消费、考勤、门禁、订餐与访客业务，让管理更简单，让数据更有价值。</p>
          <div className="login-feature-list">
            <div><SafetyCertificateOutlined /><span><strong>角色权限体系</strong><small>菜单、页面与操作三级控制</small></span></div>
            <div><ScanOutlined /><span><strong>全业务数据同源</strong><small>与现有 CS 系统平滑并行</small></span></div>
          </div>
        </div>
        <div className="login-showcase__footer">稳定 · 安全 · 高效 · 协同</div>
      </section>

      <section className="login-panel">
        <div className="login-box">
          <div className="login-mobile-brand"><ScanOutlined /> 人脸通</div>
          <div className="login-heading">
            <span className="login-heading__eyebrow">WELCOME BACK</span>
            <h2>登录管理平台</h2>
            <p>使用 CS 系统操作员账号登录</p>
          </div>
          <Form<LoginForm>
            form={form}
            layout="vertical"
            requiredMark={false}
            onFinish={submit}
            initialValues={{ userName: remembered ?? '', password: '', remember: Boolean(remembered) }}
            size="large"
          >
            <Form.Item name="userName" label="账号" rules={[{ required: true, message: '请输入操作员账号' }, { whitespace: true, message: '账号不能为空白' }]}>
              <Input prefix={<UserOutlined />} placeholder="请输入操作员账号" autoComplete="username" maxLength={50} />
            </Form.Item>
            <Form.Item name="password" label="密码" rules={[{ required: true, message: '请输入密码' }]}>
              <Input.Password prefix={<LockOutlined />} placeholder="请输入登录密码" autoComplete="current-password" maxLength={100} />
            </Form.Item>
            <Form.Item name="remember" valuePropName="checked" className="login-remember">
              <Checkbox>记住账号</Checkbox>
            </Form.Item>
            <Button type="primary" htmlType="submit" block loading={loading} className="login-submit">登 录</Button>
          </Form>

          {demoEnabled && (
            <div className="demo-accounts">
              <div className="demo-accounts__title"><span>演示角色</span><small>选择角色自动填充 · 密码 123456</small></div>
              <div className="demo-accounts__grid">
                {DEMO_ACCOUNTS.map((account) => (
                  <button key={account.userName} onClick={() => selectDemo(account.userName)}>{account.displayName}<small>{account.userName}</small></button>
                ))}
              </div>
              <p>后端服务未启动时，开发环境将自动使用演示会话。</p>
            </div>
          )}
          <div className="login-security"><LockOutlined /> 登录密码仅用于本次认证，不会在本地保存</div>
        </div>
        <footer>© 2026 人脸通系统 · 管理端</footer>
      </section>
    </main>
  )
}
