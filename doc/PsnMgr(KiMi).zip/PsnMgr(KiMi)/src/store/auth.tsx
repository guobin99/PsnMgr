import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { PropsWithChildren } from 'react'
import { App as AntdApp } from 'antd'
import type { LoginPayload, SessionUser } from '@/types/navigation'
import { loginRequest, logoutRequest } from '@/services/auth'
import { UNAUTHORIZED_EVENT } from '@/services/http'
import { readJson, readStorage, removeStorage, storageKeys, writeJson, writeStorage } from '@/utils/storage'

interface AuthContextValue {
  token: string | null
  user: SessionUser | null
  isAuthenticated: boolean
  login: (payload: LoginPayload) => Promise<SessionUser>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

function restoreUser(): SessionUser | null {
  const token = readStorage(storageKeys.token)
  const user = readJson<SessionUser>(storageKeys.user)
  return token && user ? user : null
}

export function AuthProvider({ children }: PropsWithChildren) {
  const { message } = AntdApp.useApp()
  const initialUser = restoreUser()
  const [user, setUser] = useState<SessionUser | null>(initialUser)
  const [token, setToken] = useState<string | null>(initialUser ? readStorage(storageKeys.token) : null)

  const clearSession = useCallback(() => {
    removeStorage(storageKeys.token)
    removeStorage(storageKeys.user)
    setToken(null)
    setUser(null)
  }, [])

  useEffect(() => {
    const onUnauthorized = () => {
      clearSession()
      message.warning('登录状态已失效，请重新登录')
    }
    window.addEventListener(UNAUTHORIZED_EVENT, onUnauthorized)
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, onUnauthorized)
  }, [clearSession, message])

  const login = useCallback(async (payload: LoginPayload) => {
    const result = await loginRequest(payload)
    writeStorage(storageKeys.token, result.token)
    writeJson(storageKeys.user, result.user)
    setToken(result.token)
    setUser(result.user)
    return result.user
  }, [])

  const logout = useCallback(async () => {
    try {
      await logoutRequest()
    } catch {
      // 后端退出接口失败也必须允许本地安全退出。
    } finally {
      clearSession()
    }
  }, [clearSession])

  const value = useMemo<AuthContextValue>(() => ({
    token,
    user,
    isAuthenticated: Boolean(token && user),
    login,
    logout,
  }), [token, user, login, logout])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth 必须在 AuthProvider 内使用')
  return context
}
