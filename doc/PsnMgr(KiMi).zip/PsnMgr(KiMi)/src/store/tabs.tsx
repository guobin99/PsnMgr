import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import type { PropsWithChildren } from 'react'
import type { TabItem } from '@/types/navigation'
import { DASHBOARD_PATH, findNodeByPath, getDomainOf } from '@/config/menu'

const dashboardTab: TabItem = {
  key: DASHBOARD_PATH,
  path: DASHBOARD_PATH,
  title: '工作台',
  domain: '首页',
  closable: false,
}

interface TabsContextValue {
  tabs: TabItem[]
  activePath: string
  setActivePath: (path: string) => void
  openTab: (path: string) => void
  closeTab: (path: string) => string | null
  closeOthers: (path: string) => string
  closeAll: () => string
  resetTabs: () => void
}

const TabsContext = createContext<TabsContextValue | null>(null)

export function TabsProvider({ children }: PropsWithChildren) {
  const [tabs, setTabs] = useState<TabItem[]>([dashboardTab])
  const [activePath, setActivePath] = useState(DASHBOARD_PATH)

  const openTab = useCallback((path: string) => {
    const node = findNodeByPath(path)
    if (!node) return
    const tab: TabItem = {
      key: path,
      path,
      title: node.label,
      domain: getDomainOf(path)?.label ?? '首页',
      closable: path !== DASHBOARD_PATH,
    }
    setTabs((current) => current.some((item) => item.path === path) ? current : [...current, tab])
  }, [])

  const closeTab = useCallback((path: string) => {
    const target = tabs.find((tab) => tab.path === path)
    if (!target?.closable) return null
    const index = tabs.findIndex((tab) => tab.path === path)
    const remaining = tabs.filter((tab) => tab.path !== path)
    setTabs(remaining)
    if (activePath !== path) return null
    return remaining[Math.max(0, index - 1)]?.path ?? DASHBOARD_PATH
  }, [tabs, activePath])

  const closeOthers = useCallback((path: string) => {
    const target = tabs.find((tab) => tab.path === path) ?? findNodeByPath(path)
    const targetPath = target?.path ?? DASHBOARD_PATH
    setTabs((current) => current.filter((tab) => !tab.closable || tab.path === targetPath))
    return targetPath
  }, [tabs])

  const closeAll = useCallback(() => {
    setTabs([dashboardTab])
    return DASHBOARD_PATH
  }, [])

  const resetTabs = useCallback(() => {
    setTabs([dashboardTab])
    setActivePath(DASHBOARD_PATH)
  }, [])

  const value = useMemo(() => ({
    tabs, activePath, setActivePath, openTab, closeTab, closeOthers, closeAll, resetTabs,
  }), [tabs, activePath, openTab, closeTab, closeOthers, closeAll, resetTabs])

  return <TabsContext.Provider value={value}>{children}</TabsContext.Provider>
}

export function useTabs(): TabsContextValue {
  const context = useContext(TabsContext)
  if (!context) throw new Error('useTabs 必须在 TabsProvider 内使用')
  return context
}
