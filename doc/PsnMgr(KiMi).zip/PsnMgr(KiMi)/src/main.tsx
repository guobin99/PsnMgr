import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { App as AntdApp, ConfigProvider } from 'antd'
import zhCN from 'antd/locale/zh_CN'
import dayjs from 'dayjs'
import 'dayjs/locale/zh-cn'
import { AuthProvider } from '@/store/auth'
import { TabsProvider } from '@/store/tabs'
import App from './App'
import '@/styles/global.css'

dayjs.locale('zh-cn')

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ConfigProvider
      locale={zhCN}
      theme={{
        token: {
          colorPrimary: '#176b5b',
          colorInfo: '#176b5b',
          borderRadius: 8,
          fontFamily: 'Inter, "PingFang SC", "Microsoft YaHei", system-ui, sans-serif',
          colorBgLayout: '#f4f6f8',
        },
        components: {
          Layout: { headerBg: '#ffffff', siderBg: '#10243e' },
          Menu: { darkItemBg: '#10243e', darkSubMenuItemBg: '#0c1d33', darkItemSelectedBg: '#176b5b' },
        },
      }}
    >
      <AntdApp>
        <AuthProvider>
          <TabsProvider>
            <BrowserRouter>
              <App />
            </BrowserRouter>
          </TabsProvider>
        </AuthProvider>
      </AntdApp>
    </ConfigProvider>
  </StrictMode>,
)
