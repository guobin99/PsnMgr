import type { ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import AdminLayout from '@/layouts/AdminLayout';
import Dashboard from '@/pages/Dashboard';
import LoginPage from '@/pages/LoginPage';
import ModulePage from '@/pages/ModulePage';
import NotFoundPage from '@/pages/NotFoundPage';
import { findNavItem } from '@/config/navigation';
import { getAccessToken } from '@/utils/auth';

function RequireAuth({ children }: { children: ReactNode }) {
  const location = useLocation();
  if (!getAccessToken()) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }
  return children;
}

function BusinessRoute() {
  const location = useLocation();
  return findNavItem(location.pathname) ? <ModulePage /> : <NotFoundPage />;
}

export default function AppRouter() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route
        path="/"
        element={
          <RequireAuth>
            <AdminLayout />
          </RequireAuth>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="*" element={<BusinessRoute />} />
      </Route>
    </Routes>
  );
}
