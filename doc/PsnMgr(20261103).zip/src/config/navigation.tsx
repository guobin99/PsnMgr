import {
  AppstoreOutlined,
  BarChartOutlined,
  CoffeeOutlined,
  DashboardOutlined,
  IdcardOutlined,
  SafetyCertificateOutlined,
  ScheduleOutlined,
  SettingOutlined,
  ShoppingOutlined,
  TeamOutlined,
  ThunderboltOutlined,
} from '@ant-design/icons';
import type { NavItem, ModulePageMeta } from '@/types/navigation';

export const navigation: NavItem[] = [
  {
    key: 'dashboard',
    label: '工作台',
    path: '/dashboard',
    icon: <DashboardOutlined />,
    permission: 'dashboard:view',
  },
  {
    key: 'card',
    label: '卡务中心',
    icon: <IdcardOutlined />,
    permission: 'card:view',
    children: [
      {
        key: 'card-person',
        label: '人员与账户',
        children: [
          { key: 'card-personnel', label: '人员档案', path: '/card/personnel', permission: 'card:person:view' },
          { key: 'card-departments', label: '部门管理', path: '/card/departments', permission: 'card:dept:view' },
          { key: 'card-accounts', label: '账户与卡', path: '/card/accounts', permission: 'card:account:view' },
        ],
      },
      {
        key: 'card-fund',
        label: '资金业务',
        children: [
          { key: 'card-funds', label: '充值与取款', path: '/card/funds', permission: 'card:fund:view' },
          { key: 'card-subsidy', label: '补贴管理', path: '/card/subsidy', permission: 'card:subsidy:view' },
        ],
      },
      {
        key: 'card-settlement',
        label: '结算与报表',
        children: [
          { key: 'card-settlements', label: '出纳结算', path: '/card/settlements', permission: 'card:settlement:view' },
          { key: 'card-reports', label: '财务报表', path: '/card/reports', permission: 'card:report:view' },
        ],
      },
    ],
  },
  {
    key: 'consume',
    label: '消费管理',
    icon: <ShoppingOutlined />,
    permission: 'consume:view',
    children: [
      {
        key: 'consume-basic',
        label: '基础资料',
        children: [
          { key: 'consume-products', label: '商品与餐别', path: '/consume/products' },
          { key: 'consume-devices', label: '消费终端', path: '/consume/devices' },
        ],
      },
      {
        key: 'consume-business',
        label: '业务处理',
        children: [
          { key: 'consume-records', label: '消费流水', path: '/consume/records' },
          { key: 'consume-subsidy', label: '补助发放', path: '/consume/subsidy' },
          { key: 'consume-corrections', label: '异常与冲正', path: '/consume/corrections' },
        ],
      },
      {
        key: 'consume-statistics',
        label: '统计报表',
        children: [
          { key: 'consume-summary', label: '消费汇总', path: '/consume/summary' },
          { key: 'consume-reports', label: '销售报表', path: '/consume/reports' },
        ],
      },
    ],
  },
  {
    key: 'attendance',
    label: '考勤管理',
    icon: <ScheduleOutlined />,
    permission: 'attendance:view',
    children: [
      {
        key: 'attendance-rules',
        label: '规则与排班',
        children: [
          { key: 'attendance-settings', label: '考勤规则', path: '/attendance/settings' },
          { key: 'attendance-shifts', label: '班次设置', path: '/attendance/shifts' },
          { key: 'attendance-schedules', label: '排班管理', path: '/attendance/schedules' },
        ],
      },
      {
        key: 'attendance-data',
        label: '考勤数据',
        children: [
          { key: 'attendance-records', label: '打卡记录', path: '/attendance/records' },
          { key: 'attendance-daily', label: '每日考勤', path: '/attendance/daily' },
          { key: 'attendance-monthly', label: '月度汇总', path: '/attendance/monthly' },
        ],
      },
      {
        key: 'attendance-exceptions',
        label: '异常处理',
        badge: 12,
        children: [
          { key: 'attendance-leave', label: '请假与加班', path: '/attendance/leave' },
          { key: 'attendance-approvals', label: '补签审批', path: '/attendance/approvals', badge: 12 },
          { key: 'attendance-corrections', label: '异常核对', path: '/attendance/corrections' },
        ],
      },
      {
        key: 'attendance-statistics',
        label: '统计报表',
        children: [
          { key: 'attendance-reports', label: '考勤报表', path: '/attendance/reports' },
        ],
      },
    ],
  },
  {
    key: 'access',
    label: '门禁管理',
    icon: <SafetyCertificateOutlined />,
    permission: 'access:view',
    children: [
      {
        key: 'access-basic',
        label: '设备与权限',
        children: [
          { key: 'access-devices', label: '控制器与门', path: '/access/devices' },
          { key: 'access-timezones', label: '时段设置', path: '/access/timezones' },
          { key: 'access-permissions', label: '门禁授权', path: '/access/permissions' },
        ],
      },
      {
        key: 'access-operation',
        label: '监控与记录',
        children: [
          { key: 'access-monitor', label: '实时门禁监控', path: '/access/monitor' },
          { key: 'access-records', label: '通行记录', path: '/access/records' },
          { key: 'access-alarms', label: '异常事件', path: '/access/alarms', badge: 3 },
        ],
      },
      {
        key: 'access-statistics',
        label: '统计报表',
        children: [
          { key: 'access-reports', label: '门禁报表', path: '/access/reports' },
        ],
      },
    ],
  },
  {
    key: 'meal',
    label: '订餐管理',
    icon: <CoffeeOutlined />,
    permission: 'meal:view',
    children: [
      {
        key: 'meal-basic',
        label: '基础设置',
        children: [
          { key: 'meal-menus', label: '食堂与菜品', path: '/meal/menus' },
          { key: 'meal-rules', label: '订餐规则', path: '/meal/rules' },
        ],
      },
      {
        key: 'meal-business',
        label: '订餐业务',
        children: [
          { key: 'meal-orders', label: '订餐订单', path: '/meal/orders' },
          { key: 'meal-verification', label: '取餐核销', path: '/meal/verification' },
          { key: 'meal-cancellations', label: '退订管理', path: '/meal/cancellations' },
        ],
      },
      {
        key: 'meal-statistics',
        label: '统计报表',
        children: [
          { key: 'meal-reports', label: '订餐报表', path: '/meal/reports' },
        ],
      },
    ],
  },
  {
    key: 'visitor',
    label: '访客管理',
    icon: <TeamOutlined />,
    permission: 'visitor:view',
    children: [
      {
        key: 'visitor-appointments',
        label: '预约与审批',
        children: [
          { key: 'visitor-bookings', label: '访客预约', path: '/visitor/bookings' },
          { key: 'visitor-approvals', label: '访客审批', path: '/visitor/approvals', badge: 8 },
        ],
      },
      {
        key: 'visitor-business',
        label: '访客业务',
        children: [
          { key: 'visitor-registration', label: '访客登记', path: '/visitor/registration' },
          { key: 'visitor-records', label: '进出记录', path: '/visitor/records' },
        ],
      },
      {
        key: 'visitor-statistics',
        label: '统计报表',
        children: [
          { key: 'visitor-reports', label: '访客报表', path: '/visitor/reports' },
        ],
      },
    ],
  },
  {
    key: 'extensions',
    label: '扩展应用',
    icon: <ThunderboltOutlined />,
    permission: 'extension:view',
    children: [
      { key: 'extension-water', label: '水控管理', path: '/extensions/water' },
      { key: 'extension-patrol', label: '巡更管理', path: '/extensions/patrol' },
    ],
  },
  {
    key: 'reports',
    label: '报表中心',
    icon: <BarChartOutlined />,
    permission: 'report:view',
    children: [
      { key: 'reports-overview', label: '综合运营报表', path: '/reports/overview' },
      { key: 'reports-favorites', label: '常用报表', path: '/reports/favorites' },
    ],
  },
  {
    key: 'system',
    label: '系统管理',
    icon: <SettingOutlined />,
    permission: 'system:view',
    children: [
      {
        key: 'system-permissions',
        label: '组织与权限',
        children: [
          { key: 'system-users', label: '操作员管理', path: '/system/users' },
          { key: 'system-roles', label: '角色权限', path: '/system/roles' },
        ],
      },
      {
        key: 'system-configuration',
        label: '系统配置',
        children: [
          { key: 'system-settings', label: '参数与字典', path: '/system/settings' },
          { key: 'system-integrations', label: '接口与集成', path: '/system/integrations' },
          { key: 'system-maintenance', label: '数据维护', path: '/system/maintenance' },
        ],
      },
      {
        key: 'system-security',
        label: '安全审计',
        children: [
          { key: 'system-logs', label: '日志审计', path: '/system/logs' },
        ],
      },
    ],
  },
];

export const quickLinks: NavItem[] = [
  { key: 'quick-personnel', label: '人员档案', path: '/card/personnel', icon: <TeamOutlined /> },
  { key: 'quick-consume', label: '消费流水', path: '/consume/records', icon: <ShoppingOutlined /> },
  { key: 'quick-attendance', label: '每日考勤', path: '/attendance/daily', icon: <ScheduleOutlined /> },
  { key: 'quick-monitor', label: '门禁监控', path: '/access/monitor', icon: <SafetyCertificateOutlined /> },
  { key: 'quick-orders', label: '订餐订单', path: '/meal/orders', icon: <CoffeeOutlined /> },
  { key: 'quick-visitor', label: '访客审批', path: '/visitor/approvals', icon: <AppstoreOutlined /> },
];

export function flattenNavigation(items: NavItem[] = navigation): NavItem[] {
  return items.flatMap((item) => [item, ...flattenNavigation(item.children ?? [])]);
}

export function findNavItem(pathname: string): NavItem | undefined {
  return flattenNavigation().find((item) => item.path === pathname);
}

export function getNavigationTrail(pathname: string): NavItem[] {
  const walk = (items: NavItem[], trail: NavItem[]): NavItem[] | undefined => {
    for (const item of items) {
      const nextTrail = [...trail, item];
      if (item.path === pathname) return nextTrail;
      const matched = item.children ? walk(item.children, nextTrail) : undefined;
      if (matched) return matched;
    }
    return undefined;
  };
  return walk(navigation, []) ?? [];
}

const descriptionMap: Record<string, string> = {
  人员档案: '统一维护人员资料、照片、人脸信息与部门归属，支持批量导入和条件查询。',
  部门管理: '维护组织机构与部门层级，配置部门数据权限和人员归属。',
  账户与卡: '管理账户余额、卡状态、有效期及挂失、补卡、销户等卡业务。',
  充值与取款: '处理充值、退款、取款及资金凭据，确保账户余额与流水一致。',
  补贴管理: '按人员、部门和补贴规则发放补贴，跟踪批次与到账结果。',
  消费流水: '查询终端消费明细、消费前后余额、餐别和订单信息。',
  异常与冲正: '处理异常流水、退款与冲正业务，保留完整审计记录。',
  消费终端: '维护消费机档案、终端参数和下发状态，查看在线与回收情况。',
  打卡记录: '查询人员打卡时间、考勤终端、识别方式和现场照片。',
  每日考勤: '查看每日出勤、迟到、早退和缺勤结果，支持异常核对。',
  补签审批: '集中处理补签申请与审批，审批结果自动回写考勤数据。',
  实时门禁监控: '实时掌握控制器、门状态和报警事件，执行受控远程操作。',
  通行记录: '查询正常与异常通行记录，按人员、门、时段和通行方式筛选。',
  异常事件: '处理非法闯入、门长时间未关和未授权尝试等门禁事件。',
  订餐订单: '统一查看个人订餐、代订和批量订餐订单及扣款状态。',
  取餐核销: '核验订餐订单与取餐状态，跟踪未用餐和异常核销记录。',
  访客预约: '管理访客预约、来访时间、被访人、随行人员与通行凭证。',
  访客审批: '处理访客预约审批、改期与驳回，并同步通知相关人员。',
  访客登记: '完成访客到访、离场、凭证发放和临时通行权限登记。',
  进出记录: '查询访客到访、离场与门禁通行记录，识别超时未离场情况。',
  操作员管理: '维护管理平台操作员、所属部门、状态与角色分配。',
  角色权限: '配置角色的菜单、操作按钮和数据范围权限。',
  参数与字典: '按业务域维护系统参数、数据字典与列表显示配置。',
  接口与集成: '管理硬件服务、人脸识别、微信平台、支付与短信集成配置。',
  数据维护: '执行数据备份、整理、同步与受控清理，记录维护结果。',
  日志审计: '查询登录、操作、接口与同步日志，追踪关键业务前后值。',
};

export function getModulePageMeta(pathname: string): ModulePageMeta | undefined {
  const trail = getNavigationTrail(pathname);
  const current = trail[trail.length - 1];
  if (!current?.path || pathname === '/dashboard') return undefined;
  const domain = trail[0]?.label ?? '业务管理';
  return {
    path: pathname,
    title: current.label,
    domain,
    description: descriptionMap[current.label] ?? `集中处理${domain}相关的${current.label}业务，提供统一查询、办理与统计入口。`,
    primaryAction: current.label.includes('报表') || current.label.includes('记录') || current.label.includes('流水') ? '导出数据' : `新增${current.label.replace('管理', '')}`,
  };
}

export function getAncestorKeys(pathname: string): string[] {
  return getNavigationTrail(pathname).slice(0, -1).map((item) => item.key);
}

/** 顶栏“业务域切换”下拉使用的业务域（不含工作台） */
export const domainSwitchEntries: NavItem[] = navigation.filter((item) => item.key !== 'dashboard');

const domainSwitchLabels: Record<string, string> = {
  extensions: '水控/巡更',
};

export function getDomainLabel(key: string): string {
  return domainSwitchLabels[key] ?? navigation.find((item) => item.key === key)?.label ?? key;
}

/** 取业务域下的第一个可访问页面路径 */
export function getFirstLeafPath(item: NavItem): string | undefined {
  if (item.path) return item.path;
  for (const child of item.children ?? []) {
    const path = getFirstLeafPath(child);
    if (path) return path;
  }
  return undefined;
}
