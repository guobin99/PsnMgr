const TOKEN_KEY = 'psn_access_token';
const USER_KEY = 'psn_user_name';

export function getAccessToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function saveLogin(userName: string): void {
  localStorage.setItem(TOKEN_KEY, 'demo-access-token');
  localStorage.setItem(USER_KEY, userName);
}

export function clearLogin(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

export function getUserName(): string {
  return localStorage.getItem(USER_KEY) || '系统管理员';
}
