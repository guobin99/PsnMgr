import { useEffect, useMemo, useState } from 'react';
import {
  App,
  Avatar,
  Badge,
  Breadcrumb,
  Button,
  Drawer,
  Dropdown,
  Form,
  Input,
  Layout,
  Menu,
  Modal,
  Space,
  Tag,
  Tooltip,
} from 'antd';
import type { MenuProps } from 'antd';
import {
  AppstoreOutlined,
  BellOutlined,
  CheckCircleOutlined,
  CheckOutlined,
  CloseOutlined,
  DownOutlined,
  ExpandOutlined,
  HomeOutlined,
  LockOutlined,
  LogoutOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  MoreOutlined,
  SearchOutlined,
  SettingOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import BrandLogo from '@/components/BrandLogo';
import {
  domainSwitchEntries,
  findNavItem,
  flattenNavigation,
  getAncestorKeys,
  getDomainLabel,
  getFirstLeafPath,
  getNavigationTrail,
  navigation,
} from '@/config/navigation';
import type { NavItem, PageTab } from '@/types/navigation';
import { clearLogin, getUserName } from '@/utils/auth';

const { Header, Sider, Content } = Layout;

interface NoticeItem {
  id: number;
  title: string;
  description: string;
  time: string;
  category: string;
  read: boolean;
}

const initialNotices: NoticeItem[] = [
  { id: 1, title: '访客预约待审批', description: '李明提交的访客预约等待您审批', time: '10 分钟前', category: '访客', read: false },
  { id: 2, title: '门禁异常事件提醒', description: '东门控制器发生 1 次未授权通行尝试', time: '32 分钟前', category: '门禁', read: false },
  { id: 3, title: '考勤数据计算完成', description: '昨日每日考勤数据已完成计算', time: '1 小时前', category: '考勤', read: false },
  { id: 4, title: '消费终端恢复在线', description: '二食堂 03 号消费机已恢复连接', time: '2 小时前', category: '设备', read: true },
];

function renderMenuLabel(item: NavItem) {
  return (
    <span className="menu-item-label">
      <span>{item.label}</span>
      {item.badge ? <span className="menu-item-badge">{item.badge}</span> : null}
    </span>
  );
}

function toMenuItems(items: NavItem[]): MenuProps['items'] {
  return items.map((item) => ({
    key: item.key,
    icon: item.icon,
    label: renderMenuLabel(item),
    children: item.children ? toMenuItems(item.children) : undefined,
  }));
}

export default function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { message, modal } = App.useApp();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [openKeys, setOpenKeys] = useState<string[]>([]);
  const [tabs, setTabs] = useState<PageTab[]>([{ key: '/dashboard', label: '工作台', closable: false }]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [notices, setNotices] = useState(initialNotices);
  const [profileOpen, setProfileOpen] = useState(false);
  const [passwordOpen, setPasswordOpen] = useState(false);

  const menuItems = useMemo(() => toMenuItems(navigation), []);
  const allPages = useMemo(() => flattenNavigation().filter((item) => item.path), []);
  const currentTrail = getNavigationTrail(location.pathname);
  const currentDomainKey = currentTrail[0] && currentTrail[0].key !== 'dashboard' ? currentTrail[0].key : undefined;
  const currentDomainLabel = currentDomainKey ? getDomainLabel(currentDomainKey) : '业务域切换';
  const domainSwitchItems = useMemo(
    () =>
      domainSwitchEntries.map((item) => ({
        key: item.key,
        icon: item.icon,
        label: (
          <span className={`domain-switch-item ${item.key === currentDomainKey ? 'is-active' : ''}`}>
            <span>{getDomainLabel(item.key)}</span>
            {item.key === currentDomainKey ? <CheckOutlined className="domain-switch-check" /> : null}
          </span>
        ),
      })),
    [currentDomainKey],
  );
  const selectedKey = findNavItem(location.pathname)?.key ?? '';
  const unreadCount = notices.filter((notice) => !notice.read).length;

  useEffect(() => {
    const media = window.matchMedia('(max-width: 992px)');
    const update = () => setIsMobile(media.matches);
    update();
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  useEffect(() => {
    const current = findNavItem(location.pathname);
    if (!current?.path) return;
    setTabs((previous) => {
      if (previous.some((tab) => tab.key === current.path)) return previous;
      return [...previous, { key: current.path!, label: current.label, closable: current.path !== '/dashboard' }];
    });
    setOpenKeys((previous) => Array.from(new Set([...previous, ...getAncestorKeys(location.pathname)])));
    setMobileOpen(false);
  }, [location.pathname]);

  const navigateTo = (path: string) => {
    navigate(path);
    setSearchOpen(false);
    setSearchText('');
  };

  const onMenuClick: MenuProps['onClick'] = ({ key }) => {
    const target = allPages.find((item) => item.key === key);
    if (target?.path) navigateTo(target.path);
  };

  const closeTab = (path: string) => {
    setTabs((previous) => {
      const index = previous.findIndex((tab) => tab.key === path);
      const next = previous.filter((tab) => tab.key !== path);
      if (location.pathname === path) {
        const target = next[Math.max(0, index - 1)] ?? next[0];
        navigate(target?.key ?? '/dashboard');
      }
      return next;
    });
  };

  const closeOtherTabs = () => {
    const current = findNavItem(location.pathname);
    const currentTab = current?.path
      ? { key: current.path, label: current.label, closable: current.path !== '/dashboard' }
      : undefined;
    setTabs((previous) => [previous[0], ...(currentTab && currentTab.key !== '/dashboard' ? [currentTab] : [])]);
  };

  const closeAllTabs = () => {
    setTabs([{ key: '/dashboard', label: '工作台', closable: false }]);
    navigate('/dashboard');
  };

  const toggleFullscreen = () => {
    if (document.fullscreenElement) {
      void document.exitFullscreen();
    } else {
      void document.documentElement.requestFullscreen();
    }
  };

  const handleUserMenu = ({ key }: { key: string }) => {
    if (key === 'profile') setProfileOpen(true);
    if (key === 'password') setPasswordOpen(true);
    if (key === 'logout') {
      modal.confirm({
        title: '确认退出登录？',
        content: '退出后需要重新验证身份才能进入管理平台。',
        okText: '退出登录',
        cancelText: '取消',
        onOk: () => {
          clearLogin();
          navigate('/login', { replace: true });
        },
      });
    }
  };

  const filteredPages = allPages.filter((item) => {
    const trail = getNavigationTrail(item.path!);
    const keyword = searchText.trim().toLowerCase();
    return !keyword || `${trail.map((entry) => entry.label).join(' ')} ${item.path}`.toLowerCase().includes(keyword);
  });

  const navigationMenu = (
    <Menu
      theme="dark"
      mode="inline"
      items={menuItems}
      selectedKeys={[selectedKey]}
      openKeys={openKeys}
      onOpenChange={(keys) => setOpenKeys(keys)}
      onClick={onMenuClick}
      className="sidebar-menu"
    />
  );

  const sidebarFooter = (
    <div className={`sidebar-status ${collapsed && !isMobile ? 'is-collapsed' : ''}`}>
      <span className="status-dot" />
      {!collapsed || isMobile ? (
        <div>
          <strong>服务运行正常</strong>
          <span>SQL Server · 硬件通讯服务</span>
        </div>
      ) : null}
    </div>
  );

  return (
    <Layout className="admin-shell">
      {!isMobile && (
        <Sider
          width={248}
          collapsedWidth={80}
          collapsed={collapsed}
          trigger={null}
          className="admin-sider"
        >
          <BrandLogo collapsed={collapsed} />
          <div className="sidebar-section-title">{collapsed ? '···' : '业务导航'}</div>
          <div className="sidebar-menu-scroll">{navigationMenu}</div>
          {sidebarFooter}
        </Sider>
      )}

      <Drawer
        placement="left"
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        width={280}
        closable={false}
        className="mobile-navigation"
        styles={{ body: { padding: 0, background: '#0c1729' } }}
      >
        <BrandLogo />
        <div className="sidebar-section-title">业务导航</div>
        {navigationMenu}
        {sidebarFooter}
      </Drawer>

      <Layout className="admin-main-layout">
        <Header className="admin-header">
          <div className="header-left">
            <Button
              type="text"
              className="header-icon-button"
              icon={isMobile ? <MenuUnfoldOutlined /> : collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
              onClick={() => (isMobile ? setMobileOpen(true) : setCollapsed(!collapsed))}
              aria-label="切换导航"
            />
            <Dropdown
              trigger={['click']}
              placement="bottomLeft"
              overlayClassName="domain-switch-overlay"
              menu={{
                items: domainSwitchItems,
                onClick: ({ key }) => {
                  const entry = domainSwitchEntries.find((item) => item.key === key);
                  const path = entry ? getFirstLeafPath(entry) : undefined;
                  if (path) navigateTo(path);
                },
              }}
            >
              <button className="domain-switch" aria-label="业务域切换">
                <AppstoreOutlined className="domain-switch-icon" />
                <span className="domain-switch-text">{currentDomainLabel}</span>
                <DownOutlined className="domain-switch-chevron" />
              </button>
            </Dropdown>
            <Breadcrumb
              className="header-breadcrumb"
              items={currentTrail.map((item) => ({ title: item.label }))}
            />
          </div>
          <div className="header-actions">
            <button className="global-search" onClick={() => setSearchOpen(true)}>
              <SearchOutlined className="global-search-icon" />
              <span className="global-search-text">搜索菜单与功能</span>
              <kbd>Ctrl K</kbd>
            </button>
            <Tooltip title="全屏显示">
              <Button type="text" className="header-icon-button desktop-action" icon={<ExpandOutlined />} onClick={toggleFullscreen} />
            </Tooltip>
            <Tooltip title="消息通知">
              <Badge count={unreadCount} size="small" offset={[-3, 5]}>
                <Button type="text" className="header-icon-button" icon={<BellOutlined />} onClick={() => setNoticeOpen(true)} />
              </Badge>
            </Tooltip>
            <span className="header-divider" />
            <Dropdown
              trigger={['click']}
              placement="bottomRight"
              menu={{
                onClick: handleUserMenu,
                items: [
                  { key: 'profile', icon: <UserOutlined />, label: '个人信息' },
                  { key: 'password', icon: <LockOutlined />, label: '修改密码' },
                  { key: 'settings', icon: <SettingOutlined />, label: '系统设置', onClick: () => navigateTo('/system/settings') },
                  { type: 'divider' },
                  { key: 'logout', icon: <LogoutOutlined />, label: '退出登录', danger: true },
                ],
              }}
            >
              <button className="user-entry">
                <Avatar size={36} className="user-avatar">管</Avatar>
                <span className="user-summary">
                  <strong>{getUserName()}</strong>
                  <small>超级管理员</small>
                </span>
                <DownOutlined className="user-chevron" />
              </button>
            </Dropdown>
          </div>
        </Header>

        <div className="workspace-tabs">
          <div className="tabs-scroll">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                className={`workspace-tab ${location.pathname === tab.key ? 'is-active' : ''}`}
                onClick={() => navigate(tab.key)}
              >
                {tab.key === '/dashboard' ? <HomeOutlined /> : <span className="tab-dot" />}
                <span>{tab.label}</span>
                {tab.closable && (
                  <span
                    role="button"
                    className="tab-close"
                    aria-label={`关闭${tab.label}`}
                    onClick={(event) => {
                      event.stopPropagation();
                      closeTab(tab.key);
                    }}
                  >
                    <CloseOutlined />
                  </span>
                )}
              </button>
            ))}
          </div>
          <Dropdown
            menu={{
              items: [
                { key: 'others', label: '关闭其他页签' },
                { key: 'all', label: '关闭全部页签' },
              ],
              onClick: ({ key }) => (key === 'others' ? closeOtherTabs() : closeAllTabs()),
            }}
          >
            <Button type="text" className="tabs-more" icon={<MoreOutlined />} />
          </Dropdown>
        </div>

        <Content className="admin-content">
          <Outlet />
        </Content>
        <footer className="admin-footer">
          <span>人脸通 BS 一体化管理平台</span>
          <span>数据同源 · CS / BS 平滑共存</span>
        </footer>
      </Layout>

      <Modal
        open={searchOpen}
        onCancel={() => {
          setSearchOpen(false);
          setSearchText('');
        }}
        footer={null}
        closable={false}
        width={600}
        className="search-modal"
      >
        <Input
          autoFocus
          size="large"
          prefix={<SearchOutlined />}
          placeholder="输入功能名称或路径，如：人员档案"
          value={searchText}
          onChange={(event) => setSearchText(event.target.value)}
          onPressEnter={() => filteredPages[0]?.path && navigateTo(filteredPages[0].path)}
        />
        <div className="search-result-caption">{searchText ? `找到 ${filteredPages.length} 个功能` : '常用功能与全部菜单'}</div>
        <div className="search-results">
          {filteredPages.slice(0, 8).map((item) => (
            <button key={item.key} className="search-result" onClick={() => navigateTo(item.path!)}>
              <span className="search-result-icon"><AppstoreOutlined /></span>
              <span>
                <strong>{item.label}</strong>
                <small>{getNavigationTrail(item.path!).slice(0, -1).map((entry) => entry.label).join(' / ')}</small>
              </span>
              <span className="search-enter">↵</span>
            </button>
          ))}
          {filteredPages.length === 0 && <div className="search-empty">未找到匹配的功能，请换个关键词</div>}
        </div>
      </Modal>

      <Drawer
        title="消息通知"
        open={noticeOpen}
        onClose={() => setNoticeOpen(false)}
        width={400}
        extra={<Button type="link" onClick={() => setNotices((previous) => previous.map((item) => ({ ...item, read: true })))}>全部已读</Button>}
      >
        <div className="notice-list">
          {notices.map((notice) => (
            <button
              key={notice.id}
              className={`notice-item ${notice.read ? 'is-read' : ''}`}
              onClick={() => setNotices((previous) => previous.map((item) => item.id === notice.id ? { ...item, read: true } : item))}
            >
              <span className="notice-icon"><BellOutlined /></span>
              <span className="notice-body">
                <span className="notice-title"><strong>{notice.title}</strong>{!notice.read && <i />}</span>
                <span>{notice.description}</span>
                <small><Tag>{notice.category}</Tag>{notice.time}</small>
              </span>
            </button>
          ))}
        </div>
      </Drawer>

      <Modal open={profileOpen} onCancel={() => setProfileOpen(false)} footer={<Button type="primary" onClick={() => setProfileOpen(false)}>知道了</Button>} title="个人信息">
        <div className="profile-card">
          <Avatar size={64} className="user-avatar">管</Avatar>
          <div><h3>{getUserName()}</h3><p>系统管理中心 · 超级管理员</p></div>
        </div>
        <div className="profile-details">
          <div><span>用户编号</span><strong>admin</strong></div>
          <div><span>数据权限</span><strong>全部部门</strong></div>
          <div><span>最近登录</span><strong>今天 08:32</strong></div>
          <div><span>账号状态</span><Tag icon={<CheckCircleOutlined />} color="success">正常</Tag></div>
        </div>
      </Modal>

      <Modal open={passwordOpen} onCancel={() => setPasswordOpen(false)} footer={null} title="修改密码" destroyOnClose>
        <Form
          layout="vertical"
          onFinish={() => {
            setPasswordOpen(false);
            message.success('密码修改成功（演示）');
          }}
        >
          <Form.Item name="oldPassword" label="当前密码" rules={[{ required: true, message: '请输入当前密码' }]}>
            <Input.Password prefix={<LockOutlined />} placeholder="请输入当前密码" />
          </Form.Item>
          <Form.Item name="newPassword" label="新密码" rules={[{ required: true, message: '请输入新密码' }, { min: 6, message: '密码至少 6 位' }]}>
            <Input.Password prefix={<LockOutlined />} placeholder="至少 6 位，建议包含数字与字母" />
          </Form.Item>
          <Form.Item
            name="confirmPassword"
            label="确认新密码"
            dependencies={['newPassword']}
            rules={[
              { required: true, message: '请再次输入新密码' },
              ({ getFieldValue }) => ({ validator: (_, value) => !value || getFieldValue('newPassword') === value ? Promise.resolve() : Promise.reject(new Error('两次输入的密码不一致')) }),
            ]}
          >
            <Input.Password prefix={<LockOutlined />} placeholder="请再次输入新密码" />
          </Form.Item>
          <Space className="modal-form-actions">
            <Button onClick={() => setPasswordOpen(false)}>取消</Button>
            <Button type="primary" htmlType="submit">确认修改</Button>
          </Space>
        </Form>
      </Modal>
    </Layout>
  );
}
