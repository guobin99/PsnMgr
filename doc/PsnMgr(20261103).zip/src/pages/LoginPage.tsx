import { useState } from 'react';
import { Button, Checkbox, Form, Input } from 'antd';
import { LockOutlined, SafetyCertificateOutlined, UserOutlined } from '@ant-design/icons';
import { useLocation, useNavigate } from 'react-router-dom';
import BrandLogo from '@/components/BrandLogo';
import { saveLogin } from '@/utils/auth';

interface LoginValues {
  username: string;
  password: string;
  remember: boolean;
}

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = useState(false);

  const onFinish = (values: LoginValues) => {
    setLoading(true);
    window.setTimeout(() => {
      saveLogin(values.username === 'admin' ? '系统管理员' : values.username);
      const from = (location.state as { from?: string } | null)?.from;
      navigate(from || '/dashboard', { replace: true });
      setLoading(false);
    }, 500);
  };

  return (
    <main className="login-page">
      <section className="login-brand-panel">
        <div className="login-brand"><BrandLogo /></div>
        <div className="login-brand-content">
          <span className="login-kicker"><SafetyCertificateOutlined />统一身份 · 统一数据 · 统一运营</span>
          <h1>一个平台，连接<br />人、卡、设备与场景</h1>
          <p>覆盖消费、考勤、门禁、订餐与访客业务，<br />让每一次识别都转化为高效管理。</p>
          <div className="login-feature-row">
            <div><strong>8+</strong><span>业务子系统</span></div>
            <div><strong>1</strong><span>同源数据库</span></div>
            <div><strong>24h</strong><span>实时服务</span></div>
          </div>
        </div>
        <div className="login-visual" aria-hidden="true">
          <div className="scan-frame"><UserOutlined /><i /></div>
          <span className="visual-chip chip-one">人脸识别</span>
          <span className="visual-chip chip-two">安全通行</span>
        </div>
        <footer>兼容 CS 业务基线 · 支持平滑过渡</footer>
      </section>

      <section className="login-form-panel">
        <div className="login-form-wrap">
          <div className="login-mobile-brand"><BrandLogo /></div>
          <div className="login-form-title">
            <span>WELCOME BACK</span>
            <h2>欢迎回来</h2>
            <p>登录人脸通 BS 一体化管理平台</p>
          </div>
          <Form<LoginValues>
            layout="vertical"
            initialValues={{ username: 'admin', password: '123456', remember: true }}
            onFinish={onFinish}
            requiredMark={false}
          >
            <Form.Item name="username" label="账号" rules={[{ required: true, message: '请输入登录账号' }]}>
              <Input size="large" prefix={<UserOutlined />} placeholder="请输入操作员账号" autoComplete="username" />
            </Form.Item>
            <Form.Item name="password" label="密码" rules={[{ required: true, message: '请输入登录密码' }]}>
              <Input.Password size="large" prefix={<LockOutlined />} placeholder="请输入登录密码" autoComplete="current-password" />
            </Form.Item>
            <div className="login-options">
              <Form.Item name="remember" valuePropName="checked" noStyle><Checkbox>记住登录状态</Checkbox></Form.Item>
              <Button type="link">忘记密码？</Button>
            </div>
            <Button type="primary" htmlType="submit" size="large" block loading={loading} className="login-submit">登录系统</Button>
          </Form>
          <div className="demo-account"><span>演示账号</span><code>admin</code><i>/</i><code>123456</code></div>
          <p className="login-security"><LockOutlined />请妥善保管账号，离开前及时退出系统</p>
        </div>
        <footer>© 2026 人脸通 · BS 一体化管理平台</footer>
      </section>
    </main>
  );
}
