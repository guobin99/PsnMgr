import type { ReactNode } from 'react';

export interface NavItem {
  key: string;
  label: string;
  path?: string;
  icon?: ReactNode;
  permission?: string;
  badge?: number;
  children?: NavItem[];
}

export interface PageTab {
  key: string;
  label: string;
  closable: boolean;
}

export interface ModulePageMeta {
  path: string;
  title: string;
  domain: string;
  description: string;
  primaryAction: string;
}
