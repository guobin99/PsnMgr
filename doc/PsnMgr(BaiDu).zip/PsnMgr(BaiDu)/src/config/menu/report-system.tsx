import type { NavNode } from '@/types/navigation';

/** 报表中心：跨业务域的综合运营报表与报表工具 */
export const reportDomain: NavNode = {
  key: 'report',
  label: '报表中心',
  permission: 'report:view',
  description: '跨业务域综合运营报表与报表模板、导出任务管理。',
  children: [
    {
      key: 'report-overview',
      label: '综合运营',
      description: '财务、消费、考勤、门禁与订餐的多维度综合报表。',
      children: [
        { key: 'report-dashboard', label: '运营总览', path: '/report/overview', permission: 'report:overview' },
        { key: 'report-finance', label: '财务综合报表', path: '/report/finance', permission: 'report:finance' },
        { key: 'report-consume', label: '消费综合报表', path: '/report/consume', permission: 'report:consume' },
        { key: 'report-attendance', label: '考勤综合报表', path: '/report/attendance', permission: 'report:attendance' },
        { key: 'report-access', label: '门禁综合报表', path: '/report/access', permission: 'report:access' },
        { key: 'report-meal', label: '订餐综合报表', path: '/report/meal', permission: 'report:meal' },
      ],
    },
    {
      key: 'report-tools',
      label: '报表工具',
      description: '报表模板配置、常用报表收藏与导出任务跟踪。',
      children: [
        { key: 'report-template', label: '报表模板', path: '/report/template', permission: 'report:template' },
        { key: 'report-favorite', label: '常用报表', path: '/report/favorite', permission: 'report:favorite' },
        { key: 'report-export-task', label: '导出任务', path: '/report/export-task', permission: 'report:exportTask' },
      ],
    },
  ],
};

/** 系统管理：操作员与权限、系统配置、安全审计 */
export const systemDomain: NavNode = {
  key: 'system',
  label: '系统管理',
  permission: 'system:view',
  description: '操作员与角色权限、系统参数与数据字典、第三方接口集成、安全审计日志。',
  children: [
    {
      key: 'system-org',
      label: '组织与权限',
      description: '沿用 CS 角色权限表：ST_UserInfo、ST_RoleInfo、ST_RoleRight、ST_RightInfo、ST_MenuInfo、ST_DeptRight、ST_MOCRight。',
      children: [
        { key: 'system-operator', label: '操作员管理', path: '/system/operator', permission: 'system:operator:view' },
        { key: 'system-role', label: '角色管理', path: '/system/role', permission: 'system:role:view' },
        { key: 'system-permission', label: '菜单与操作权限', path: '/system/permission', permission: 'system:permission:view' },
        { key: 'system-dept-right', label: '部门数据权限', path: '/system/dept-right', permission: 'system:deptRight:view' },
        { key: 'system-device-right', label: '设备权限', path: '/system/device-right', permission: 'system:deviceRight:view' },
        { key: 'system-subsystem-right', label: '子系统权限', path: '/system/subsystem-right', permission: 'system:subsystemRight:view' },
        { key: 'system-cashier-auth', label: '出纳授权管理', path: '/system/cashier-auth', permission: 'system:cashierAuth:view' },
      ],
    },
    {
      key: 'system-config',
      label: '系统配置',
      description: '系统参数、数据字典、接口与集成（微信、支付、短信、人脸）、数据维护与黑名单。',
      children: [
        { key: 'system-param', label: '系统参数', path: '/system/param', permission: 'system:param:view' },
        { key: 'system-dict', label: '数据字典', path: '/system/dict', permission: 'system:dict:view' },
        { key: 'system-integration', label: '接口与集成', path: '/system/integration', permission: 'system:integration:view', description: '管理微信支付、阿里云短信、人脸识别与硬件通讯服务的接入配置。' },
        { key: 'system-maintain', label: '数据维护', path: '/system/maintain', permission: 'system:maintain:view' },
        { key: 'system-blacklist', label: '黑名单管理', path: '/system/blacklist', permission: 'system:blacklist:view' },
      ],
    },
    {
      key: 'system-audit',
      label: '安全审计',
      description: '系统日志、登录日志、操作审计与同步日志，日志不可被普通角色修改或删除。',
      children: [
        { key: 'system-log-system', label: '系统日志', path: '/system/log/system', permission: 'system:log:system' },
        { key: 'system-log-login', label: '登录日志', path: '/system/log/login', permission: 'system:log:login' },
        { key: 'system-log-oper', label: '操作审计', path: '/system/log/oper', permission: 'system:log:oper' },
        { key: 'system-log-sync', label: '同步日志', path: '/system/log/sync', permission: 'system:log:sync' },
      ],
    },
  ],
};