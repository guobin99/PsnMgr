import type { NavNode } from '@/types/navigation';

/** 订餐管理（CS DC 子系统） */
export const mealDomain: NavNode = {
  key: 'meal',
  label: '订餐管理',
  permission: 'meal:view',
  description: '订餐基础设置、订餐业务处理与订餐/未用餐报表；扣款模式由 ST_SysParam 的 DC.Solution 控制。',
  children: [
    {
      key: 'meal-basic',
      label: '基础设置',
      description: '订餐参数、订餐机、订餐规则与时间、食堂菜品与餐别配置。',
      children: [
        { key: 'meal-param', label: '系统参数设置', path: '/meal/param', permission: 'meal:param:view', description: '维护 DC.Solution 扣款模式：1 为订餐扣款，0 为消费取餐扣款。' },
        { key: 'meal-terminal', label: '订餐机设置', path: '/meal/terminal', permission: 'meal:terminal:view' },
        { key: 'meal-rule', label: '订餐规则设置', path: '/meal/rule', permission: 'meal:rule:view' },
        { key: 'meal-time', label: '订餐时间设置', path: '/meal/time', permission: 'meal:time:view' },
        { key: 'meal-area', label: '食堂与区域', path: '/meal/area', permission: 'meal:area:view' },
        { key: 'meal-ware', label: '菜品与类别', path: '/meal/ware', permission: 'meal:ware:view' },
        { key: 'meal-daily-dish', label: '每日菜品', path: '/meal/daily-dish', permission: 'meal:dailyDish:view' },
        { key: 'meal-repast', label: '餐别设置', path: '/meal/repast', permission: 'meal:repast:view' },
      ],
    },
    {
      key: 'meal-business',
      label: '订餐业务',
      description: '订餐数据下载、控制台、手工订餐、撤销订餐、订单查询与取餐核销。',
      children: [
        { key: 'meal-download', label: '订餐数据下载', path: '/meal/download', permission: 'meal:download:view' },
        { key: 'meal-console', label: '订餐机控制台', path: '/meal/console', permission: 'meal:console:view' },
        { key: 'meal-manual', label: '手工订餐', path: '/meal/manual', permission: 'meal:manual:view' },
        { key: 'meal-cancel', label: '撤销订餐', path: '/meal/cancel', permission: 'meal:cancel:view' },
        { key: 'meal-order', label: '订餐订单', path: '/meal/order', permission: 'meal:order:view', description: '主表 DC_OrderData / SF_OrderData 与子表按 Order_No 关联；订餐扣款同时写入 XF_Consume。' },
        { key: 'meal-verify', label: '取餐核销', path: '/meal/verify', permission: 'meal:verify:view' },
      ],
    },
    {
      key: 'meal-report',
      label: '订餐报表',
      description: '订餐数据与未用餐的明细、汇总报表，报表与消费记录分开显示。',
      children: [
        { key: 'meal-report-detail', label: '订餐数据明细', path: '/meal/report/detail', permission: 'meal:report:detail' },
        { key: 'meal-report-summary', label: '订餐数据汇总', path: '/meal/report/summary', permission: 'meal:report:summary' },
        { key: 'meal-report-unused', label: '未用餐明细', path: '/meal/report/unused', permission: 'meal:report:unused' },
        { key: 'meal-report-unused-summary', label: '未用餐汇总', path: '/meal/report/unused-summary', permission: 'meal:report:unusedSummary' },
      ],
    },
    {
      key: 'meal-maintain',
      label: '系统维护',
      description: '订餐过期数据清理与历史归档。',
      children: [
        { key: 'meal-clean', label: '过期数据清理', path: '/meal/clean', permission: 'meal:clean:view' },
      ],
    },
  ],
};

/** 访客管理（CS MJ 访客相关菜单） */
export const visitorDomain: NavNode = {
  key: 'visitor',
  label: '访客管理',
  permission: 'visitor:view',
  description: '访客预约与审核、访客卡与签到登记、访客进出记录与报表。',
  children: [
    {
      key: 'visitor-apply',
      label: '预约与审批',
      description: '访客预约登记、预约审核与预约记录查询。',
      children: [
        { key: 'visitor-apply-add', label: '访客预约登记', path: '/visitor/apply', permission: 'visitor:apply:view' },
        { key: 'visitor-approve', label: '预约审核', path: '/visitor/approve', permission: 'visitor:approve:view', description: '处理 VisitorApply 预约单的审批、改期与驳回。' },
        { key: 'visitor-apply-record', label: '访客预约记录', path: '/visitor/apply-record', permission: 'visitor:applyRecord:view' },
      ],
    },
    {
      key: 'visitor-business',
      label: '访客业务',
      description: '访客卡登记、签到签离与临时通行权限发放。',
      children: [
        { key: 'visitor-card', label: '访客卡登记', path: '/visitor/card', permission: 'visitor:card:view' },
        { key: 'visitor-checkin', label: '访客签到签离', path: '/visitor/checkin', permission: 'visitor:checkin:view' },
        { key: 'visitor-access', label: '访客通行登记', path: '/visitor/access', permission: 'visitor:access:view' },
      ],
    },
    {
      key: 'visitor-record',
      label: '记录与报表',
      description: '访客签到记录、进出记录与访客统计报表。',
      children: [
        { key: 'visitor-checkin-record', label: '访客签到记录', path: '/visitor/checkin-record', permission: 'visitor:record:checkin' },
        { key: 'visitor-access-record', label: '访客进出记录', path: '/visitor/access-record', permission: 'visitor:record:access' },
        { key: 'visitor-report', label: '访客报表', path: '/visitor/report', permission: 'visitor:record:report' },
      ],
    },
    {
      key: 'visitor-setting',
      label: '参数设置',
      description: '访客系统参数、证件类型与超时未离场规则。',
      children: [
        { key: 'visitor-param', label: '访客参数设置', path: '/visitor/param', permission: 'visitor:param:view' },
      ],
    },
  ],
};

/** 水控（SK）与巡更（XG）扩展子系统 */
export const utilityDomain: NavNode = {
  key: 'utility',
  label: '水控/巡更',
  permission: 'utility:view',
  description: '水控卡类与终端、采集记录与用水汇总；巡更点线、计划与巡更日报。',
  children: [
    {
      key: 'utility-water',
      label: '水控管理',
      description: '水控卡类、终端、场合与补贴机配置，采集记录与用水汇总报表。',
      children: [
        { key: 'utility-water-card-type', label: '卡类设置', path: '/utility/water/card-type', permission: 'utility:water:cardType' },
        { key: 'utility-water-terminal', label: '终端机设置', path: '/utility/water/terminal', permission: 'utility:water:terminal' },
        { key: 'utility-water-area', label: '消费场合设置', path: '/utility/water/area', permission: 'utility:water:area' },
        { key: 'utility-water-subsidy', label: '水控补贴机', path: '/utility/water/subsidy', permission: 'utility:water:subsidy' },
        { key: 'utility-water-special-card', label: '特殊卡管理', path: '/utility/water/special-card', permission: 'utility:water:specialCard' },
        { key: 'utility-water-discount', label: '打折时段设置', path: '/utility/water/discount', permission: 'utility:water:discount' },
        { key: 'utility-water-site', label: '区域/场所设置', path: '/utility/water/site', permission: 'utility:water:site' },
        { key: 'utility-water-record', label: '采集记录', path: '/utility/water/record', permission: 'utility:water:record' },
        { key: 'utility-water-report', label: '采集数据汇总表', path: '/utility/water/report', permission: 'utility:water:report' },
      ],
    },
    {
      key: 'utility-patrol',
      label: '巡更管理',
      description: '巡更点与线路、巡更人员计划、巡更记录与日报、异常事件。',
      children: [
        { key: 'utility-patrol-site', label: '巡更点设置', path: '/utility/patrol/site', permission: 'utility:patrol:site' },
        { key: 'utility-patrol-route', label: '巡更线路设置', path: '/utility/patrol/route', permission: 'utility:patrol:route' },
        { key: 'utility-patrol-plan', label: '巡更人员与计划', path: '/utility/patrol/plan', permission: 'utility:patrol:plan' },
        { key: 'utility-patrol-record', label: '巡更记录', path: '/utility/patrol/record', permission: 'utility:patrol:record' },
        { key: 'utility-patrol-daily', label: '巡更日报', path: '/utility/patrol/daily', permission: 'utility:patrol:daily' },
        { key: 'utility-patrol-event', label: '巡更异常事件', path: '/utility/patrol/event', permission: 'utility:patrol:event' },
      ],
    },
  ],
};