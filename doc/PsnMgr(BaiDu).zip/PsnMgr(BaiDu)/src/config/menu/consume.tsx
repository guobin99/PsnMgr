import type { NavNode } from '@/types/navigation';

/** 消费管理（CS SF 售饭 / LH 灵活消费） */
export const consumeDomain: NavNode = {
  key: 'consume',
  label: '消费管理',
  permission: 'consume:view',
  description: '消费基础资料、消费业务处理、消费明细与汇总报表；终端下发与数据回收由 5501 消费服务端承担。',
  children: [
    {
      key: 'consume-basic',
      label: '基础资料',
      description: '食堂区域、餐别、菜谱菜品、打折类型、消费模式与终端档案配置。',
      children: [
        { key: 'consume-area', label: '区域/食堂设置', path: '/consume/area', permission: 'consume:area:view' },
        { key: 'consume-repast', label: '餐别设置', path: '/consume/repast', permission: 'consume:repast:view' },
        { key: 'consume-menu', label: '菜谱设置', path: '/consume/menu', permission: 'consume:menu:view' },
        { key: 'consume-daily-dish', label: '每日菜品设置', path: '/consume/daily-dish', permission: 'consume:dailyDish:view' },
        { key: 'consume-ware', label: '菜品与商品档案', path: '/consume/ware', permission: 'consume:ware:view' },
        { key: 'consume-discount', label: '打折类型设置', path: '/consume/discount', permission: 'consume:discount:view' },
        { key: 'consume-mode', label: '餐别消费模式设置', path: '/consume/mode', permission: 'consume:mode:view' },
        { key: 'consume-terminal', label: '终端机设置', path: '/consume/terminal', permission: 'consume:terminal:view' },
        { key: 'consume-keyvalue', label: '键值设置', path: '/consume/keyvalue', permission: 'consume:keyvalue:view' },
        { key: 'consume-biometric', label: '生物识别消费机管理', path: '/consume/biometric', permission: 'consume:biometric:view' },
      ],
    },
    {
      key: 'consume-business',
      label: '业务处理',
      description: '消费流水查询、纠错冲正、手工补消费与 U 盘数据导入。',
      children: [
        { key: 'consume-records', label: '消费流水', path: '/consume/records', permission: 'consume:record:view', description: '查询 XF_Consume 消费明细，含消费前余额、餐别、机台与订单号。' },
        { key: 'consume-correction', label: '消费纠错', path: '/consume/correction', permission: 'consume:correction:view' },
        { key: 'consume-manual', label: '手工补消费', path: '/consume/manual', permission: 'consume:manual:view' },
        { key: 'consume-import', label: 'U 盘导入消费', path: '/consume/import', permission: 'consume:import:view' },
        { key: 'consume-reversal', label: '异常与冲正', path: '/consume/reversal', permission: 'consume:reversal:view' },
      ],
    },
    {
      key: 'consume-detail',
      label: '明细报表',
      description: '按消费类型拆分的明细报表，字段口径与 CS 消耗报表一致。',
      children: [
        { key: 'consume-report-normal', label: '正常消费明细表', path: '/consume/report/normal', permission: 'consume:report:normal' },
        { key: 'consume-report-correction', label: '纠错与补消费明细表', path: '/consume/report/correction', permission: 'consume:report:correction' },
        { key: 'consume-report-abnormal', label: '异常消费记录明细表', path: '/consume/report/abnormal', permission: 'consume:report:abnormal' },
        { key: 'consume-report-time', label: '时长消费明细表', path: '/consume/report/time', permission: 'consume:report:time' },
        { key: 'consume-report-qrcode-log', label: '二维码支付日志', path: '/consume/report/qrcode-log', permission: 'consume:report:qrcodeLog' },
      ],
    },
    {
      key: 'consume-summary',
      label: '汇总报表',
      description: '按部门、人员、餐别、食堂与机台维度的消费汇总统计。',
      children: [
        { key: 'consume-summary-dept', label: '部门餐别汇总表', path: '/consume/summary/dept', permission: 'consume:summary:dept' },
        { key: 'consume-summary-person', label: '人员餐别汇总表', path: '/consume/summary/person', permission: 'consume:summary:person' },
        { key: 'consume-summary-repast', label: '餐别日报表', path: '/consume/summary/repast', permission: 'consume:summary:repast' },
        { key: 'consume-summary-moc', label: '机台餐别汇总表', path: '/consume/summary/moc', permission: 'consume:summary:moc' },
        { key: 'consume-summary-ware', label: '品种消费汇总表', path: '/consume/summary/ware', permission: 'consume:summary:ware' },
        { key: 'consume-summary-qrcode', label: '二维码消费汇总', path: '/consume/summary/qrcode', permission: 'consume:summary:qrcode' },
      ],
    },
  ],
};