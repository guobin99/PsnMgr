import type { NavNode } from '@/types/navigation';

/** 卡务中心（CS ST 子系统） */
export const cardDomain: NavNode = {
  key: 'card',
  label: '卡务中心',
  permission: 'card:view',
  description: '人员与账户主数据、卡业务与资金业务、出纳结算与财务报表。',
  children: [
    {
      key: 'card-org',
      label: '人员与组织',
      description: '统一维护人员档案、组织机构、编码规则与人脸照片，支持批量导入导出。',
      children: [
        { key: 'card-person', label: '人员档案', path: '/card/person', permission: 'card:person:view', description: '维护 ST_Person 人员资料、证件号、手机号、卡号与部门归属。' },
        { key: 'card-dept', label: '部门档案', path: '/card/dept', permission: 'card:dept:view' },
        { key: 'card-code', label: '编码管理', path: '/card/code', permission: 'card:code:view' },
        { key: 'card-face', label: '人脸照片库', path: '/card/face', permission: 'card:face:view', description: '管理 ST_PersonPhoto 人脸照片，自动审核通过后入库，超过 80K 先压缩。' },
        { key: 'card-import', label: '人员导入导出', path: '/card/import', permission: 'card:import:view' },
      ],
    },
    {
      key: 'card-account-group',
      label: '账户与卡',
      description: '账户开设与变更、卡状态与有效期管理、挂失补卡换卡及销户。',
      children: [
        { key: 'card-account', label: '账户信息设置', path: '/card/account', permission: 'card:account:view' },
        { key: 'card-account-type', label: '账户类别设置', path: '/card/account-type', permission: 'card:accountType:view' },
        { key: 'card-account-open', label: '开户与销户', path: '/card/account-open', permission: 'card:accountOpen:view' },
        { key: 'card-freeze', label: '账户冻结与解冻', path: '/card/freeze', permission: 'card:freeze:view' },
        { key: 'card-change', label: '换卡与补卡', path: '/card/card-change', permission: 'card:cardChange:view' },
        { key: 'card-loss', label: '卡挂失与解挂', path: '/card/card-loss', permission: 'card:cardLoss:view' },
        { key: 'card-import-id', label: '导入授权 ID 卡', path: '/card/card-import', permission: 'card:cardImport:view' },
        { key: 'card-personal', label: '个人账户', path: '/card/personal', permission: 'card:personal:view' },
      ],
    },
    {
      key: 'card-fund',
      label: '资金业务',
      description: '充值存款、取款、转账、补贴发放与支付订单管理，资金变动实时回写账户余额。',
      children: [
        { key: 'card-recharge', label: '充值存款', path: '/card/recharge', permission: 'card:recharge:view', description: '柜面充值、微信支付充值入账，写 ST_SupplyFund 并同步 ST_Card.Card_Balance。' },
        { key: 'card-withdraw', label: '用户取款', path: '/card/withdraw', permission: 'card:withdraw:view' },
        { key: 'card-transfer', label: '小金额转账', path: '/card/transfer', permission: 'card:transfer:view' },
        { key: 'card-subsidy', label: '补贴发放', path: '/card/subsidy', permission: 'card:subsidy:view' },
        { key: 'card-cashier-auth', label: '出纳授权', path: '/card/cashier-auth', permission: 'card:cashierAuth:view' },
        { key: 'card-pay-order', label: '支付订单与日志', path: '/card/pay-order', permission: 'card:payOrder:view', description: '查询微信支付订单、异步通知与接口收发日志，支持订单状态兜底查询。' },
      ],
    },
    {
      key: 'card-report',
      label: '结算与报表',
      description: '出纳结算与财务报表，口径与 CS 保持一致。',
      children: [
        { key: 'card-report-cashier', label: '会计出纳报表', path: '/card/report/cashier', permission: 'card:report:cashier' },
        { key: 'card-report-balance', label: '账户余额表', path: '/card/report/balance', permission: 'card:report:balance' },
        { key: 'card-report-card-state', label: '卡状态统计表', path: '/card/report/card-state', permission: 'card:report:cardState' },
        { key: 'card-report-fund-detail', label: '资金明细报表', path: '/card/report/fund-detail', permission: 'card:report:fundDetail' },
        { key: 'card-report-roster', label: '人员花名册', path: '/card/report/roster', permission: 'card:report:roster' },
      ],
    },
    {
      key: 'card-maintain',
      label: '日志与维护',
      description: '卡务业务日志、数据备份清理与黑名单管理。',
      children: [
        { key: 'card-log', label: '系统日志管理', path: '/card/log', permission: 'card:log:view' },
        { key: 'card-backup', label: '数据备份', path: '/card/backup', permission: 'card:backup:view' },
        { key: 'card-clean', label: '数据清理', path: '/card/clean', permission: 'card:clean:view' },
        { key: 'card-blacklist', label: '黑名单管理', path: '/card/blacklist', permission: 'card:blacklist:view' },
        { key: 'card-settlement', label: '财务结算', path: '/card/settlement', permission: 'card:settlement:view' },
      ],
    },
  ],
};