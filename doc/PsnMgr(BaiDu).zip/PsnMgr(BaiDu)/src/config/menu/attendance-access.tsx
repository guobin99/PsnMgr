import type { NavNode } from '@/types/navigation';

/** 考勤管理（CS KQ 子系统） */
export const attendanceDomain: NavNode = {
  key: 'attendance',
  label: '考勤管理',
  permission: 'attendance:view',
  description: '考勤规则与班次、考勤数据处理、请假加班异常处理与考勤报表。',
  children: [
    {
      key: 'attendance-basic',
      label: '基础设置',
      description: '账套、规则、假种、法定假、考勤机与人员考勤信息等基础配置。',
      children: [
        { key: 'attendance-account', label: '账套管理', path: '/attendance/account', permission: 'attendance:account:view', description: '维护 KQ_Account 账套，取数仅使用 Account_Flag = 0 的当前账套。' },
        { key: 'attendance-rule', label: '考勤规则', path: '/attendance/rule', permission: 'attendance:rule:view' },
        { key: 'attendance-leave-type', label: '假种定义', path: '/attendance/leave-type', permission: 'attendance:leaveType:view' },
        { key: 'attendance-holiday', label: '法定假定义', path: '/attendance/holiday', permission: 'attendance:holiday:view' },
        { key: 'attendance-terminal', label: '考勤机设置', path: '/attendance/terminal', permission: 'attendance:terminal:view' },
        { key: 'attendance-person', label: '人员考勤信息', path: '/attendance/person', permission: 'attendance:person:view' },
        { key: 'attendance-shift', label: '班次设置', path: '/attendance/shift', permission: 'attendance:shift:view' },
        { key: 'attendance-schedule', label: '安排班次', path: '/attendance/schedule', permission: 'attendance:schedule:view' },
      ],
    },
    {
      key: 'attendance-data',
      label: '考勤数据',
      description: '原始刷卡数据、外进外出数据与每日考勤结果，支持按账套期间自动落表。',
      children: [
        { key: 'attendance-download', label: '考勤数据下载', path: '/attendance/download', permission: 'attendance:download:view' },
        { key: 'attendance-raw', label: '原始刷卡数据', path: '/attendance/raw', permission: 'attendance:raw:view' },
        { key: 'attendance-out', label: '外进外出数据', path: '/attendance/out', permission: 'attendance:out:view' },
        { key: 'attendance-daily', label: '每日考勤', path: '/attendance/daily', permission: 'attendance:daily:view', description: '考勤日期晚于账套 Date_Bgn 时取 KQ_Daily，否则取 KQ_DailyHistory；无记录先触发每日考勤计算。' },
        { key: 'attendance-history', label: '历史考勤', path: '/attendance/history', permission: 'attendance:history:view' },
        { key: 'attendance-biometric', label: '生物识别考勤机管理', path: '/attendance/biometric', permission: 'attendance:biometric:view' },
      ],
    },
    {
      key: 'attendance-exception',
      label: '异常处理',
      description: '请假登记（含请假时间段）、班次调整、调休补班、加班登记与补出勤。',
      children: [
        { key: 'attendance-leave', label: '请假登记', path: '/attendance/leave', permission: 'attendance:leave:view', description: '请假记录必须包含起止时间段（精确到分钟），审批通过后回写每日考勤。' },
        { key: 'attendance-adjust', label: '班次调整', path: '/attendance/adjust', permission: 'attendance:adjust:view' },
        { key: 'attendance-makeup', label: '调休补班', path: '/attendance/makeup', permission: 'attendance:makeup:view' },
        { key: 'attendance-overtime', label: '加班登记', path: '/attendance/overtime', permission: 'attendance:overtime:view' },
        { key: 'attendance-makeup-card', label: '增补刷卡', path: '/attendance/makeup-card', permission: 'attendance:makeupCard:view' },
        { key: 'attendance-supplement', label: '补出勤补加班', path: '/attendance/supplement', permission: 'attendance:supplement:view' },
      ],
    },
    {
      key: 'attendance-photo',
      label: '拍照考勤机',
      description: '拍照考勤机照片对比、实时显示与参数配置。',
      children: [
        { key: 'attendance-photo-compare', label: '照片对比', path: '/attendance/photo-compare', permission: 'attendance:photo:compare' },
        { key: 'attendance-photo-realtime', label: '实时显示', path: '/attendance/photo-realtime', permission: 'attendance:photo:realtime' },
        { key: 'attendance-photo-config', label: '配置参数', path: '/attendance/photo-config', permission: 'attendance:photo:config' },
      ],
    },
    {
      key: 'attendance-report',
      label: '统计报表',
      description: '考勤日报、月报与年报。',
      children: [
        { key: 'attendance-report-daily', label: '考勤日报表', path: '/attendance/report/daily', permission: 'attendance:report:daily' },
        { key: 'attendance-report-month', label: '考勤月报表', path: '/attendance/report/month', permission: 'attendance:report:month' },
        { key: 'attendance-report-year', label: '考勤年报表', path: '/attendance/report/year', permission: 'attendance:report:year' },
      ],
    },
  ],
};

/** 门禁管理（CS MJ 子系统，含指纹门禁） */
export const accessDomain: NavNode = {
  key: 'access',
  label: '门禁管理',
  permission: 'access:view',
  description: '门禁设备与时段、通行授权与下发、联动控制、远程监控与通行记录查询。',
  children: [
    {
      key: 'access-device',
      label: '设备与时段',
      description: '控制器、门属性、门/人时段与进出权限方案配置。',
      children: [
        { key: 'access-controller', label: '控制器设置', path: '/access/controller', permission: 'access:controller:view' },
        { key: 'access-door', label: '门属性设置', path: '/access/door', permission: 'access:door:view' },
        { key: 'access-door-time', label: '门开关时段设置', path: '/access/door-time', permission: 'access:doorTime:view' },
        { key: 'access-door-special', label: '门特殊时段设置', path: '/access/door-special', permission: 'access:doorSpecial:view' },
        { key: 'access-psn-time', label: '人进出时段设置', path: '/access/psn-time', permission: 'access:psnTime:view' },
        { key: 'access-psn-special', label: '人特殊时段设置', path: '/access/psn-special', permission: 'access:psnSpecial:view' },
        { key: 'access-scheme', label: '进出权限方案管理', path: '/access/scheme', permission: 'access:scheme:view' },
        { key: 'access-extension-point', label: '扩展点设置', path: '/access/extension-point', permission: 'access:extensionPoint:view' },
      ],
    },
    {
      key: 'access-grant',
      label: '授权与下发',
      description: '人员门权限、凭证（卡/人脸/二维码/密码）授权与名单下发状态跟踪。',
      children: [
        { key: 'access-person', label: '人员设置', path: '/access/person', permission: 'access:person:view' },
        { key: 'access-permission', label: '门权限设置', path: '/access/permission', permission: 'access:permission:view', description: '为人员授权可通行门与时段，支持人脸、卡片、二维码、密码多种凭证。' },
        { key: 'access-super-card', label: '超级卡或密码', path: '/access/super-card', permission: 'access:superCard:view' },
        { key: 'access-card-add', label: '刷卡添加用户', path: '/access/card-add', permission: 'access:cardAdd:view' },
        { key: 'access-manage-card', label: '管理卡设置', path: '/access/manage-card', permission: 'access:manageCard:view' },
      ],
    },
    {
      key: 'access-control',
      label: '联动与控制',
      description: '控制器联动、报警输出、多门互锁、紧急群组、开门规则与会议管理。',
      children: [
        { key: 'access-linkage', label: '控制器联动设置', path: '/access/linkage', permission: 'access:linkage:view' },
        { key: 'access-alarm-out', label: '报警输出设置', path: '/access/alarm-out', permission: 'access:alarmOut:view' },
        { key: 'access-interlock', label: '多门互锁设置', path: '/access/interlock', permission: 'access:interlock:view' },
        { key: 'access-emergency', label: '紧急群组设置', path: '/access/emergency', permission: 'access:emergency:view' },
        { key: 'access-first-card', label: '首卡开门设置', path: '/access/first-card', permission: 'access:firstCard:view' },
        { key: 'access-multi-card', label: '多卡开门设置', path: '/access/multi-card', permission: 'access:multiCard:view' },
        { key: 'access-meeting', label: '会议管理', path: '/access/meeting', permission: 'access:meeting:view' },
        { key: 'access-dvs', label: 'DVS 联动', path: '/access/dvs', permission: 'access:dvs:view' },
      ],
    },
    {
      key: 'access-monitor',
      label: '远程监控',
      description: '门禁控制台、电子地图与地图实时监控、人脸识别终端监控。',
      children: [
        { key: 'access-console', label: '门禁控制台', path: '/access/console', permission: 'access:console:view' },
        { key: 'access-map-design', label: '电子地图设计', path: '/access/map-design', permission: 'access:map:design' },
        { key: 'access-map-monitor', label: '地图实时监控', path: '/access/map-monitor', permission: 'access:map:monitor' },
        { key: 'access-face-terminal', label: '人脸识别终端', path: '/access/face-terminal', permission: 'access:faceTerminal:view' },
      ],
    },
    {
      key: 'access-record',
      label: '记录查询',
      description: '正常与异常通行记录、报警事件记录；通行方式与异常原因取 MJ_EventInfo 名称。',
      children: [
        { key: 'access-record-normal', label: '正常通行记录', path: '/access/record/normal', permission: 'access:record:normal', description: '数据来源 MJ_NormalRecord，通行方式取 MJ_EventInfo.Event_Name。' },
        { key: 'access-record-abnormal', label: '异常通行记录', path: '/access/record/abnormal', permission: 'access:record:abnormal', description: '数据来源 MJ_AbnormRecord，异常原因取 MJ_EventInfo 维护的名称。' },
        { key: 'access-record-alarm', label: '报警事件记录', path: '/access/record/alarm', permission: 'access:record:alarm' },
        { key: 'access-record-realtime', label: '实时监控记录', path: '/access/record/realtime', permission: 'access:record:realtime' },
      ],
    },
    {
      key: 'access-finger',
      label: '指纹门禁',
      description: '指纹门禁时段、组别、开锁组合与生物识别门禁机管理。',
      children: [
        { key: 'access-finger-time', label: '时段设置', path: '/access/finger/time', permission: 'access:finger:time' },
        { key: 'access-finger-group', label: '时段组别设置', path: '/access/finger/group', permission: 'access:finger:group' },
        { key: 'access-finger-combo', label: '开锁组合设置', path: '/access/finger/combo', permission: 'access:finger:combo' },
        { key: 'access-finger-person', label: '人员时段设置', path: '/access/finger/person', permission: 'access:finger:person' },
        { key: 'access-finger-terminal', label: '生物识别门禁机管理', path: '/access/finger/terminal', permission: 'access:finger:terminal' },
      ],
    },
    {
      key: 'access-maintain',
      label: '系统维护',
      description: '门禁系统参数、扩展功能与过期数据清理。',
      children: [
        { key: 'access-param', label: '门禁系统参数', path: '/access/param', permission: 'access:param:view' },
        { key: 'access-extension', label: '扩展功能设置', path: '/access/extension', permission: 'access:extension:view' },
        { key: 'access-clean', label: '清理过期数据', path: '/access/clean', permission: 'access:clean:view' },
      ],
    },
  ],
};