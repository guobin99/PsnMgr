import {
  BarChartOutlined,
  CoffeeOutlined,
  DashboardOutlined,
  IdcardOutlined,
  SafetyCertificateOutlined,
  ScheduleOutlined,
  SettingOutlined,
  ShoppingCartOutlined,
  TeamOutlined,
  ThunderboltOutlined,
} from '@ant-design/icons';

import type { CrumbItem, DomainMeta, ModulePageMeta, NavNode, PermissionCode } from '@/types/navigation';
import { hasPermission } from '@/utils/permission';

import { accessDomain, attendanceDomain } from './menu/attendance-access';
import { cardDomain } from './menu/card';
import { consumeDomain } from './menu/consume';
import { mealDomain, utilityDomain, visitorDomain } from './menu/meal-visitor-utility';
import { reportDomain, systemDomain } from './menu/report-system';

/** 工作台：所有角色可见 */
export const dashboardNode: NavNode = {
  key: 'dashboard',
  label: '工作台',
  path: '/dashboard',
  icon: <DashboardOutlined />,
  permission: 'dashboard:view',
  description: '业务概览、常用功能快捷入口与系统运行状态。',
};

/** 九大业务域导航（对齐需求文档 4.1 与附录 B 的映射原则：业务域—子功能—操作三级） */
export const navigation: NavNode[] = [
  dashboardNode,
  { ...cardDomain, icon: <IdcardOutlined /> },
  { ...consumeDomain, icon: <ShoppingCartOutlined /> },
  { ...attendanceDomain, icon: <ScheduleOutlined /> },
  { ...accessDomain, icon: <SafetyCertificateOutlined /> },
  { ...mealDomain, icon: <CoffeeOutlined /> },
  { ...visitorDomain, icon: <TeamOutlined /> },
  { ...utilityDomain, icon: <ThunderboltOutlined /> },
  { ...reportDomain, icon: <BarChartOutlined /> },
  { ...systemDomain, icon: <SettingOutlined /> },
];

/** 逐个展开整棵导航树 */
export function flattenMenu(nodes: NavNode[] = navigation): NavNode[] {
  return nodes.flatMap((node) => [node, ...flattenMenu(node.children ?? [])]);
}

/** 仅展开可跳转的叶子节点 */
export function flattenLeaves(nodes: NavNode[] = navigation): NavNode[] {
  return nodes.flatMap((node) => (node.children?.length ? flattenLeaves(node.children) : [node]));
}

/** 按路径查找菜单节点 */
export function findNodeByPath(pathname: string): NavNode | undefined {
  return flattenMenu().find((node) => node.path === pathname);
}

/** 取得从业务域到当前节点的完整链路 */
export function getMenuTrail(pathname: string): NavNode[] {
  const walk = (nodes: NavNode[], trail: NavNode[]): NavNode[] | undefined => {
    for (const node of nodes) {
      const nextTrail = [...trail, node];
      if (node.path === pathname) return nextTrail;
      const matched = node.children ? walk(node.children, nextTrail) : undefined;
      if (matched) return matched;
    }
    return undefined;
  };
  return walk(navigation, []) ?? [];
}

/** 当前路径所属业务域 */
export function getDomainOf(pathname: string): NavNode | undefined {
  return getMenuTrail(pathname)[0];
}

/** 面包屑数据 */
export function getBreadcrumbs(pathname: string): CrumbItem[] {
  return getMenuTrail(pathname).map((node) => ({ key: node.key, label: node.label, path: node.path }));
}

/** 当前节点在菜单中的展开键（父级链路） */
export function getOpenKeys(pathname: string): string[] {
  return getMenuTrail(pathname)
    .slice(0, -1)
    .map((node) => node.key);
}

/** 按权限过滤导航树：父节点在全量子节点被过滤后自动隐藏 */
export function filterMenuByPermission(nodes: NavNode[], permissions: PermissionCode[]): NavNode[] {
  const result: NavNode[] = [];
  for (const node of nodes) {
    if (node.children?.length) {
      const children = filterMenuByPermission(node.children, permissions);
      if (children.length > 0) {
        result.push({ ...node, children });
      }
      continue;
    }
    if (!node.permission || hasPermission(permissions, node.permission)) {
      result.push(node);
    }
  }
  return result;
}

/** 九大业务域的入口信息，用于顶栏业务域切换 */
export function buildDomainEntries(nodes: NavNode[] = navigation): DomainMeta[] {
  return nodes
    .filter((node) => node.key !== 'dashboard')
    .map((node) => {
      const firstLeaf = flattenLeaves(node.children ?? [])[0];
      return {
        key: node.key,
        label: node.label,
        icon: node.icon,
        permission: node.permission ?? `${node.key}:view`,
        description: node.description ?? '',
        entryPath: firstLeaf?.path ?? '/dashboard',
      } satisfies DomainMeta;
    });
}

/** 占位页渲染所需的元信息 */
export function getModulePageMeta(pathname: string): ModulePageMeta | undefined {
  const trail = getMenuTrail(pathname);
  const current = trail[trail.length - 1];
  if (!current?.path || current.path === '/dashboard') return undefined;

  const domainNode = trail[0];
  const domainLabel = domainNode?.label ?? '业务管理';
  const groupLabel = trail.length > 2 ? trail[trail.length - 2]?.label : undefined;

  return {
    path: current.path,
    title: current.label,
    domain: domainLabel,
    description:
      current.description ??
      `统一办理「${current.label}」业务` +
        (groupLabel ? `（${groupLabel}）` : '') +
        `：支持多条件查询、批量操作、数据导出与权限化按钮，操作留痕可审计。`,
    primaryAction: /报表|明细|汇总|记录|日志|流水|查询/.test(current.label) ? '导出数据' : `新增${current.label}`,
    permission: current.permission,
  };
}

/** 全局菜单搜索索引 */
export function buildMenuSearchIndex(nodes: NavNode[] = navigation): { path: string; label: string; domain: string; trail: string }[] {
  const rows: { path: string; label: string; domain: string; trail: string }[] = [];
  const walk = (items: NavNode[], labels: string[]) => {
    for (const node of items) {
      const nextLabels = [...labels, node.label];
      if (node.path) {
        rows.push({
          path: node.path,
          label: node.label,
          domain: labels[0] ?? node.label,
          trail: nextLabels.join(' / '),
        });
      }
      if (node.children?.length) walk(node.children, nextLabels);
    }
  };
  walk(nodes, []);
  return rows;
}