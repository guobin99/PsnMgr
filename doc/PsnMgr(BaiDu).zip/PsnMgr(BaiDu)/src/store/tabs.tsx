import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

import type { TabItem } from '@/types/navigation';

const HOME_TAB: TabItem = {
  key: 'dashboard',
  path: '/dashboard',
  title: '工作台',
  domain: '首页',
  closable: false,
};

interface TabsContextValue {
  tabs: TabItem[];
  /** 打开（或激活）一个页签 */
  openTab: (tab: TabItem) => void;
  closeTab: (key: string) => TabItem[];
  closeOthers: (key: string) => void;
  closeAll: () => void;
  /** 关闭当前页签后应跳转的路径 */
  resolveAfterClose: (key: string) => string;
}

const TabsContext = createContext<TabsContextValue | null>(null);

export function TabsProvider({ children }: { children: ReactNode }) {
  const [tabs, setTabs] = useState<TabItem[]>([HOME_TAB]);

  const openTab = useCallback((tab: TabItem) => {
    setTabs((prev) => {
      const exists = prev.some((item) => item.key === tab.key);
      if (exists) {
        return prev.map((item) => (item.key === tab.key ? { ...item, path: tab.path, title: tab.title, domain: tab.domain } : item));
      }
      return [...prev, tab];
    });
  }, []);

  const closeTab = useCallback((key: string) => {
    let next: TabItem[] = [];
    setTabs((prev) => {
      next = prev.filter((item) => item.key !== key || !item.closable);
      if (next.length === 0) next = [HOME_TAB];
      return next;
    });
    return next;
  }, []);

  const closeOthers = useCallback((key: string) => {
    setTabs((prev) => prev.filter((item) => item.key === key || !item.closable));
  }, []);

  const closeAll = useCallback(() => {
    setTabs([HOME_TAB]);
  }, []);

  const resolveAfterClose = useCallback(
    (key: string) => {
      const index = tabs.findIndex((item) => item.key === key);
      if (index < 0) return HOME_TAB.path;
      const rest = tabs.filter((item) => item.key !== key);
      const neighbour = rest[index] ?? rest[index - 1] ?? HOME_TAB;
      return neighbour.path;
    },
    [tabs],
  );

  const value = useMemo<TabsContextValue>(
    () => ({ tabs, openTab, closeTab, closeOthers, closeAll, resolveAfterClose }),
    [tabs, openTab, closeTab, closeOthers, closeAll, resolveAfterClose],
  );

  return <TabsContext.Provider value={value}>{children}</TabsContext.Provider>;
}

export function useTabs(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error('useTabs 必须在 TabsProvider 内使用');
  }
  return context;
}

export { HOME_TAB };