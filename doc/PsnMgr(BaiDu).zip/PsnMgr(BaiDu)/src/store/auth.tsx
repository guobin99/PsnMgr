import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

import { loginRequest, logoutRequest } from '@/services/auth';
import { UNAUTHORIZED_EVENT } from '@/services/http';
import type { LoginPayload, SessionUser } from '@/types/navigation';
import { readStorage, removeStorage, STORAGE_KEYS, writeStorage } from '@/utils/storage';

interface AuthContextValue {
  token: string | null;
  user: SessionUser | null;
  isAuthenticated: boolean;
  /** 是否处于会话恢复中（用于首屏守卫） */
  initializing: boolean;
  login: (payload: LoginPayload) => Promise<SessionUser>;
  logout: () => Promise<void>;
  updateUser: (patch: Partial<SessionUser>) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() => readStorage<string | null>(STORAGE_KEYS.token, null));
  const [user, setUser] = useState<SessionUser | null>(() => readStorage<SessionUser | null>(STORAGE_KEYS.user, null));
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    setInitializing(false);
  }, []);

  const login = useCallback(async (payload: LoginPayload) => {
    const result = await loginRequest(payload);
    setToken(result.token);
    setUser(result.user);
    writeStorage(STORAGE_KEYS.token, result.token);
    writeStorage(STORAGE_KEYS.user, result.user);
    return result.user;
  }, []);

  const logout = useCallback(async () => {
    await logoutRequest();
    setToken(null);
    setUser(null);
    removeStorage(STORAGE_KEYS.token);
    removeStorage(STORAGE_KEYS.user);
  }, []);

  const updateUser = useCallback((patch: Partial<SessionUser>) => {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, ...patch };
      writeStorage(STORAGE_KEYS.user, next);
      return next;
    });
  }, []);

  useEffect(() => {
    const handleUnauthorized = () => {
      setToken(null);
      setUser(null);
      removeStorage(STORAGE_KEYS.token);
      removeStorage(STORAGE_KEYS.user);
    };
    window.addEventListener(UNAUTHORIZED_EVENT, handleUnauthorized);
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, handleUnauthorized);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ token, user, isAuthenticated: Boolean(token), initializing, login, logout, updateUser }),
    [token, user, initializing, login, logout, updateUser],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth 必须在 AuthProvider 内使用');
  }
  return context;
}