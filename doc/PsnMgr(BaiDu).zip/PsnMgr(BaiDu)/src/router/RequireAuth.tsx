import { Navigate, Outlet, useLocation } from 'react-router-dom';

import { useAuth } from '@/store/auth';

/**
 * 路由鉴权守卫：未登录时跳转登录页，并把来源路径写入 state.from，
 * 登录成功后由登录页读取该 state 原路返回。
 */
export default function RequireAuth() {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  return <Outlet />;
}