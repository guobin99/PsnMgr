import type { ReactNode } from 'react';
import { useLocation } from 'react-router-dom';

import { usePermission } from '@/hooks/usePermission';
import ForbiddenPage from '@/pages/ForbiddenPage';
import type { PermissionCode } from '@/types/navigation';

interface PermissionGateProps {
  /** 访问该页面所需的权限码；不传表示不做页面级校验 */
  permission?: PermissionCode;
  children: ReactNode;
}

/**
 * 页面级权限守卫：越权访问时不渲染任何业务内容，直接返回 403 结果页，
 * 与需求中「越权访问返回 403」的约定一致。
 */
export default function PermissionGate({ permission, children }: PermissionGateProps) {
  const { can } = usePermission();
  const location = useLocation();

  if (permission && !can(permission)) {
    return <ForbiddenPage inline required={permission} path={location.pathname} />;
  }

  return <>{children}</>;
}