import { BRAND } from '@/styles/theme';

export default function BrandLogo({ collapsed }: { collapsed: boolean }) {
  return (
    <div className="app-brand" style={{ paddingInline: collapsed ? 0 : 16, justifyContent: collapsed ? 'center' : 'flex-start' }}>
      <span className="app-brand__logo" aria-hidden>
        人
      </span>
      {!collapsed && (
        <span className="app-brand__text">
          <span className="app-brand__title">{BRAND.fullName}</span>
          <span className="app-brand__sub">Card · Consume · Access</span>
        </span>
      )}
    </div>
  );
}