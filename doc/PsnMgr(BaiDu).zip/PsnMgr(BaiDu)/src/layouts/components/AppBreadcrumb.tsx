import { Breadcrumb } from 'antd';
import { HomeOutlined } from '@ant-design/icons';
import { Link, useLocation } from 'react-router-dom';

import { getBreadcrumbs } from '@/config/menu';

export default function AppBreadcrumb() {
  const { pathname } = useLocation();
  const crumbs = getBreadcrumbs(pathname);

  const items = [
    {
      title: (
        <Link to="/dashboard">
          <HomeOutlined /> <span>首页</span>
        </Link>
      ),
    },
    ...crumbs.map((crumb, index) => ({
      title: crumb.path && index < crumbs.length - 1 ? <Link to={crumb.path}>{crumb.label}</Link> : <span>{crumb.label}</span>,
    })),
  ];

  return <Breadcrumb className="app-crumbs" items={items} />;
}