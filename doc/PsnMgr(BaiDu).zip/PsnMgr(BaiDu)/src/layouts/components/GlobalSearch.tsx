import { useMemo, useState } from 'react';
import { Dropdown, Input, type MenuProps } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';

import { buildMenuSearchIndex } from '@/config/menu';
import type { NavNode } from '@/types/navigation';

interface GlobalSearchProps {
  /** 已按权限过滤的菜单树，保证只能搜到有权限的页面 */
  tree: NavNode[];
}

export default function GlobalSearch({ tree }: GlobalSearchProps) {
  const navigate = useNavigate();
  const [keyword, setKeyword] = useState('');
  const [open, setOpen] = useState(false);

  const index = useMemo(() => buildMenuSearchIndex(tree), [tree]);

  const matched = useMemo(() => {
    const trimmed = keyword.trim().toLowerCase();
    if (!trimmed) return [];
    // 命中结果按链路层级数升序排列（层级浅、更接近业务域的节点优先），同层级保持索引原序
    return index
      .filter((row) => row.trail.toLowerCase().includes(trimmed))
      .sort((a, b) => a.trail.split(' / ').length - b.trail.split(' / ').length)
      .slice(0, 8);
  }, [index, keyword]);

  const menu: MenuProps = {
    items: matched.map((row) => ({
      key: row.path,
      label: (
        <div style={{ lineHeight: 1.45, maxWidth: 320 }}>
          <div style={{ fontWeight: 500 }}>{row.label}</div>
          <div className="text-muted" style={{ fontSize: 12 }}>
            {row.trail}
          </div>
        </div>
      ),
    })),
    onClick: ({ key }) => {
      navigate(String(key));
      setKeyword('');
      setOpen(false);
    },
  };

  return (
    <Dropdown
      open={open && matched.length > 0}
      menu={menu}
      trigger={['click']}
      placement="bottomLeft"
      onOpenChange={(next) => setOpen(next)}
    >
      <Input
        allowClear
        value={keyword}
        prefix={<SearchOutlined style={{ color: '#94a3b8' }} />}
        placeholder="搜索菜单 / 功能（如：充值、考勤日报）"
        style={{ width: 260 }}
        onChange={(event) => {
          setKeyword(event.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => window.setTimeout(() => setOpen(false), 180)}
      />
    </Dropdown>
  );
}