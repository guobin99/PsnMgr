import { useMemo } from 'react';
import { Badge, Dropdown, Tooltip, type MenuProps } from 'antd';
import {
  AppstoreOutlined,
  BellOutlined,
  DownOutlined,
  ExpandOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  ReloadOutlined,
} from '@ant-design/icons';
import { useLocation, useNavigate } from 'react-router-dom';

import { buildDomainEntries } from '@/config/menu';
import type { NavNode } from '@/types/navigation';

import GlobalSearch from './GlobalSearch';
import UserMenu from './UserMenu';

interface HeaderBarProps {
  collapsed: boolean;
  onToggle: () => void;
  /** 已按权限过滤的菜单树 */
  tree: NavNode[];
}

export default function HeaderBar({ collapsed, onToggle, tree }: HeaderBarProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const domains = useMemo(() => {
    const visibleDomainKeys = new Set(tree.filter((node) => node.key !== 'dashboard').map((node) => node.key));
    return buildDomainEntries(tree).filter((domain) => visibleDomainKeys.has(domain.key));
  }, [tree]);

  const currentDomain = domains.find((domain) => location.pathname.startsWith(`/${domain.key}`));

  const domainMenu: MenuProps = {
    items: domains.map((domain) => ({ key: domain.key, icon: domain.icon, label: domain.label })),
    onClick: ({ key }) => {
      const domain = domains.find((item) => item.key === key);
      if (domain) navigate(domain.entryPath);
    },
  };

  return (
    <div className="app-header-bar">
      <span className="app-header__trigger" onClick={onToggle} aria-label="折叠菜单">
        {collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
      </span>

      <Dropdown menu={domainMenu} trigger={['click']}>
        <span className="app-header__action app-header__domain">
          <AppstoreOutlined />
          <span style={{ fontSize: 13, fontWeight: 500 }}>{currentDomain?.label ?? '业务域切换'}</span>
          <DownOutlined style={{ fontSize: 10, color: '#94a3b8' }} />
        </span>
      </Dropdown>

      <span className="app-header__spacer" />

      <GlobalSearch tree={tree} />

      <Tooltip title="刷新当前页">
        <span
          className="app-header__trigger"
          onClick={() => navigate(`${location.pathname}${location.search}`, { replace: true })}
        >
          <ReloadOutlined />
        </span>
      </Tooltip>

      <Tooltip title="全屏显示">
        <span
          className="app-header__trigger"
          onClick={() => {
            const doc = document;
            if (doc.fullscreenElement) {
              void doc.exitFullscreen?.().catch(() => undefined);
              return;
            }
            // 浏览器不支持或用户拒绝时静默失败，不打断操作
            void doc.documentElement.requestFullscreen?.().catch(() => undefined);
          }}
        >
          <ExpandOutlined />
        </span>
      </Tooltip>

      <Tooltip title="待办与通知">
        <span className="app-header__trigger">
          <Badge count={6} size="small" offset={[2, -2]}>
            <BellOutlined />
          </Badge>
        </span>
      </Tooltip>

      <UserMenu />
    </div>
  );
}