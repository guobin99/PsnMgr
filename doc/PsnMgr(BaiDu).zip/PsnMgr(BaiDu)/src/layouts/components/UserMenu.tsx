import { useMemo } from 'react';
import { Avatar, Dropdown, Space, Tag, type MenuProps } from 'antd';
import { DownOutlined, LogoutOutlined, QuestionCircleOutlined, SettingOutlined, UserOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';

import { useAuth } from '@/store/auth';

export default function UserMenu() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const items = useMemo<MenuProps['items']>(
    () => [
      { key: 'profile', icon: <UserOutlined />, label: '个人信息' },
      { key: 'settings', icon: <SettingOutlined />, label: '账号设置' },
      { key: 'help', icon: <QuestionCircleOutlined />, label: '帮助与文档' },
      { type: 'divider' },
      { key: 'logout', icon: <LogoutOutlined />, label: '退出登录', danger: true },
    ],
    [],
  );

  const onClick: MenuProps['onClick'] = async ({ key }) => {
    if (key === 'logout') {
      await logout();
      navigate('/login', { replace: true });
      return;
    }
    navigate('/403?from=personal-center');
  };

  return (
    <Dropdown menu={{ items, onClick }} placement="bottomRight" trigger={['click']}>
      <span className="app-header__action">
        <Avatar size={28} style={{ background: '#2f6fed' }} icon={<UserOutlined />} />
        <Space size={6}>
          <span style={{ fontSize: 13, fontWeight: 500 }}>{user?.displayName ?? '未登录'}</span>
          <Tag color="blue" style={{ marginInlineEnd: 0, fontSize: 11, lineHeight: '18px' }}>
            {user?.roleName ?? '访客'}
          </Tag>
        </Space>
        <DownOutlined style={{ fontSize: 10, color: '#94a3b8' }} />
      </span>
    </Dropdown>
  );
}