import { useMemo } from 'react';
import { Dropdown, Tabs, type MenuProps } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import { useLocation, useNavigate } from 'react-router-dom';

import { useTabs } from '@/store/tabs';

export default function TabsBar() {
  const { tabs, closeTab, closeOthers, closeAll, resolveAfterClose } = useTabs();
  const navigate = useNavigate();
  const location = useLocation();

  const activeKey = useMemo(
    () => tabs.find((tab) => tab.path === location.pathname)?.key ?? location.pathname,
    [tabs, location.pathname],
  );

  const items = tabs.map((tab) => ({
    key: tab.key,
    label: (
      <span>
        {tab.title}
        <span className="text-muted" style={{ marginInlineStart: 6, fontSize: 11 }}>
          {tab.domain}
        </span>
      </span>
    ),
    closable: tab.closable,
  }));

  const menuItems: MenuProps['items'] = [
    { key: 'others', label: '关闭其他页签' },
    { key: 'all', label: '关闭全部页签' },
    { key: 'refresh', label: '刷新当前页签' },
  ];

  const onMenuClick: MenuProps['onClick'] = ({ key }) => {
    if (key === 'others') {
      closeOthers(activeKey);
      return;
    }
    if (key === 'all') {
      closeAll();
      navigate('/dashboard');
      return;
    }
    navigate(location.pathname, { replace: true });
  };

  return (
    <div className="app-tabsbar">
      <Tabs
        type="editable-card"
        hideAdd
        size="small"
        activeKey={activeKey}
        items={items}
        onChange={(key) => {
          const target = tabs.find((tab) => tab.key === key);
          if (target) navigate(target.path);
        }}
        onEdit={(targetKey, action) => {
          if (action !== 'remove') return;
          const key = String(targetKey);
          const nextPath = resolveAfterClose(key);
          const closingActive = key === activeKey;
          closeTab(key);
          if (closingActive) navigate(nextPath);
        }}
      />
      <Dropdown menu={{ items: menuItems, onClick: onMenuClick }} trigger={['click']}>
        <span className="app-header__action" style={{ height: 28, padding: '0 8px' }}>
          <DownOutlined style={{ fontSize: 10 }} />
        </span>
      </Dropdown>
    </div>
  );
}