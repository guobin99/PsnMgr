import { useEffect, useMemo, useState } from 'react';
import { Menu, type MenuProps } from 'antd';
import { useLocation, useNavigate } from 'react-router-dom';

import { flattenMenu } from '@/config/menu';
import type { NavNode } from '@/types/navigation';

type MenuItem = Required<MenuProps>['items'][number];

/** 关键词过滤：命中叶子即保留，父节点在存在命中子节点时保留 */
function filterByKeyword(nodes: NavNode[], keyword: string): NavNode[] {
  const trimmed = keyword.trim().toLowerCase();
  if (!trimmed) return nodes;

  const result: NavNode[] = [];
  for (const node of nodes) {
    if (node.children?.length) {
      const children = filterByKeyword(node.children, trimmed);
      if (children.length > 0) {
        result.push({ ...node, children });
      }
      continue;
    }
    if (node.label.toLowerCase().includes(trimmed)) {
      result.push(node);
    }
  }
  return result;
}

function toMenuItems(nodes: NavNode[]): MenuItem[] {
  return nodes.map((node) => {
    const base = { key: node.key, label: node.label, icon: node.icon } as MenuItem;
    if (node.children?.length) {
      return { ...base, children: toMenuItems(node.children) } as MenuItem;
    }
    return base;
  });
}

function collectAncestorKeys(nodes: NavNode[], pathname: string, trail: string[] = []): string[] {
  for (const node of nodes) {
    const nextTrail = [...trail, node.key];
    if (node.path === pathname) return nextTrail.slice(0, -1);
    if (node.children?.length) {
      const matched = collectAncestorKeys(node.children, pathname, nextTrail);
      if (matched.length > 0) return matched;
    }
  }
  return [];
}

interface SideMenuProps {
  /** 已按权限过滤的菜单树 */
  tree: NavNode[];
  collapsed: boolean;
  keyword?: string;
  onNavigate?: (path: string) => void;
}

export default function SideMenu({ tree, collapsed, keyword = '', onNavigate }: SideMenuProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const nodeMap = useMemo(() => {
    const map = new Map<string, NavNode>();
    flattenMenu(tree).forEach((node) => map.set(node.key, node));
    return map;
  }, [tree]);

  const selectedKey = useMemo(() => {
    const matched = flattenMenu(tree).find((node) => node.path === location.pathname);
    return matched?.key ?? location.pathname;
  }, [tree, location.pathname]);

  const [openKeys, setOpenKeys] = useState<string[]>(() => collectAncestorKeys(tree, location.pathname));

  useEffect(() => {
    const ancestors = collectAncestorKeys(tree, location.pathname);
    if (ancestors.length > 0) {
      setOpenKeys((prev) => Array.from(new Set([...prev, ...ancestors])));
    }
  }, [tree, location.pathname]);

  const items = useMemo(() => toMenuItems(filterByKeyword(tree, keyword)), [tree, keyword]);

  const handleClick: MenuProps['onClick'] = ({ key }) => {
    const target = nodeMap.get(String(key));
    if (target?.path) {
      navigate(target.path);
      onNavigate?.(target.path);
    }
  };

  return (
    <Menu
      theme="dark"
      mode="inline"
      items={items}
      selectedKeys={[selectedKey]}
      openKeys={collapsed ? undefined : openKeys}
      onOpenChange={(keys) => setOpenKeys(keys as string[])}
      onClick={handleClick}
      inlineIndent={16}
    />
  );
}