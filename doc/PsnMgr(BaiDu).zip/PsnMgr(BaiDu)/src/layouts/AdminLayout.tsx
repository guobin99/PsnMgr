import { useEffect, useMemo, useState } from 'react';
import { Input, Layout } from 'antd';
import { useLocation, useOutlet } from 'react-router-dom';

import { filterMenuByPermission, findNodeByPath, getDomainOf, navigation } from '@/config/menu';
import { useAuth } from '@/store/auth';
import { useTabs } from '@/store/tabs';
import { readStorage, STORAGE_KEYS, writeStorage } from '@/utils/storage';

import AppBreadcrumb from './components/AppBreadcrumb';
import BrandLogo from './components/BrandLogo';
import HeaderBar from './components/HeaderBar';
import SideMenu from './components/SideMenu';
import TabsBar from './components/TabsBar';

const { Content, Header, Sider } = Layout;

export default function AdminLayout() {
  const outlet = useOutlet();
  const location = useLocation();
  const { user } = useAuth();
  const { openTab } = useTabs();

  // 用户自身的折叠偏好（持久化），与断点造成的临时折叠分开维护
  const [collapsed, setCollapsed] = useState<boolean>(() => readStorage<boolean>(STORAGE_KEYS.collapsed, false));
  // 视口是否处于 lg 断点以下：低于断点强制折叠，恢复后回到用户偏好
  const [belowBreakpoint, setBelowBreakpoint] = useState(false);
  const [keyword, setKeyword] = useState('');

  const effectiveCollapsed = collapsed || belowBreakpoint;

  const permissions = useMemo(() => user?.permissions ?? [], [user]);
  const menuTree = useMemo(() => filterMenuByPermission(navigation, permissions), [permissions]);

  useEffect(() => {
    writeStorage(STORAGE_KEYS.collapsed, collapsed);
  }, [collapsed]);

  // 路由变化时同步多页签
  useEffect(() => {
    const node = findNodeByPath(location.pathname);
    if (!node?.path) return;
    openTab({
      key: node.key,
      path: node.path,
      title: node.label,
      domain: getDomainOf(node.path)?.label ?? '业务管理',
      closable: node.path !== '/dashboard',
    });
  }, [location.pathname, openTab]);

  return (
    <Layout className="app-shell">
      <Sider
        className="app-sider"
        theme="dark"
        width={240}
        collapsedWidth={64}
        collapsed={effectiveCollapsed}
        breakpoint="lg"
        trigger={null}
        onBreakpoint={setBelowBreakpoint}
      >
        <BrandLogo collapsed={effectiveCollapsed} />
        {!effectiveCollapsed && (
          <div className="app-sider__search">
            <Input
              allowClear
              size="small"
              value={keyword}
              placeholder="筛选菜单"
              onChange={(event) => setKeyword(event.target.value)}
            />
          </div>
        )}
        <div className="app-sider__menu">
          <SideMenu tree={menuTree} collapsed={effectiveCollapsed} keyword={keyword} onNavigate={() => setKeyword('')} />
        </div>
        <div className="app-sider__footer">v1.0.0 · 与 CS 并行运行</div>
      </Sider>

      <Layout>
        <Header className="app-header">
          <HeaderBar collapsed={effectiveCollapsed} onToggle={() => setCollapsed((prev) => !prev)} tree={menuTree} />
        </Header>
        <TabsBar />
        <Content className="app-content">
          <AppBreadcrumb />
          {outlet}
        </Content>
      </Layout>
    </Layout>
  );
}