import { useMemo } from 'react';

import { useAuth } from '@/store/auth';
import type { PermissionCode } from '@/types/navigation';
import { hasAnyPermission, hasPermission } from '@/utils/permission';

/** 权限判定 Hook：按角色权限渲染菜单与操作按钮 */
export function usePermission() {
  const { user } = useAuth();
  const permissions = useMemo<PermissionCode[]>(() => user?.permissions ?? [], [user]);

  return useMemo(
    () => ({
      permissions,
      can: (code?: PermissionCode) => hasPermission(permissions, code),
      canAny: (codes: PermissionCode[]) => hasAnyPermission(permissions, codes),
    }),
    [permissions],
  );
}