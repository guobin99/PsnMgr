import type { ReactNode } from 'react';

/** 权限码：采用「业务域:资源:操作」三段式，如 card:account:view */
export type PermissionCode = string;

/** 导航节点：分组节点仅含 children，叶子节点含 path */
export interface NavNode {
  /** 唯一键，用于菜单展开态、页签与权限匹配 */
  key: string;
  /** 菜单名称 */
  label: string;
  /** 叶子节点路由路径 */
  path?: string;
  icon?: ReactNode;
  /** 访问所需权限码；未设置表示继承父节点 */
  permission?: PermissionCode;
  /** 菜单右侧角标（待办数量等） */
  badge?: number;
  /** 页面说明，用于占位页与页面标题 */
  description?: string;
  /** 是否在菜单中隐藏（如详情页） */
  hidden?: boolean;
  children?: NavNode[];
}

/** 业务域元信息 */
export interface DomainMeta {
  key: string;
  label: string;
  icon: ReactNode;
  permission: PermissionCode;
  description: string;
  /** 业务域入口路径（第一个叶子节点） */
  entryPath: string;
}

/** 面包屑条目 */
export interface CrumbItem {
  key: string;
  label: string;
  path?: string;
}

/** 多页签条目 */
export interface TabItem {
  /** 与菜单节点 key 一致，保证同一页面只开一个页签 */
  key: string;
  path: string;
  title: string;
  domain: string;
  closable: boolean;
}

/** 占位页渲染元信息 */
export interface ModulePageMeta {
  path: string;
  title: string;
  domain: string;
  description: string;
  primaryAction: string;
  permission?: PermissionCode;
}

/** 登录用户 */
export interface SessionUser {
  userId: string;
  userName: string;
  displayName: string;
  roleNo: string;
  roleName: string;
  deptName: string;
  /** 权限码集合，支持 * 与前缀通配（如 card:*） */
  permissions: PermissionCode[];
}

/** 登录结果 */
export interface LoginPayload {
  userName: string;
  password: string;
}

export interface LoginResult {
  token: string;
  user: SessionUser;
}