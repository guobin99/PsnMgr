import { App as AntdApp, ConfigProvider } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import dayjs from 'dayjs';
import 'dayjs/locale/zh-cn';

import AppRouter from '@/router';
import { AuthProvider } from '@/store/auth';
import { TabsProvider } from '@/store/tabs';
import { antdTheme } from '@/styles/theme';

dayjs.locale('zh-cn');

export default function App() {
  return (
    <ConfigProvider locale={zhCN} theme={antdTheme}>
      <AntdApp>
        <AuthProvider>
          <TabsProvider>
            <AppRouter />
          </TabsProvider>
        </AuthProvider>
      </AntdApp>
    </ConfigProvider>
  );
}