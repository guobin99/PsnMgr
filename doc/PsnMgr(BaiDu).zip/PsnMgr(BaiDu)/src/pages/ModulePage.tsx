import { useMemo } from 'react';
import { Alert, Button, Card, DatePicker, Descriptions, Empty, Input, Row, Col, Select, Space, Table, Tag, Tooltip } from 'antd';
import { DownloadOutlined, PlusOutlined, ReloadOutlined, SearchOutlined } from '@ant-design/icons';
import { useLocation } from 'react-router-dom';

import { getDomainOf, getMenuTrail, getModulePageMeta } from '@/config/menu';
import { usePermission } from '@/hooks/usePermission';
import { describePermission } from '@/utils/permission';

interface PlaceholderRow {
  key: string;
  name: string;
  scope: string;
  status: string;
  updatedAt: string;
}

/** 占位示例数据：接口接入后由后端分页返回 */
function buildRows(title: string, domainLabel: string): PlaceholderRow[] {
  return [1, 2, 3, 4, 5].map((index) => ({
    key: String(index),
    name: `${title}示例数据 ${String(index).padStart(2, '0')}`,
    scope: domainLabel,
    status: index % 3 === 0 ? '待完善' : '已启用',
    updatedAt: '2026-11-01 09:00',
  }));
}

export default function ModulePage() {
  const { pathname } = useLocation();
  const meta = useMemo(() => getModulePageMeta(pathname), [pathname]);
  const trail = useMemo(() => getMenuTrail(pathname), [pathname]);
  const { can } = usePermission();

  if (!meta) {
    return <Empty description="未找到对应的功能页面，请从左侧菜单重新进入" />;
  }

  const domainNode = getDomainOf(pathname);
  const groupLabel = trail.length > 2 ? trail[trail.length - 2]?.label : undefined;

  /** 操作权限：查看权限 <资源>:view 对应派生 <资源>:edit */
  const editPermission = meta.permission?.endsWith(':view')
    ? `${meta.permission.slice(0, -':view'.length)}:edit`
    : meta.permission;
  const canEdit = can(editPermission);

  const columns = [
    { title: '序号', dataIndex: 'key', width: 70 },
    { title: '名称', dataIndex: 'name' },
    { title: '归属', dataIndex: 'scope', width: 140 },
    {
      title: '状态',
      dataIndex: 'status',
      width: 110,
      render: (value: string) => (
        <Tag color={value === '已启用' ? 'success' : 'warning'} style={{ marginInlineEnd: 0 }}>
          {value}
        </Tag>
      ),
    },
    { title: '更新时间', dataIndex: 'updatedAt', width: 160 },
    {
      title: '操作',
      key: 'action',
      width: 150,
      render: () =>
        canEdit ? (
          <Space size={4}>
            <Button type="link" size="small">
              查看
            </Button>
            <Button type="link" size="small">
              编辑
            </Button>
          </Space>
        ) : (
          <Tooltip title="当前角色无操作权限">
            <span className="text-muted" style={{ fontSize: 12 }}>
              仅可查看
            </span>
          </Tooltip>
        ),
    },
  ];

  return (
    <Space direction="vertical" size={12} style={{ display: 'flex' }}>
      <div className="module-page__hero">
        <span className="module-page__hero-icon">{domainNode?.icon}</span>
        <div style={{ flex: 1 }}>
          <h2 className="module-page__title">{meta.title}</h2>
          <div className="text-muted" style={{ fontSize: 13 }}>
            {meta.description}
          </div>
          <div className="module-page__tags">
            <Tag color="blue" style={{ marginInlineEnd: 0 }}>
              {meta.domain}
            </Tag>
            {groupLabel && (
              <Tag color="geekblue" style={{ marginInlineEnd: 0 }}>
                {groupLabel}
              </Tag>
            )}
            <Tag style={{ marginInlineEnd: 0 }}>权限码 {meta.permission ?? '未设置'}</Tag>
            <Tag color={canEdit ? 'green' : 'default'} style={{ marginInlineEnd: 0 }}>
              {canEdit ? '可查询 / 可操作' : '仅可查询'}
            </Tag>
          </div>
        </div>
      </div>

      <Card title="查询条件" size="small">
        <Row gutter={[12, 12]} align="middle">
          <Col xs={24} sm={12} lg={6}>
            <Input allowClear placeholder={`搜索${meta.title}名称 / 编号`} prefix={<SearchOutlined />} />
          </Col>
          <Col xs={24} sm={12} lg={6}>
            <Select
              allowClear
              style={{ width: '100%' }}
              placeholder="状态"
              options={[
                { value: 'enabled', label: '已启用' },
                { value: 'disabled', label: '已停用' },
                { value: 'pending', label: '待完善' },
              ]}
            />
          </Col>
          <Col xs={24} sm={12} lg={8}>
            <DatePicker.RangePicker style={{ width: '100%' }} />
          </Col>
          <Col xs={24} sm={12} lg={4}>
            <Space>
              <Button type="primary" icon={<SearchOutlined />}>
                查询
              </Button>
              <Button icon={<ReloadOutlined />}>重置</Button>
            </Space>
          </Col>
        </Row>
      </Card>

      <Card
        size="small"
        title={meta.title}
        extra={
          <Space>
            {canEdit && (
              <Button type="primary" icon={<PlusOutlined />}>
                {meta.primaryAction}
              </Button>
            )}
            <Button icon={<DownloadOutlined />}>导出数据</Button>
          </Space>
        }
      >
        <Alert
          type="info"
          showIcon
          style={{ marginBottom: 12 }}
          message="布局与导航阶段的占位页面"
          description={`本页已接入路由、面包屑、多页签与权限校验，业务表格与表单将在后续阶段按需求文档第 5 章「${meta.domain}」的取数规则与字段口径实现。`}
        />
        <Table<PlaceholderRow>
          rowKey="key"
          size="small"
          columns={columns}
          dataSource={buildRows(meta.title, meta.domain)}
          pagination={{ pageSize: 10, showSizeChanger: false, showTotal: (total) => `共 ${total} 条（占位数据）` }}
        />
      </Card>

      <Card size="small" title="接口与集成约定">
        <Descriptions
          size="small"
          column={2}
          items={[
            { key: 'route', label: '前端路由', children: pathname },
            { key: 'permission', label: '页面权限码', children: meta.permission ?? '未设置' },
            {
              key: 'permission-desc',
              label: '权限含义',
              children: meta.permission ? describePermission(meta.permission) : '未设置',
            },
            { key: 'api', label: '后端接口建议', children: `GET /api${pathname}` },
            { key: 'schema', label: '权限模型', children: 'ST_UserInfo / ST_RoleInfo / ST_RoleRight / ST_RightInfo / ST_MenuInfo' },
            { key: 'degrade', label: '越权处理', children: '无权限时返回 403 结果页，不渲染业务内容' },
          ]}
        />
      </Card>
    </Space>
  );
}