import { useMemo } from 'react';
import { Alert, Card, Col, Row, Space, Statistic, Table, Tag } from 'antd';
import { ArrowRightOutlined, ClockCircleOutlined, ThunderboltOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router-dom';

import { buildDomainEntries } from '@/config/menu';
import { usePermission } from '@/hooks/usePermission';
import { useAuth } from '@/store/auth';

interface StatItem {
  key: string;
  label: string;
  value: number;
  suffix: string;
  precision?: number;
  hint: string;
}

interface ActivityRow {
  key: string;
  time: string;
  module: string;
  action: string;
  operator: string;
  result: '成功' | '待补充' | '失败';
}

/** 演示数据：接口接入后由后端统计接口（消费汇总 / 充值汇总 / 考勤异常 / 门禁通行）返回 */
const statItems: StatItem[] = [
  { key: 'consume', label: '今日消费笔数', value: 1286, suffix: '笔', hint: '消费管理 · XF_Consume 当日汇总' },
  { key: 'consume-fund', label: '今日消费金额', value: 9860.5, suffix: '元', precision: 2, hint: '消费管理 · 含各食堂与机台' },
  { key: 'supply', label: '今日充值金额', value: 12400, suffix: '元', precision: 2, hint: '卡务中心 · ST_SupplyFund 当日入账' },
  { key: 'exception', label: '今日考勤异常', value: 7, suffix: '人次', hint: '考勤管理 · 迟到 / 缺卡 / 早退' },
];

const activities: ActivityRow[] = [
  { key: '1', time: '09:12', module: '卡务中心', action: '柜面充值 200.00 元（现金）', operator: '张明', result: '成功' },
  { key: '2', time: '09:35', module: '消费管理', action: '午餐消费 12.50 元 · 三号机台', operator: '系统', result: '成功' },
  { key: '3', time: '10:02', module: '门禁管理', action: '异常通行补录（异常原因：卡失效）', operator: '王强', result: '待补充' },
  { key: '4', time: '10:41', module: '订餐管理', action: '晚餐订餐 2 项菜品（订餐扣款）', operator: '李慧', result: '成功' },
  { key: '5', time: '11:08', module: '考勤管理', action: '请假登记（08:30 — 12:00）', operator: '李慧', result: '成功' },
];

const todoItems = [
  { key: '1', title: '待审核人脸照片 6 张', desc: '卡务中心 · 人脸照片库', level: 'warning' as const },
  { key: '2', title: '消费纠错待复核 2 笔', desc: '消费管理 · 异常与冲正', level: 'error' as const },
  { key: '3', title: '访客预约待确认 3 条', desc: '访客管理 · 预约审批', level: 'processing' as const },
  { key: '4', title: '待发放补贴批次 1 个', desc: '卡务中心 · 补贴发放', level: 'default' as const },
];

export default function DashboardPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { can, permissions } = usePermission();

  const domains = useMemo(() => buildDomainEntries().filter((domain) => can(domain.permission)), [can]);

  const columns = [
    { title: '时间', dataIndex: 'time', width: 90 },
    { title: '业务模块', dataIndex: 'module', width: 120 },
    { title: '业务动作', dataIndex: 'action' },
    { title: '操作员', dataIndex: 'operator', width: 100 },
    {
      title: '结果',
      dataIndex: 'result',
      width: 100,
      render: (value: ActivityRow['result']) => (
        <Tag color={value === '成功' ? 'success' : value === '失败' ? 'error' : 'warning'} style={{ marginInlineEnd: 0 }}>
          {value}
        </Tag>
      ),
    },
  ];

  return (
    <Space direction="vertical" size={12} style={{ display: 'flex' }}>
      <Card>
        <Row align="middle" gutter={16}>
          <Col flex="auto">
            <Space direction="vertical" size={4}>
              <span style={{ fontSize: 20, fontWeight: 600 }}>
                {dayjs().format('YYYY年MM月DD日')}，{user?.displayName ?? '访客'}，欢迎回来
              </span>
              <span className="text-muted" style={{ fontSize: 13 }}>
                归属部门：{user?.deptName ?? '-'}　当前角色：{user?.roleName ?? '-'}　
                已授权权限码 {permissions.length === 1 && permissions[0] === '*' ? '全部' : permissions.length} 项
              </span>
            </Space>
          </Col>
          <Col>
            <Tag color="blue" style={{ marginInlineEnd: 0 }}>
              {dayjs().format('dddd')}
            </Tag>
          </Col>
        </Row>
      </Card>

      <Alert
        type="info"
        showIcon
        message="工作台数据为演示数据"
        description="统计卡片、待办与业务动态将于后端 RESTful 接口接入后替换为实时数据；当前数值仅用于验证布局与导航结构。"
      />

      <Row gutter={[12, 12]}>
        {statItems.map((item) => (
          <Col key={item.key} xs={24} sm={12} lg={6}>
            <Card size="small" className="stat-card">
              <span className="stat-card__label">{item.label}</span>
              <Statistic
                value={item.value}
                precision={item.precision}
                suffix={item.suffix}
                valueStyle={{ fontSize: 24, fontWeight: 600 }}
              />
              <div className="text-muted" style={{ fontSize: 12 }}>
                {item.hint}
              </div>
            </Card>
          </Col>
        ))}
      </Row>

      <Row gutter={[12, 12]}>
        <Col xs={24} xl={15}>
          <Card
            title="业务域快捷入口"
            extra={
              <span className="text-muted" style={{ fontSize: 12 }}>
                仅显示当前角色有权访问的业务域
              </span>
            }
          >
            <Row gutter={[12, 12]}>
              {domains.map((domain) => (
                <Col key={domain.key} xs={24} sm={12} lg={8}>
                  <Card size="small" hoverable onClick={() => navigate(domain.entryPath)}>
                    <Space align="start" size={10}>
                      <span
                        className="module-page__hero-icon"
                        style={{ width: 34, height: 34, flex: '0 0 34px', fontSize: 16, boxShadow: 'none' }}
                      >
                        {domain.icon}
                      </span>
                      <span>
                        <div style={{ fontWeight: 600 }}>
                          {domain.label} <ArrowRightOutlined style={{ fontSize: 11, color: '#94a3b8' }} />
                        </div>
                        <div className="text-muted" style={{ fontSize: 12 }}>
                          {domain.description}
                        </div>
                      </span>
                    </Space>
                  </Card>
                </Col>
              ))}
            </Row>
          </Card>
        </Col>

        <Col xs={24} xl={9}>
          <Card
            title="待办与提醒"
            extra={
              <span className="text-muted" style={{ fontSize: 12 }}>
                <ClockCircleOutlined /> 演示数据
              </span>
            }
          >
            <Space direction="vertical" size={8} style={{ display: 'flex' }}>
              {todoItems.map((item) => (
                <div key={item.key} className="todo-row">
                  <Tag color={item.level} style={{ marginInlineEnd: 8 }}>
                    {item.title.split(' ')[0]}
                  </Tag>
                  <span style={{ fontSize: 13 }}>{item.title}</span>
                  <div className="text-muted" style={{ fontSize: 12 }}>
                    {item.desc}
                  </div>
                </div>
              ))}
            </Space>
          </Card>
        </Col>
      </Row>

      <Card
        title="最近业务动态"
        extra={
          <span className="text-muted" style={{ fontSize: 12 }}>
            <ThunderboltOutlined /> 演示数据 · 接口接入后取操作审计日志
          </span>
        }
      >
        <Table<ActivityRow> rowKey="key" size="small" columns={columns} dataSource={activities} pagination={false} />
      </Card>
    </Space>
  );
}