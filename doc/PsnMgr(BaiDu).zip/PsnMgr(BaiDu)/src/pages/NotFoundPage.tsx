import { Button, Result, Space } from 'antd';
import { useLocation, useNavigate } from 'react-router-dom';

export default function NotFoundPage() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <Result
      status="404"
      title="404"
      subTitle={
        <Space direction="vertical" size={4}>
          <span>页面「{location.pathname}」不存在或已调整，请从左侧菜单重新进入。</span>
        </Space>
      }
      extra={
        <Space>
          <Button type="primary" onClick={() => navigate('/dashboard')}>
            返回工作台
          </Button>
          <Button onClick={() => navigate(-1)}>返回上一页</Button>
        </Space>
      }
    />
  );
}