import type { PermissionCode } from '@/types/navigation';

/**
 * 权限码匹配：支持完全匹配、全局通配 *、以及前缀通配（如 card:* 命中 card:person:view）
 * 权限数据来自 CS 角色权限表（ST_RoleRight / ST_RightInfo / ST_MenuInfo）的映射结果。
 */
export function hasPermission(permissions: PermissionCode[], required?: PermissionCode): boolean {
  if (!required) return true;
  if (!permissions.length) return false;

  return permissions.some((grant) => {
    if (grant === '*' || grant === required) return true;
    if (grant.endsWith(':*')) {
      return required.startsWith(grant.slice(0, -1));
    }
    return false;
  });
}

/** 是否具备任意一个权限码 */
export function hasAnyPermission(permissions: PermissionCode[], required: PermissionCode[]): boolean {
  return required.some((code) => hasPermission(permissions, code));
}

/** 权限码转展示文案，便于排查：card:person:view -> 卡务中心·人员档案·查看 */
export function describePermission(code: PermissionCode): string {
  return code.replace(/:/g, ' · ');
}