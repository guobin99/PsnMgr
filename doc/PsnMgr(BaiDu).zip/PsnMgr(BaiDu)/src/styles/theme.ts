import type { ThemeConfig } from 'antd';

/** 全站主色：与登录页、侧边栏渐变保持一致 */
export const BRAND = {
  name: '人脸通',
  fullName: '人脸通 · BS 管理平台',
  primary: '#2f6fed',
  primaryDark: '#1d4ed8',
  teal: '#12b3a6',
  siderBg: '#0f1c33',
  siderBgLight: '#ffffff',
  version: 'v1.0.0',
} as const;

export const antdTheme: ThemeConfig = {
  token: {
    colorPrimary: BRAND.primary,
    colorInfo: BRAND.primary,
    colorSuccess: '#16a34a',
    colorWarning: '#f59e0b',
    colorError: '#e5484d',
    borderRadius: 6,
    fontSize: 14,
    fontFamily:
      '"PingFang SC", "Microsoft YaHei", "Helvetica Neue", "Segoe UI", Roboto, Arial, sans-serif',
    colorBgLayout: '#f4f6fa',
  },
  components: {
    Layout: {
      headerBg: '#ffffff',
      headerHeight: 56,
      headerPadding: '0 16px',
      bodyBg: '#f4f6fa',
      siderBg: BRAND.siderBg,
    },
    Menu: {
      darkItemBg: BRAND.siderBg,
      darkSubMenuItemBg: '#0a1526',
      darkItemSelectedBg: BRAND.primary,
      darkItemHoverBg: 'rgba(255, 255, 255, 0.08)',
      itemHeight: 40,
      itemMarginInline: 8,
      iconSize: 16,
    },
    Table: {
      headerBg: '#f7f9fc',
      headerColor: '#334155',
      rowHoverBg: '#f5f8ff',
    },
    Card: {
      headerFontSize: 15,
    },
    Tabs: {
      cardGutter: 4,
    },
  },
};