import { buildDemoUser, DEMO_PASSWORD, demoAccounts, type DemoAccount } from '@/config/roles';
import type { LoginPayload, LoginResult, SessionUser } from '@/types/navigation';

import { ApiError, post } from './http';

const DEMO_LOGIN_ENABLED = import.meta.env.VITE_ENABLE_DEMO_LOGIN === 'true';

function normalizeLoginResult(raw: LoginResult | { token: string; user?: SessionUser }): LoginResult {
  if (!raw?.token || !raw.user) {
    throw new ApiError('登录接口返回数据不完整', 'BAD_RESPONSE');
  }
  return { token: raw.token, user: raw.user };
}

/** 演示账号离线登录：后端未就绪时保证前端布局与导航可独立验收 */
function demoLogin(payload: LoginPayload): LoginResult {
  const account: DemoAccount | undefined = demoAccounts.find((item) => item.userName === payload.userName.trim());
  if (!account || payload.password !== DEMO_PASSWORD) {
    throw new ApiError('账号或密码错误（演示账号密码为 123456）', 'AUTH_FAILED');
  }
  const user = buildDemoUser(account);
  if (!user) {
    throw new ApiError('演示角色配置缺失', 'ROLE_NOT_FOUND');
  }
  return { token: `demo-token.${account.userName}.${Date.now()}`, user };
}

/**
 * 登录：优先调用 .NET RESTful 后端 /api/auth/login，
 * 开发环境（VITE_ENABLE_DEMO_LOGIN=true）在后端不可用时回退到本地演示角色。
 */
export async function loginRequest(payload: LoginPayload): Promise<LoginResult> {
  try {
    const data = await post<LoginResult>('/auth/login', payload);
    return normalizeLoginResult(data);
  } catch (error) {
    if (!DEMO_LOGIN_ENABLED) throw error;
    if (error instanceof ApiError && (error.code === 'AUTH_FAILED' || error.code === 'BAD_RESPONSE')) {
      throw error;
    }
    return demoLogin(payload);
  }
}

/** 拉取当前登录用户与权限（后端不可用时保留本地会话） */
export async function fetchProfileRequest(): Promise<SessionUser> {
  return post<SessionUser>('/auth/profile');
}

export async function logoutRequest(): Promise<void> {
  try {
    await post<void>('/auth/logout');
  } catch {
    /* 退出登录失败不阻塞前端会话清理 */
  }
}

export { DEMO_LOGIN_ENABLED };