# 人脸通 · BS 管理平台（前端布局与导航）

基于 **React 18 + TypeScript + Vite + Ant Design 5** 的人脸通 BS 一体化管理平台前端，本阶段交付范围为
**布局（Layout）与导航（Navigation）**：登录页、主框架、多级菜单、面包屑、多页签、路由组织与权限框架。

后端为 .NET RESTful API（开发期默认 `http://localhost:5187`），数据库沿用 CS 的 SQL Server 结构（只增不删）。

## 技术栈

| 类别 | 选型 |
| --- | --- |
| 框架 | React 18.3 + TypeScript 5.6 |
| 构建 | Vite 5.4（路径别名 `@` → `src`，`/api` 开发代理） |
| UI | Ant Design 5.29 + @ant-design/icons |
| 路由 | react-router-dom 6（BrowserRouter + 嵌套路由 + 懒加载） |
| 请求 | axios（统一返回体 `{ code, message, data }`，401/403 统一拦截） |
| 状态 | React Context（会话 `store/auth`、多页签 `store/tabs`），不额外引入状态库 |
| 时间 | dayjs（中文 locale） |

## 快速开始

```bash
npm install          # 安装依赖（Node 18+，已验证 Node 22 / npm 10）
npm run dev          # 开发调试：http://127.0.0.1:5273
npm run typecheck    # 类型检查（tsc --noEmit）
npm run build        # 生产构建（tsc --noEmit && vite build，产物在 dist/）
npm run preview      # 预览生产构建
```

开发环境变量（`.env.development`）：

| 变量 | 说明 |
| --- | --- |
| `VITE_API_BASE_URL` | 前端请求前缀，默认 `/api`（经 Vite 代理转发） |
| `VITE_PROXY_TARGET` | 代理目标，默认 `http://localhost:5187`（PsnMgrService 的 http profile） |
| `VITE_ENABLE_DEMO_LOGIN` | `true` 时后端不可用可回退到本地演示账号；生产环境须为 `false` |

## 目录结构

```
src/
├─ config/
│  ├─ menu.tsx                     # 导航树总装：九大业务域 + 派生工具（面包屑、搜索索引、占位页元信息）
│  ├─ menu/
│  │  ├─ card.tsx                  # 卡务中心
│  │  ├─ consume.tsx               # 消费管理
│  │  ├─ attendance-access.tsx     # 考勤管理 / 门禁管理
│  │  ├─ meal-visitor-utility.tsx  # 订餐管理 / 访客管理 / 水控巡更
│  │  └─ report-system.tsx         # 报表中心 / 系统管理
│  └─ roles.ts                     # 角色权限映射与演示账号（正式环境由后端下发）
├─ layouts/
│  ├─ AdminLayout.tsx              # 主框架：侧边菜单 + 顶栏 + 多页签 + 内容区路由出口
│  └─ components/                  # BrandLogo / SideMenu / HeaderBar / GlobalSearch / UserMenu / AppBreadcrumb / TabsBar
├─ router/
│  ├─ index.tsx                    # 路由总装：登录路由、鉴权守卫、业务域重定向、叶子路由、403/404
│  ├─ RequireAuth.tsx              # 登录守卫（未登录跳转 /login 并记录来源）
│  └─ PermissionGate.tsx           # 页面级权限守卫（越权渲染 403）
├─ pages/
│  ├─ LoginPage.tsx                # 登录页
│  ├─ DashboardPage.tsx            # 工作台
│  ├─ ModulePage.tsx               # 业务页面占位模板（由菜单元信息驱动）
│  ├─ ForbiddenPage.tsx            # 403
│  └─ NotFoundPage.tsx             # 404
├─ services/                       # http.ts（axios 实例与拦截器）、auth.ts（登录/退出/档案）
├─ store/                          # auth.tsx（会话）、tabs.tsx（多页签）
├─ hooks/usePermission.ts          # 权限判定 Hook
├─ utils/                          # permission.ts（权限码匹配）、storage.ts（本地存储）
├─ styles/                         # global.css、theme.ts（Ant Design 主题与品牌色）
└─ types/navigation.ts             # 导航、权限、页签、会话类型
```

## 布局结构

主框架 `AdminLayout` 自上而下、自左向右由四部分组成：

1. **侧边栏**（暗色，宽 240 / 折叠 64）：品牌标识、菜单筛选框、多级菜单、版本信息；`breakpoint="lg"` 自动折叠，
   折叠状态持久化到 `localStorage`。
2. **顶栏**：折叠开关、业务域切换（下拉，按权限过滤）、全局菜单搜索（带完整层级链路的候选）、刷新当前页、
   全屏、待办角标、用户下拉（个人信息 / 账号设置 / 帮助与文档 / 退出登录）。
3. **多页签栏**：随路由自动开页签，支持关闭、关闭其他、关闭全部、刷新；首页页签固定不可关闭。
4. **内容区**：面包屑 + 路由出口（`<Outlet />`）。

## 导航与路由组织

菜单按需求文档 4.1「布局与导航」的九大业务域划分，采用 **业务域 — 子功能 — 操作** 三级结构：

| 业务域 | 路由前缀 | 说明 |
| --- | --- | --- |
| 卡务中心 | `/card` | 人员与组织、账户与卡、资金业务、结算与报表、日志与维护 |
| 消费管理 | `/consume` | 基础资料、业务处理、明细报表、汇总报表 |
| 考勤管理 | `/attendance` | 考勤规则、班次与排班、考勤业务、考勤报表 |
| 门禁管理 | `/access` | 门禁参数、设备与权限、通行业务、异常与报警、门禁报表 |
| 订餐管理 | `/meal` | 餐次与菜谱、订餐业务、订餐结算、订餐报表 |
| 访客管理 | `/visitor` | 访客预约、来访登记、证件与发放、访客查询 |
| 水控巡更 | `/utility` | 水控参数、水控业务、巡更点与线路、巡更记录 |
| 报表中心 | `/report` | 综合运营报表、报表工具 |
| 系统管理 | `/system` | 组织与权限、系统配置、安全审计 |

- 路由表由菜单树派生的叶子节点统一生成（`flattenLeaves()`），菜单与路由**单一数据源**，不重复维护。
- 业务域入口（`/card`）自动重定向到该域第一个叶子页面（`/card/person`）。
- 页面级懒加载：`LoginPage / DashboardPage / ModulePage` 通过 `React.lazy` 按需加载，各自包裹 `Suspense`，
  切换业务页时不卸载主框架。
- 未匹配路径渲染 404，越权访问渲染 403。

## 权限框架

- 权限码采用三段式 `业务域:资源:操作`（如 `card:person:view`），支持全局通配 `*` 与前缀通配 `card:*`。
- 权限模型沿用 CS 的 `ST_UserInfo / ST_RoleInfo / ST_RoleRight / ST_RightInfo / ST_DeptRight / ST_SubSysRight / ST_MenuInfo`；
  正式环境由后端 `/auth/profile` 下发权限码集合，前端只做展示层控制，**后端必须做二次校验**。
- 菜单按权限过滤：分组节点在其下所有叶子都被过滤后自动隐藏。
- 页面级：`PermissionGate` 校验页面权限码，越权渲染 403 结果页，不渲染任何业务内容。
- 操作级：业务按钮通过 `usePermission().can()` 判定（占位页中体现为「新增」按钮与操作列）。

演示角色（仅供开发环境联调，密码统一为 `123456`，仅当 `VITE_ENABLE_DEMO_LOGIN=true` 时启用）：

| 账号 | 角色 | 权限范围 |
| --- | --- | --- |
| `admin` | 系统管理员 | 全部业务域与全部操作 |
| `cashier` | 卡务出纳 | 卡务中心全部、消费流水与汇总、跨域报表、系统日志 |
| `hr` | 人事考勤 | 考勤管理、人员 / 部门 / 人脸查看、访客管理、考勤类报表 |
| `security` | 门禁安保 | 门禁管理、访客管理、人员 / 人脸查看、门禁类报表 |
| `canteen` | 食堂消费 | 消费管理、订餐管理、消费与订餐报表 |
| `viewer` | 运营查看 | 工作台与报表中心（只读） |

## 与后端对接约定

- 请求前缀 `/api`，开发期由 Vite 代理到 `VITE_PROXY_TARGET`；生产环境由网关或反向代理转发。
- 统一返回体 `{ code, message, data }`，成功码集合 `['0','200','SUCCESS','OK']`，成功时响应拦截器直接返回 `data`。
- `Authorization: Bearer <token>` 由请求拦截器自动注入（token 存于 `localStorage`，键前缀 `psnmgr.`）。
- 401 触发全局事件 `psnmgr:unauthorized`，会话被清理并回到登录页；403 抛出可识别的业务错误。
- 登录接口 `POST /auth/login`（`{ userName, password }` → `{ token, user }`）、档案 `POST /auth/profile`、
  退出 `POST /auth/logout`；其余业务接口按 §导航与路由组织 中的路由前缀映射（如 `GET /api/card/person`）。

## 说明与约束

- 数据库结构须兼容既有 CS 结构：**可新增，不可删除**；前端不直接访问数据库，一律经后端 RESTful API。
- 工作台与占位页中的数值、列表均为演示数据，接口接入后替换为后端实时数据。
- 本工程不含任何真实密码、密钥或支付凭据；演示密码仅用于开发环境。