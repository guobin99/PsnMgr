/**
 * 生产构建入口（替代直接调用 `vite build`）。
 *
 * 背景：Windows 下 esbuild 会在系统临时目录（%TEMP%）生成中间文件，
 * 退出前需删除；若被杀毒软件实时扫描短暂持有，删除会报
 * `[vite:esbuild-transpile] remove ...: Access is denied.` 而让整次构建失败。
 * 这里把 TMP/TEMP/TMPDIR 指向工程内的 .tmp-build，并在构建前清理上一轮遗留，
 * 使构建不再依赖共享的系统临时目录。
 */
import { spawnSync } from 'node:child_process';
import { mkdirSync, readdirSync, rmSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const tmpDir = join(root, '.tmp-build');

mkdirSync(tmpDir, { recursive: true });

// 清理上一轮遗留：清理失败（仍被占用）不阻断本次构建
for (const name of readdirSync(tmpDir)) {
  try {
    rmSync(join(tmpDir, name), { force: true, recursive: true });
  } catch {
    /* 下一轮再清理 */
  }
}

const viteBin = join(root, 'node_modules', 'vite', 'bin', 'vite.js');
const LOCK_PATTERN = /Access is denied|EBUSY|EPERM|operation not permitted/i;

function runBuild() {
  const result = spawnSync(process.execPath, [viteBin, 'build'], {
    cwd: root,
    encoding: 'utf8',
    env: { ...process.env, TMP: tmpDir, TEMP: tmpDir, TMPDIR: tmpDir },
  });
  process.stdout.write(result.stdout ?? '');
  process.stderr.write(result.stderr ?? '');
  if (result.error) {
    console.error(`[build] 启动 vite 失败：${result.error.message}`);
    process.exit(1);
  }
  return result;
}

let result = runBuild();

// 临时文件仍被杀毒软件瞬时占用时（Windows 偶发），清理后再试一次
if (result.status !== 0 && LOCK_PATTERN.test(`${result.stdout ?? ''}${result.stderr ?? ''}`)) {
  console.warn('\n[build] 检测到临时文件被占用导致的失败，清理临时目录后重试一次…\n');
  for (const name of readdirSync(tmpDir)) {
    try {
      rmSync(join(tmpDir, name), { force: true, recursive: true });
    } catch {
      /* 忽略：重试仍会自行创建新文件 */
    }
  }
  result = runBuild();
}

process.exit(result.status ?? 1);