import type { PermissionCode } from '@/types/navigation';

/**
 * 权限码匹配：支持完全匹配、全局通配 *、以及前缀通配（如 card:* 命中 card:person:view）。
 *
 * 判定顺序不可调整：先判空要求（无要求即通过），再判空集合（无权限即拒绝），
 * 最后按精确匹配、全局通配、前缀通配依次判定。
 * 前缀通配的实现方式是去掉授权码末尾的冒号与星号，再判断所需权限是否以其为前缀，
 * 因此 card:* 能命中 card:person:view，而 card:person 不能命中 card:person:view。
 *
 * 权限数据来自 CS 角色权限表（ST_RoleRight / ST_RightInfo / ST_MenuInfo）的映射结果。
 */
export function hasPermission(permissions: PermissionCode[], required?: PermissionCode): boolean {
  if (!required) return true;
  if (!permissions?.length) return false;

  return permissions.some((grant) => {
    if (grant === '*') return true;
    if (grant === required) return true;
    if (grant.endsWith(':*') && required.startsWith(grant.slice(0, -1))) return true;
    return false;
  });
}

/** 是否具备任意一个权限码 */
export function hasAnyPermission(permissions: PermissionCode[], required: PermissionCode[]): boolean {
  return required.some((code) => hasPermission(permissions, code));
}

/** 是否具备全部权限码 */
export function hasEveryPermission(permissions: PermissionCode[], required: PermissionCode[]): boolean {
  return required.every((code) => hasPermission(permissions, code));
}

/** 权限码转展示文案，便于排查：card:person:view -> card · person · view */
export function describePermission(code?: PermissionCode): string {
  if (!code) return '未设置';
  return code.replace(/:/g, ' · ');
}

/**
 * 操作级权限码派生：以「资源:view」为基线，按动作追加后缀。
 * 派生规则见设计文档 6.8.1：:edit 编辑类、:delete 删除、:import 导入、
 * :export 导出、:audit 审核类、:dispatch 下发类、:cashier 出纳资金类、:batch 批量类。
 */
export function deriveOperationPermission(pagePermission?: PermissionCode, operation = 'edit'): PermissionCode | undefined {
  if (!pagePermission) return undefined;
  if (!pagePermission.endsWith(':view')) return pagePermission;
  const resource = pagePermission.slice(0, -':view'.length);
  return `${resource}:${operation}`;
}
