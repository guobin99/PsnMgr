/** 本地存储统一前缀，键名形如 psnmgr.auth.token */
const PREFIX = 'psnmgr.';

/** 读取本地存储：存储不可用或解析失败时返回兜底值，不抛异常 */
export function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(PREFIX + key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

/** 写入本地存储：配额不足或隐私模式下静默忽略 */
export function writeStorage(key: string, value: unknown): void {
  try {
    window.localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    /* 隐私模式或配额不足时忽略 */
  }
}

/** 删除本地存储 */
export function removeStorage(key: string): void {
  try {
    window.localStorage.removeItem(PREFIX + key);
  } catch {
    /* ignore */
  }
}

export const STORAGE_KEYS = {
  /** 访问令牌 */
  token: 'auth.token',
  /** 会话用户序列化结果 */
  user: 'auth.user',
  /** 侧边栏折叠状态 */
  collapsed: 'layout.collapsed',
  /** 主题偏好 */
  theme: 'layout.theme',
  /** 记住的登录账号 */
  loginUserName: 'login.userName',
} as const;
