import { useMemo } from 'react';

import { useAuth } from '@/store/auth';
import type { PermissionCode } from '@/types/navigation';
import { hasAnyPermission, hasEveryPermission, hasPermission } from '@/utils/permission';

/**
 * 权限判定 Hook：按角色权限渲染菜单与操作按钮。
 * 权限集合来自会话上下文，是前端权限判定的唯一依据。
 */
export function usePermission() {
  const { user } = useAuth();
  const permissions = useMemo<PermissionCode[]>(() => user?.permissions ?? [], [user]);

  return useMemo(
    () => ({
      permissions,
      /** 单一权限判定 */
      can: (code?: PermissionCode) => hasPermission(permissions, code),
      /** 任一命中即通过 */
      canAny: (codes: PermissionCode[]) => hasAnyPermission(permissions, codes),
      /** 全部命中才通过 */
      canEvery: (codes: PermissionCode[]) => hasEveryPermission(permissions, codes),
    }),
    [permissions],
  );
}
