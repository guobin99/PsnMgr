import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

import { loginRequest, logoutRequest } from '@/services/auth';
import { UNAUTHORIZED_EVENT } from '@/services/http';
import type { LoginPayload, SessionUser } from '@/types/navigation';
import { readStorage, removeStorage, STORAGE_KEYS, writeStorage } from '@/utils/storage';

interface AuthContextValue {
  /** 访问令牌 */
  token: string | null;
  /** 会话用户（含权限码集合） */
  user: SessionUser | null;
  /** 登录态判定：等价于令牌非空，不解析令牌有效期 */
  isAuthenticated: boolean;
  /** 会话恢复中（首屏守卫用） */
  initializing: boolean;
  /** 登录并建立会话 */
  login: (payload: LoginPayload) => Promise<SessionUser>;
  /** 退出登录：无论后端是否成功都清理本地会话 */
  logout: () => Promise<void>;
  /** 更新会话用户（如刷新权限集合） */
  updateUser: (patch: Partial<SessionUser>) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  // 会话恢复在一次同步读取中完成，避免首屏先渲染登录页再跳回造成的闪烁
  const [token, setToken] = useState<string | null>(() => readStorage<string | null>(STORAGE_KEYS.token, null));
  const [user, setUser] = useState<SessionUser | null>(() => readStorage<SessionUser | null>(STORAGE_KEYS.user, null));
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    setInitializing(false);
  }, []);

  const login = useCallback(async (payload: LoginPayload) => {
    const result = await loginRequest(payload);
    setToken(result.token);
    setUser(result.user);
    writeStorage(STORAGE_KEYS.token, result.token);
    writeStorage(STORAGE_KEYS.user, result.user);
    return result.user;
  }, []);

  const logout = useCallback(async () => {
    // 退出接口失败不阻塞本地会话清理
    await logoutRequest();
    setToken(null);
    setUser(null);
    removeStorage(STORAGE_KEYS.token);
    removeStorage(STORAGE_KEYS.user);
  }, []);

  const updateUser = useCallback((patch: Partial<SessionUser>) => {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, ...patch };
      writeStorage(STORAGE_KEYS.user, next);
      return next;
    });
  }, []);

  // 被动失效：请求层派发全局未授权事件，由会话上下文统一清理，保证只执行一次
  useEffect(() => {
    const handleUnauthorized = () => {
      setToken(null);
      setUser(null);
      removeStorage(STORAGE_KEYS.token);
      removeStorage(STORAGE_KEYS.user);
    };
    window.addEventListener(UNAUTHORIZED_EVENT, handleUnauthorized);
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, handleUnauthorized);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ token, user, isAuthenticated: Boolean(token), initializing, login, logout, updateUser }),
    [token, user, initializing, login, logout, updateUser],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth 必须在 AuthProvider 内使用');
  }
  return context;
}
