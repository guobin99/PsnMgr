import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

import type { TabItem } from '@/types/navigation';

/** 工作台页签：固定存在、不可关闭，作为所有回退路径的终点 */
export const HOME_TAB: TabItem = {
  key: 'dashboard',
  path: '/dashboard',
  title: '工作台',
  domain: '首页',
  closable: false,
};

interface TabsContextValue {
  /** 页签集合 */
  tabs: TabItem[];
  /** 打开（或激活）一个页签：已存在则只更新标题与业务域 */
  openTab: (tab: TabItem) => void;
  /** 关闭页签，返回关闭后应跳转的路径（右侧相邻 → 左侧相邻 → 工作台） */
  closeTab: (key: string) => string;
  /** 关闭其他页签：只保留当前页签与不可关闭的工作台页签 */
  closeOthers: (key: string) => void;
  /** 关闭全部页签：仅剩工作台页签 */
  closeAll: () => void;
  /** 关闭当前页签后应跳转的路径 */
  resolveAfterClose: (key: string) => string;
}

const TabsContext = createContext<TabsContextValue | null>(null);

export function TabsProvider({ children }: { children: ReactNode }) {
  // 页签不做持久化：路径随版本演进易失效，刷新后仅保留工作台并补开当前页
  const [tabs, setTabs] = useState<TabItem[]>([HOME_TAB]);

  const openTab = useCallback((tab: TabItem) => {
    setTabs((prev) => {
      const exists = prev.some((item) => item.key === tab.key);
      if (exists) {
        return prev.map((item) =>
          item.key === tab.key ? { ...item, path: tab.path, title: tab.title, domain: tab.domain } : item,
        );
      }
      return [...prev, tab];
    });
  }, []);

  /** 回退目标：右侧相邻 → 左侧相邻 → 工作台 */
  const resolveAfterClose = useCallback(
    (key: string) => {
      const index = tabs.findIndex((item) => item.key === key);
      if (index < 0) return HOME_TAB.path;
      const rest = tabs.filter((item) => item.key !== key);
      const neighbour = rest[index] ?? rest[index - 1] ?? HOME_TAB;
      return neighbour.path;
    },
    [tabs],
  );

  const closeTab = useCallback(
    (key: string) => {
      const fallback = resolveAfterClose(key);
      setTabs((prev) => {
        const next = prev.filter((item) => item.key !== key || !item.closable);
        return next.length === 0 ? [HOME_TAB] : next;
      });
      return fallback;
    },
    [resolveAfterClose],
  );

  const closeOthers = useCallback((key: string) => {
    setTabs((prev) => prev.filter((item) => item.key === key || !item.closable));
  }, []);

  const closeAll = useCallback(() => {
    setTabs([HOME_TAB]);
  }, []);

  const value = useMemo<TabsContextValue>(
    () => ({ tabs, openTab, closeTab, closeOthers, closeAll, resolveAfterClose }),
    [tabs, openTab, closeTab, closeOthers, closeAll, resolveAfterClose],
  );

  return <TabsContext.Provider value={value}>{children}</TabsContext.Provider>;
}

export function useTabs(): TabsContextValue {
  const context = useContext(TabsContext);
  if (!context) {
    throw new Error('useTabs 必须在 TabsProvider 内使用');
  }
  return context;
}
