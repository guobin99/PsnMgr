/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** 请求基础地址，开发环境由 Vite 代理转发到后端 */
  readonly VITE_API_BASE_URL?: string;
  /** 开发代理目标地址 */
  readonly VITE_PROXY_TARGET?: string;
  /** 应用标题 */
  readonly VITE_APP_TITLE?: string;
  /** 演示登录回退开关，生产构建必须为 false */
  readonly VITE_ENABLE_DEMO_LOGIN?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
