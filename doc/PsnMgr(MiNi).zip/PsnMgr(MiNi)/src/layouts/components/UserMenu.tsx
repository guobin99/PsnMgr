import { useMemo } from 'react';
import { Avatar, Dropdown, Space, Tag, type MenuProps } from 'antd';
import {
  DownOutlined,
  LogoutOutlined,
  QuestionCircleOutlined,
  SettingOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';

import { useAuth } from '@/store/auth';

/**
 * 顶栏用户菜单：头像、姓名、角色标签与下拉动作。
 * 主动退出：调用退出接口（无论成功与否都继续），清理会话后跳转登录页。
 */
export default function UserMenu() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const items = useMemo<MenuProps['items']>(
    () => [
      { key: 'profile', icon: <UserOutlined />, label: '个人信息' },
      { key: 'settings', icon: <SettingOutlined />, label: '账号设置' },
      { key: 'help', icon: <QuestionCircleOutlined />, label: '帮助与文档' },
      { type: 'divider' },
      { key: 'logout', icon: <LogoutOutlined />, label: '退出登录', danger: true },
    ],
    [],
  );

  const onClick: MenuProps['onClick'] = async ({ key }) => {
    if (key === 'logout') {
      await logout();
      navigate('/login', { replace: true });
      return;
    }
    // 个人中心与设置页尚未建设，统一引导到 403 结果页说明当前状态
    navigate('/403?from=user-menu');
  };

  return (
    <Dropdown menu={{ items, onClick }} placement="bottomRight" trigger={['click']}>
      <span className="app-header__action">
        <Avatar size={28} style={{ background: '#2f6fed' }} icon={<UserOutlined />} />
        <Space size={6}>
          <span className="app-header__user-name" style={{ fontSize: 13, fontWeight: 500 }}>
            {user?.displayName ?? '未登录'}
          </span>
          {user?.roleName && (
            <Tag color="blue" style={{ marginInlineEnd: 0, fontSize: 11, lineHeight: '18px' }}>
              {user.roleName}
            </Tag>
          )}
        </Space>
        <DownOutlined style={{ fontSize: 10, color: '#94a3b8' }} />
      </span>
    </Dropdown>
  );
}
