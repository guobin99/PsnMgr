import { useEffect, useMemo, useState } from 'react';
import { Menu, type MenuProps } from 'antd';
import { useLocation, useNavigate } from 'react-router-dom';

import { flattenMenu } from '@/config/menu';
import type { NavNode } from '@/types/navigation';

type MenuItem = Required<MenuProps>['items'][number];

/**
 * 关键词过滤：按菜单名称与路径做包含匹配，命中叶子即保留，
 * 父节点在存在命中子节点时保留，避免出现空分组。
 */
function filterByKeyword(nodes: NavNode[], keyword: string): NavNode[] {
  const trimmed = keyword.trim().toLowerCase();
  if (!trimmed) return nodes;

  const result: NavNode[] = [];
  for (const node of nodes) {
    if (node.children?.length) {
      const children = filterByKeyword(node.children, trimmed);
      if (children.length > 0) {
        result.push({ ...node, children });
      }
      continue;
    }
    const hitLabel = node.label.toLowerCase().includes(trimmed);
    const hitPath = (node.path ?? '').toLowerCase().includes(trimmed);
    if (hitLabel || hitPath) {
      result.push(node);
    }
  }
  return result;
}

/** 导航树转 antd 菜单项；hidden 节点不进入菜单但仍可路由访问 */
function toMenuItems(nodes: NavNode[]): MenuItem[] {
  return nodes
    .filter((node) => !node.hidden)
    .map((node) => {
      const base = { key: node.key, label: node.label, icon: node.icon } as MenuItem;
      if (node.children?.length) {
        return { ...base, children: toMenuItems(node.children) } as MenuItem;
      }
      return base;
    });
}

/** 取得当前路径的父级链路，作为菜单展开键 */
function collectAncestorKeys(nodes: NavNode[], pathname: string, trail: string[] = []): string[] {
  for (const node of nodes) {
    const nextTrail = [...trail, node.key];
    if (node.path === pathname) return nextTrail.slice(0, -1);
    if (node.children?.length) {
      const matched = collectAncestorKeys(node.children, pathname, nextTrail);
      if (matched.length > 0) return matched;
    }
  }
  return [];
}

interface SideMenuProps {
  /** 已按权限过滤的菜单树 */
  tree: NavNode[];
  /** 侧边栏是否折叠 */
  collapsed: boolean;
  /** 筛选关键词 */
  keyword?: string;
  /** 选中菜单后的回调（用于清空筛选词） */
  onNavigate?: (path: string) => void;
}

/**
 * 侧边栏菜单：深色 inline 模式，三级结构（业务域 / 子功能分组 / 操作页面）。
 * 选中键取当前路径对应的叶子节点键，不使用路径本身作为键，避免与分组键混淆。
 */
export default function SideMenu({ tree, collapsed, keyword = '', onNavigate }: SideMenuProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const nodeMap = useMemo(() => {
    const map = new Map<string, NavNode>();
    flattenMenu(tree).forEach((node) => map.set(node.key, node));
    return map;
  }, [tree]);

  const selectedKey = useMemo(() => {
    const matched = flattenMenu(tree).find((node) => node.path === location.pathname);
    return matched?.key ?? location.pathname;
  }, [tree, location.pathname]);

  const [openKeys, setOpenKeys] = useState<string[]>(() => collectAncestorKeys(tree, location.pathname));

  // 路径变化时自动同步为当前页面的父级链路
  useEffect(() => {
    const ancestors = collectAncestorKeys(tree, location.pathname);
    if (ancestors.length > 0) {
      setOpenKeys((prev) => Array.from(new Set([...prev, ...ancestors])));
    }
  }, [tree, location.pathname]);

  const items = useMemo(() => toMenuItems(filterByKeyword(tree, keyword)), [tree, keyword]);

  const handleClick: MenuProps['onClick'] = ({ key }) => {
    const target = nodeMap.get(String(key));
    if (target?.path) {
      navigate(target.path);
      onNavigate?.(target.path);
    }
  };

  if (items.length === 0) {
    return (
      <div className="app-sider__empty">
        {keyword ? '没有匹配的菜单' : '当前角色暂无可访问的功能'}
      </div>
    );
  }

  return (
    <Menu
      theme="dark"
      mode="inline"
      items={items}
      selectedKeys={[selectedKey]}
      openKeys={collapsed ? undefined : openKeys}
      onOpenChange={(keys) => setOpenKeys(keys as string[])}
      onClick={handleClick}
      inlineIndent={16}
    />
  );
}
