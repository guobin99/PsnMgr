import { BRAND } from '@/styles/theme';

interface BrandLogoProps {
  /** 侧边栏是否折叠：折叠态只保留品牌方块 */
  collapsed: boolean;
}

/**
 * 品牌标识：渐变方块 + 平台名称。
 * 高度与顶栏一致，使侧边栏顶部与顶栏形成同一条水平分隔线。
 */
export default function BrandLogo({ collapsed }: BrandLogoProps) {
  return (
    <div
      className="app-brand"
      style={{ paddingInline: collapsed ? 0 : 16, justifyContent: collapsed ? 'center' : 'flex-start' }}
    >
      <span className="app-brand__logo" aria-hidden>
        人
      </span>
      {!collapsed && (
        <span className="app-brand__text">
          <span className="app-brand__title">{BRAND.fullName}</span>
          <span className="app-brand__sub">{BRAND.subtitle}</span>
        </span>
      )}
    </div>
  );
}
