import { useMemo } from 'react';
import { Dropdown, Tabs, type MenuProps } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import { useLocation, useNavigate } from 'react-router-dom';

import { useTabs } from '@/store/tabs';

/**
 * 多页签栏：与菜单叶子节点一一对应，同一页面只保留一个页签。
 *
 * 关闭激活页签时按「右侧相邻 → 左侧相邻 → 工作台」的顺序确定回退目标；
 * 关闭非激活页签只移除条目，当前位置不变。
 */
export default function TabsBar() {
  const { tabs, closeTab, closeOthers, closeAll } = useTabs();
  const navigate = useNavigate();
  const location = useLocation();

  /** 激活页签由当前路径推导，页签本身不保存选中态，避免双份状态不一致 */
  const activeKey = useMemo(
    () => tabs.find((tab) => tab.path === location.pathname)?.key ?? location.pathname,
    [tabs, location.pathname],
  );

  const items = tabs.map((tab) => ({
    key: tab.key,
    label: (
      <span>
        {tab.title}
        {tab.closable && <span className="app-tabsbar__tab-domain">{tab.domain}</span>}
      </span>
    ),
    closable: tab.closable,
  }));

  const menuItems: MenuProps['items'] = [
    { key: 'others', label: '关闭其他页签' },
    { key: 'all', label: '关闭全部页签' },
    { key: 'refresh', label: '刷新当前页签' },
  ];

  const onMenuClick: MenuProps['onClick'] = ({ key }) => {
    if (key === 'others') {
      closeOthers(activeKey);
      return;
    }
    if (key === 'all') {
      closeAll();
      navigate('/dashboard');
      return;
    }
    // 刷新：以 replace 方式重新进入当前路径，不新增页签
    navigate(location.pathname, { replace: true });
  };

  return (
    <div className="app-tabsbar">
      <Tabs
        type="editable-card"
        hideAdd
        size="small"
        activeKey={activeKey}
        items={items}
        onChange={(key) => {
          const target = tabs.find((tab) => tab.key === key);
          if (target) navigate(target.path);
        }}
        onEdit={(targetKey, action) => {
          if (action !== 'remove') return;
          const key = String(targetKey);
          const closingActive = key === activeKey;
          const nextPath = closeTab(key);
          if (closingActive) navigate(nextPath);
        }}
      />
      <Dropdown menu={{ items: menuItems, onClick: onMenuClick }} trigger={['click']}>
        <span className="app-tabsbar__more" aria-label="页签操作">
          <DownOutlined />
        </span>
      </Dropdown>
    </div>
  );
}
