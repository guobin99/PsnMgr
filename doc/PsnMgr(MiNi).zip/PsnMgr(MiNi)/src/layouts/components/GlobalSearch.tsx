import { useMemo, useState } from 'react';
import { Dropdown, Input, type MenuProps } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';

import { buildMenuSearchIndex } from '@/config/menu';
import type { NavNode } from '@/types/navigation';

interface GlobalSearchProps {
  /** 已按权限过滤的菜单树，保证只能搜到有权限的页面 */
  tree: NavNode[];
}

/**
 * 全局菜单搜索：在 233 个节点中快速定位页面。
 *
 * 索引按权限过滤后的导航树生成（与侧边栏、顶栏业务域下拉同源），
 * 搜索对名称与层级链路做忽略大小写的包含匹配，按链路层级数升序取前 8 条。
 */
export default function GlobalSearch({ tree }: GlobalSearchProps) {
  const navigate = useNavigate();
  const [keyword, setKeyword] = useState('');
  const [open, setOpen] = useState(false);

  const index = useMemo(() => buildMenuSearchIndex(tree), [tree]);

  const matched = useMemo(() => {
    const trimmed = keyword.trim().toLowerCase();
    if (!trimmed) return [];
    return index
      .filter((row) => row.label.toLowerCase().includes(trimmed) || row.trail.toLowerCase().includes(trimmed))
      .sort((a, b) => a.depth - b.depth)
      .slice(0, 8);
  }, [index, keyword]);

  const menu: MenuProps = {
    items: matched.map((row) => ({
      key: row.path,
      label: (
        <div className="app-search__candidate">
          <div className="app-search__candidate-title">{row.label}</div>
          <div className="app-search__candidate-trail">{row.trail}</div>
        </div>
      ),
    })),
    onClick: ({ key }) => {
      navigate(String(key));
      setKeyword('');
      setOpen(false);
    },
  };

  return (
    <Dropdown
      open={open && matched.length > 0}
      menu={menu}
      trigger={['click']}
      placement="bottomLeft"
      onOpenChange={(next) => setOpen(next)}
    >
      <span className="app-header__search">
        <Input
          allowClear
          value={keyword}
          prefix={<SearchOutlined style={{ color: '#94a3b8' }} />}
          placeholder="搜索菜单 / 功能（如：充值、考勤日报）"
          onChange={(event) => {
            setKeyword(event.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          // 失焦后延时收起，避免点击候选时因失焦先行关闭而丢失点击事件
          onBlur={() => window.setTimeout(() => setOpen(false), 180)}
        />
      </span>
    </Dropdown>
  );
}
