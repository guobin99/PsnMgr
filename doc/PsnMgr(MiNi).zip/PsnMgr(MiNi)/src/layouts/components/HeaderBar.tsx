import { useMemo } from 'react';
import { Dropdown, type MenuProps } from 'antd';
import {
  AppstoreOutlined,
  BellOutlined,
  DownOutlined,
  ExpandOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  ReloadOutlined,
} from '@ant-design/icons';
import { useLocation, useNavigate } from 'react-router-dom';

import { buildDomainEntries } from '@/config/menu';
import type { NavNode } from '@/types/navigation';

import GlobalSearch from './GlobalSearch';
import UserMenu from './UserMenu';

interface HeaderBarProps {
  /** 侧边栏是否折叠 */
  collapsed: boolean;
  /** 折叠开关回调 */
  onToggle: () => void;
  /** 已按权限过滤的菜单树 */
  tree: NavNode[];
}

/**
 * 顶栏内容行：折叠开关 | 业务域切换 | 弹性占位 | 全局搜索 | 刷新 | 全屏 | 通知 | 用户菜单。
 *
 * 本组件的根节点使用 .app-header-bar（内容行），外壳 .app-header 只负责高度与分隔线；
 * 中间的 .app-header__spacer 是右对齐能力的唯一保证，删除后右侧动作区将不再贴住右边界。
 */
export default function HeaderBar({ collapsed, onToggle, tree }: HeaderBarProps) {
  const navigate = useNavigate();
  const location = useLocation();

  /** 业务域下拉只列出权限过滤后仍有可见节点的业务域 */
  const domains = useMemo(() => {
    const visibleDomainKeys = new Set(tree.filter((node) => node.key !== 'dashboard').map((node) => node.key));
    return buildDomainEntries(tree).filter((domain) => visibleDomainKeys.has(domain.key));
  }, [tree]);

  /** 当前域：按「当前路径以斜线加域键开头」判断，第一个命中者即为当前域 */
  const currentDomain = domains.find((domain) => location.pathname.startsWith(`/${domain.key}`));

  const domainMenu: MenuProps = {
    items: domains.map((domain) => ({ key: domain.key, icon: domain.icon, label: domain.label })),
    onClick: ({ key }) => {
      const domain = domains.find((item) => item.key === key);
      if (domain) navigate(domain.entryPath);
    },
  };

  return (
    <div className="app-header-bar">
      <span className="app-header__trigger" onClick={onToggle} aria-label="折叠菜单">
        {collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
      </span>

      <Dropdown menu={domainMenu} trigger={['click']}>
        <span className="app-header__action app-header__domain" title={currentDomain?.label ?? '业务域切换'}>
          <AppstoreOutlined />
          <span className="app-header__domain-label">{currentDomain?.label ?? '业务域切换'}</span>
          <DownOutlined className="app-header__domain-arrow" style={{ fontSize: 10, color: '#94a3b8' }} />
        </span>
      </Dropdown>

      {/* 弹性占位元素：右对齐能力的唯一来源，不可删除 */}
      <span className="app-header__spacer" />

      <GlobalSearch tree={tree} />

      <span className="app-header__trigger app-header__action--secondary" onClick={() => navigate(location.pathname, { replace: true })} aria-label="刷新当前页">
        <ReloadOutlined />
      </span>

      <span
        className="app-header__trigger app-header__action--secondary"
        onClick={() => {
          const doc = document;
          if (doc.fullscreenElement) {
            void doc.exitFullscreen?.().catch(() => undefined);
            return;
          }
          // 浏览器不支持或用户拒绝时静默失败，不打断操作
          void doc.documentElement.requestFullscreen?.().catch(() => undefined);
        }}
        aria-label="全屏显示"
      >
        <ExpandOutlined />
      </span>

      <span className="app-header__trigger" aria-label="待办与通知">
        <BellOutlined />
      </span>

      <UserMenu />
    </div>
  );
}
