import { Breadcrumb } from 'antd';
import { HomeOutlined } from '@ant-design/icons';
import { Link, useLocation } from 'react-router-dom';

import { getBreadcrumbs } from '@/config/menu';

/**
 * 内容区面包屑：首页 / 业务域 / 子功能分组 / 当前页面。
 *
 * 首项固定为「首页」并链接到工作台；中间项只展示层级名称，不提供跳转（分组节点本身无路径）；
 * 末项为当前页面，以次要文字颜色显示且不可点击。
 * 路径不属于导航树时（403、404 等）退化为仅「首页」一项。
 */
export default function AppBreadcrumb() {
  const { pathname } = useLocation();
  const crumbs = getBreadcrumbs(pathname);

  const items = [
    {
      title: (
        <Link to="/dashboard">
          <HomeOutlined /> <span>首页</span>
        </Link>
      ),
    },
    ...crumbs.map((crumb, index) => ({
      title:
        index === crumbs.length - 1 ? (
          <span className="text-muted">{crumb.label}</span>
        ) : (
          <span>{crumb.label}</span>
        ),
    })),
  ];

  return <Breadcrumb className="app-crumbs" items={items} />;
}
