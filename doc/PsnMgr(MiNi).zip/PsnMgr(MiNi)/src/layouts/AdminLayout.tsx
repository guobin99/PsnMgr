import { useEffect, useMemo, useState } from 'react';
import { Input, Layout } from 'antd';
import { useLocation, useOutlet } from 'react-router-dom';

import { filterMenuByPermission, findNodeByPath, getDomainOf, navigation } from '@/config/menu';
import { useAuth } from '@/store/auth';
import { useTabs } from '@/store/tabs';
import { readStorage, STORAGE_KEYS, writeStorage } from '@/utils/storage';

import AppBreadcrumb from './components/AppBreadcrumb';
import BrandLogo from './components/BrandLogo';
import HeaderBar from './components/HeaderBar';
import SideMenu from './components/SideMenu';
import TabsBar from './components/TabsBar';

const { Content, Header, Sider } = Layout;

/**
 * 主框架：左侧边栏 + 右侧（顶栏 / 多页签栏 / 内容区）。
 *
 * 区域划分与尺寸口径：
 * - 侧边栏：展开 240px、折叠 64px，深色主题，含品牌区、菜单筛选、菜单区与版本条；
 * - 顶栏：56px，外壳只负责高度与分隔线，横向排布由 .app-header-bar 承载；
 * - 多页签栏：40px，工作台页签固定不可关闭；
 * - 内容区：面包屑 + 路由出口，左右内边距与顶栏内容行一致（均为 16px）。
 *
 * 布局组件只依赖导航数据与会话状态，不感知具体业务。
 */
export default function AdminLayout() {
  const outlet = useOutlet();
  const location = useLocation();
  const { user } = useAuth();
  const { openTab } = useTabs();

  // 用户自身的折叠偏好（持久化），与断点造成的临时折叠分开维护
  const [collapsed, setCollapsed] = useState<boolean>(() => readStorage<boolean>(STORAGE_KEYS.collapsed, false));
  // 视口是否处于 lg 断点以下：低于断点强制折叠，恢复后回到用户偏好
  const [belowBreakpoint, setBelowBreakpoint] = useState(false);
  const [keyword, setKeyword] = useState('');

  const effectiveCollapsed = collapsed || belowBreakpoint;

  const permissions = useMemo(() => user?.permissions ?? [], [user]);

  // 菜单在渲染前即按会话权限裁剪：无权限的功能不出现在导航中
  const menuTree = useMemo(() => filterMenuByPermission(navigation, permissions), [permissions]);

  useEffect(() => {
    writeStorage(STORAGE_KEYS.collapsed, collapsed);
  }, [collapsed]);

  // 路由变化时同步多页签：已存在只更新标题与业务域，否则追加
  useEffect(() => {
    const node = findNodeByPath(location.pathname);
    if (!node?.path) return;
    openTab({
      key: node.key,
      path: node.path,
      title: node.label,
      domain: getDomainOf(node.path)?.label ?? '业务管理',
      closable: node.path !== '/dashboard',
    });
  }, [location.pathname, openTab]);

  return (
    <Layout className="app-shell">
      <Sider
        className="app-sider"
        theme="dark"
        width={240}
        collapsedWidth={64}
        collapsed={effectiveCollapsed}
        breakpoint="lg"
        trigger={null}
        onBreakpoint={setBelowBreakpoint}
      >
        <BrandLogo collapsed={effectiveCollapsed} />

        {!effectiveCollapsed && (
          <div className="app-sider__search">
            <Input
              allowClear
              size="small"
              value={keyword}
              placeholder="筛选菜单（名称 / 路径）"
              onChange={(event) => setKeyword(event.target.value)}
            />
          </div>
        )}

        <div className="app-sider__menu">
          <SideMenu
            tree={menuTree}
            collapsed={effectiveCollapsed}
            keyword={keyword}
            onNavigate={() => setKeyword('')}
          />
        </div>

        <div className="app-sider__footer">v1.0.0 · 与 CS 并行运行</div>
      </Sider>

      <Layout>
        <Header className="app-header">
          <HeaderBar collapsed={effectiveCollapsed} onToggle={() => setCollapsed((prev) => !prev)} tree={menuTree} />
        </Header>

        <TabsBar />

        <Content className="app-content">
          <AppBreadcrumb />
          {outlet}
        </Content>
      </Layout>
    </Layout>
  );
}
