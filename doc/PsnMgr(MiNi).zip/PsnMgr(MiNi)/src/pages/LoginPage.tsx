import { useEffect, useMemo, useState } from 'react';
import { App as AntdApp, Button, Card, Checkbox, Divider, Form, Input, Space, Tag } from 'antd';
import { LockOutlined, SafetyCertificateOutlined, UserOutlined } from '@ant-design/icons';
import { useLocation, useNavigate, type Location } from 'react-router-dom';

import { buildDomainEntries } from '@/config/menu';
import { DEMO_PASSWORD, demoAccounts } from '@/config/roles';
import { DEMO_LOGIN_ENABLED } from '@/services/auth';
import { useAuth } from '@/store/auth';
import { BRAND } from '@/styles/theme';
import { readStorage, removeStorage, STORAGE_KEYS, writeStorage } from '@/utils/storage';

interface LoginFormValues {
  userName: string;
  password: string;
  remember: boolean;
}

/**
 * 登录页：左右分栏布局。
 * 左栏为平台介绍与业务域清单，右栏为登录表单。
 *
 * 登录成功后若存在来源路径则回跳来源，否则进入工作台，均以 replace 方式跳转；
 * 登录失败时不清理已填账号，只提示错误原因；密码字段不做本地留存。
 */
export default function LoginPage() {
  const [form] = Form.useForm<LoginFormValues>();
  const { message } = AntdApp.useApp();
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [submitting, setSubmitting] = useState(false);

  const domains = useMemo(() => buildDomainEntries(), []);

  /** 登录后回跳的目标：优先返回守卫记录的来源路径 */
  const redirectPath = useMemo(() => {
    const state = location.state as { from?: Location } | null;
    return state?.from?.pathname ?? '/dashboard';
  }, [location.state]);

  useEffect(() => {
    const remembered = readStorage<string>(STORAGE_KEYS.loginUserName, '');
    if (remembered) {
      form.setFieldsValue({ userName: remembered, password: '', remember: true });
    }
  }, [form]);

  useEffect(() => {
    if (isAuthenticated) {
      navigate(redirectPath, { replace: true });
    }
  }, [isAuthenticated, navigate, redirectPath]);

  const handleSubmit = async (values: LoginFormValues) => {
    setSubmitting(true);
    try {
      const account = values.userName.trim();
      const user = await login({ userName: account, password: values.password });
      if (values.remember) {
        writeStorage(STORAGE_KEYS.loginUserName, account);
      } else {
        removeStorage(STORAGE_KEYS.loginUserName);
      }
      message.success(`欢迎回来，${user.displayName}${user.roleName ? `（${user.roleName}）` : ''}`);
      navigate(redirectPath, { replace: true });
    } catch (error) {
      message.error(error instanceof Error ? error.message : '登录失败，请稍后重试');
    } finally {
      setSubmitting(false);
    }
  };

  const fillAccount = (userName: string) => {
    form.setFieldsValue({ userName, password: DEMO_PASSWORD });
    message.info(`已填充演示账号 ${userName}`);
  };

  return (
    <div className="login-page">
      <div className="login-page__intro">
        <span className="login-page__badge">
          <SafetyCertificateOutlined /> {BRAND.fullName} {BRAND.version}
        </span>
        <h1 className="login-page__title">人脸通 · BS 管理平台</h1>
        <p className="login-page__subtitle">
          面向卡务、消费、考勤、门禁、订餐、访客、水控巡更、报表与系统管理的统一 Web 工作台，
          与既有 CS 客户端共用同一套 SQL Server 数据库，权限沿用角色权限设置。
        </p>
        <div className="login-page__domains">
          {domains.map((domain) => (
            <span key={domain.key} className="login-page__domain">
              {domain.label}
            </span>
          ))}
        </div>
      </div>

      <div className="login-page__form">
        <Card className="login-card">
          <Space direction="vertical" size={2} style={{ marginBottom: 18 }}>
            <span style={{ fontSize: 20, fontWeight: 600 }}>账号登录</span>
            <span className="text-muted" style={{ fontSize: 13 }}>
              请使用操作员账号登录，账号与权限来源于系统管理的操作员与角色配置。
            </span>
          </Space>

          <Form<LoginFormValues>
            form={form}
            layout="vertical"
            requiredMark={false}
            initialValues={{ userName: '', password: '', remember: true }}
            onFinish={handleSubmit}
          >
            <Form.Item name="userName" label="操作员账号" rules={[{ required: true, message: '请输入操作员账号' }]}>
              <Input size="large" prefix={<UserOutlined />} placeholder="操作员账号" autoComplete="username" />
            </Form.Item>

            <Form.Item name="password" label="登录密码" rules={[{ required: true, message: '请输入登录密码' }]}>
              <Input.Password
                size="large"
                prefix={<LockOutlined />}
                placeholder="登录密码"
                autoComplete="current-password"
              />
            </Form.Item>

            <Form.Item style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Form.Item name="remember" valuePropName="checked" noStyle>
                  <Checkbox>记住账号</Checkbox>
                </Form.Item>
                <Button type="link" size="small" onClick={() => message.info('请联系系统管理员重置密码')}>
                  忘记密码？
                </Button>
              </div>
            </Form.Item>

            <Button type="primary" size="large" htmlType="submit" block loading={submitting}>
              登录
            </Button>
          </Form>

          {DEMO_LOGIN_ENABLED && (
            <>
              <Divider plain style={{ fontSize: 12, color: '#94a3b8' }}>
                演示账号（仅开发环境）
              </Divider>
              <Space wrap size={[8, 8]}>
                {demoAccounts.map((account) => (
                  <Tag
                    key={account.userName}
                    color="blue"
                    style={{ marginInlineEnd: 0, cursor: 'pointer' }}
                    onClick={() => fillAccount(account.userName)}
                  >
                    {account.userName} · {account.displayName}
                  </Tag>
                ))}
              </Space>
              <div className="text-muted" style={{ fontSize: 12, marginTop: 8 }}>
                点击标签自动填充账号，演示密码为 {DEMO_PASSWORD}；生产环境关闭演示登录。
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
