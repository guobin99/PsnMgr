import { Button, Result, Space } from 'antd';
import { useLocation, useNavigate } from 'react-router-dom';

import { describePermission } from '@/utils/permission';

interface ForbiddenPageProps {
  /** 作为页面内容内嵌渲染（页面级权限守卫场景），而非整屏结果页 */
  inline?: boolean;
  /** 触发越权时缺失的权限码 */
  required?: string;
  /** 被拒绝访问的路径 */
  path?: string;
}

/**
 * 403 结果页：展示当前角色无权访问，并给出所需权限码与返回入口。
 * 页面级越权时内嵌在主框架内渲染，保留侧边栏与页签导航。
 */
export default function ForbiddenPage({ inline = false, required, path }: ForbiddenPageProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const targetPath = path ?? location.pathname;

  const subTitle = (
    <Space direction="vertical" size={4}>
      <span>当前角色没有访问「{targetPath}」的权限，请联系系统管理员在角色权限中授权。</span>
      {required && (
        <span className="text-muted" style={{ fontSize: 13 }}>
          所需权限码：{required}（{describePermission(required)}）
        </span>
      )}
    </Space>
  );

  const result = (
    <Result
      status="403"
      title="403"
      subTitle={subTitle}
      extra={
        <Space>
          <Button type="primary" onClick={() => navigate('/dashboard')}>
            返回工作台
          </Button>
          <Button onClick={() => navigate(-1)}>返回上一页</Button>
        </Space>
      }
    />
  );

  if (inline) {
    return <div className="page-card">{result}</div>;
  }

  return result;
}
