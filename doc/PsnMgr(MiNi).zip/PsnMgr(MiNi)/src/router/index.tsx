import { lazy, Suspense, type ReactNode } from 'react';
import { Spin } from 'antd';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';

import { flattenLeaves, navigation } from '@/config/menu';
import AdminLayout from '@/layouts/AdminLayout';
import ForbiddenPage from '@/pages/ForbiddenPage';
import NotFoundPage from '@/pages/NotFoundPage';

import PermissionGate from './PermissionGate';
import RequireAuth from './RequireAuth';

/** 页面级懒加载：主框架先渲染，业务页面按需加载 */
const LoginPage = lazy(() => import('@/pages/LoginPage'));
const DashboardPage = lazy(() => import('@/pages/DashboardPage'));
const ModulePage = lazy(() => import('@/pages/ModulePage'));

function RouteFallback() {
  return (
    <div className="route-loading">
      <Spin size="large" />
      <span className="text-muted">页面加载中…</span>
    </div>
  );
}

/** 每个懒加载页面各自包裹 Suspense，避免切换业务页时整块主框架被卸载 */
function withSuspense(node: ReactNode) {
  return <Suspense fallback={<RouteFallback />}>{node}</Suspense>;
}

/** 九大业务域下的叶子页面：由菜单树统一派生，路由与菜单不重复维护 */
const leafRoutes = flattenLeaves().filter((node) => Boolean(node.path) && node.path !== '/dashboard');

/** 业务域入口重定向：/card → /card/person，/report → /report/overview 等 */
const domainNodes = navigation.filter((node) => node.children?.length);

/**
 * 路由总装。
 *
 * 守卫分层：登录守卫包在主框架外层，权限守卫包在每条叶子路由外层，两者职责不重叠；
 * 逐条懒加载：每个业务页面单独分包，每个路由独立 Suspense，切换页面不卸载主框架。
 */
export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        {/* 公开路由：已登录时仍可访问，用于切换账号 */}
        <Route path="/login" element={withSuspense(<LoginPage />)} />

        <Route element={<RequireAuth />}>
          <Route element={<AdminLayout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />

            <Route
              path="/dashboard"
              element={
                <PermissionGate permission="dashboard:view">{withSuspense(<DashboardPage />)}</PermissionGate>
              }
            />

            {domainNodes.map((domain) => {
              const entry = flattenLeaves(domain.children ?? [])[0];
              if (!entry?.path) return null;
              return <Route key={domain.key} path={`/${domain.key}`} element={<Navigate to={entry.path} replace />} />;
            })}

            {leafRoutes.map((node) => (
              <Route
                key={node.key}
                path={node.path}
                element={<PermissionGate permission={node.permission}>{withSuspense(<ModulePage />)}</PermissionGate>}
              />
            ))}

            {/* 403 与 404 位于主框架内，保证异常页面也保留侧边栏与页签导航 */}
            <Route path="/403" element={<ForbiddenPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
