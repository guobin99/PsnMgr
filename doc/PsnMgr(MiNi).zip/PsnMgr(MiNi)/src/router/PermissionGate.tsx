import type { ReactNode } from 'react';
import { useLocation } from 'react-router-dom';

import { usePermission } from '@/hooks/usePermission';
import ForbiddenPage from '@/pages/ForbiddenPage';
import type { PermissionCode } from '@/types/navigation';

interface PermissionGateProps {
  /** 访问该页面所需的权限码；不传表示不做页面级校验 */
  permission?: PermissionCode;
  children: ReactNode;
}

/**
 * 页面级权限守卫：防止用户通过直接输入地址、书签或外部链接越权访问。
 *
 * 未命中时在路由出口内渲染 403 结果页，保留主框架与页签，
 * 与需求文档「越权访问返回 403 提示」的约定一致。
 */
export default function PermissionGate({ permission, children }: PermissionGateProps) {
  const { can } = usePermission();
  const location = useLocation();

  if (permission && !can(permission)) {
    return <ForbiddenPage inline required={permission} path={location.pathname} />;
  }

  return <>{children}</>;
}
