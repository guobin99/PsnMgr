import type { PermissionCode, SessionUser } from '@/types/navigation';

/** 演示环境统一密码 */
export const DEMO_PASSWORD = '123456';

export interface RoleDefinition {
  roleNo: string;
  roleName: string;
  description: string;
  deptName: string;
  /** 权限码集合，支持 * 与 前缀通配 */
  permissions: PermissionCode[];
}

/**
 * 角色与权限映射（演示数据）。
 * 正式环境应由后端 /api/auth/profile 下发，权限来源为 CS 的 ST_RoleRight / ST_RightInfo / ST_MenuInfo。
 */
export const roleDefinitions: RoleDefinition[] = [
  {
    roleNo: 'R_ADMIN',
    roleName: '系统管理员',
    deptName: '信息中心',
    description: '全部业务域与全部操作权限',
    permissions: ['*'],
  },
  {
    roleNo: 'R_CASHIER',
    roleName: '卡务出纳',
    deptName: '财务处',
    description: '卡务中心全部业务、消费流水查询与跨域报表',
    permissions: [
      'dashboard:view',
      'card:*',
      'consume:record:*',
      'consume:report:*',
      'consume:summary:*',
      'report:*',
      'system:log:*',
    ],
  },
  {
    roleNo: 'R_HR',
    roleName: '人事考勤',
    deptName: '人力资源部',
    description: '考勤管理、人员档案与访客管理',
    permissions: [
      'dashboard:view',
      'attendance:*',
      'card:person:view',
      'card:dept:view',
      'card:face:view',
      'card:report:roster',
      'visitor:*',
      'report:overview',
      'report:attendance',
    ],
  },
  {
    roleNo: 'R_SECURITY',
    roleName: '门禁安保',
    deptName: '保卫处',
    description: '门禁管理、访客管理与通行记录查询',
    permissions: [
      'dashboard:view',
      'access:*',
      'visitor:*',
      'card:person:view',
      'card:face:view',
      'report:overview',
      'report:access',
    ],
  },
  {
    roleNo: 'R_CANTEEN',
    roleName: '食堂消费',
    deptName: '后勤服务集团',
    description: '消费管理、订餐管理与食堂报表',
    permissions: [
      'dashboard:view',
      'consume:*',
      'meal:*',
      'card:person:view',
      'report:overview',
      'report:consume',
      'report:meal',
    ],
  },
  {
    roleNo: 'R_VIEWER',
    roleName: '运营查看',
    deptName: '校务办公室',
    description: '仅查看工作台与报表中心',
    permissions: ['dashboard:view', 'report:*'],
  },
];

export interface DemoAccount {
  userName: string;
  displayName: string;
  roleNo: string;
}

/** 演示登录账号（对应角色权限，密码均为 DEMO_PASSWORD） */
export const demoAccounts: DemoAccount[] = [
  { userName: 'admin', displayName: '系统管理员', roleNo: 'R_ADMIN' },
  { userName: 'cashier', displayName: '出纳 - 张明', roleNo: 'R_CASHIER' },
  { userName: 'hr', displayName: '考勤 - 李慧', roleNo: 'R_HR' },
  { userName: 'security', displayName: '安保 - 王强', roleNo: 'R_SECURITY' },
  { userName: 'canteen', displayName: '食堂 - 赵磊', roleNo: 'R_CANTEEN' },
  { userName: 'viewer', displayName: '运营 - 陈婷', roleNo: 'R_VIEWER' },
];

export function findRole(roleNo: string): RoleDefinition | undefined {
  return roleDefinitions.find((role) => role.roleNo === roleNo);
}

/** 依据演示账号构造会话用户 */
export function buildDemoUser(account: DemoAccount): SessionUser | undefined {
  const role = findRole(account.roleNo);
  if (!role) return undefined;
  return {
    userId: `U_${account.userName.toUpperCase()}`,
    userName: account.userName,
    displayName: account.displayName,
    roleNo: role.roleNo,
    roleName: role.roleName,
    deptName: role.deptName,
    permissions: role.permissions,
  };
}

/**
 * 按登录账号匹配演示角色并构造会话用户。
 * 用于后端尚未下发权限码时的临时口径：后端一旦下发权限集合即以后端为准。
 */
export function buildDemoUserByAccount(userName: string): SessionUser | undefined {
  const normalized = userName.trim().toLowerCase();
  const account = demoAccounts.find((item) => item.userName.toLowerCase() === normalized);
  return account ? buildDemoUser(account) : undefined;
}