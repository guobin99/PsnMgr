import type { ThemeConfig } from 'antd';

/** 全站品牌常量：与登录页、侧边栏渐变、图标保持一致 */
export const BRAND = {
  name: '人脸通',
  fullName: '人脸通 · BS 管理平台',
  subtitle: 'Card · Consume · Access',
  primary: '#2f6fed',
  primaryDark: '#1d4ed8',
  teal: '#12b3a6',
  siderBg: '#0f1c33',
  siderBgDeep: '#0a1526',
  version: 'v1.0.0',
} as const;

/** 布局尺寸口径：顶栏、页签栏、侧边栏与内容区内边距的唯一来源 */
export const LAYOUT_METRICS = {
  /** 顶栏高度 */
  headerHeight: 56,
  /** 多页签栏高度 */
  tabsBarHeight: 40,
  /** 侧边栏展开宽度 */
  siderWidth: 240,
  /** 侧边栏折叠宽度 */
  siderCollapsedWidth: 64,
  /** 顶栏与内容区的左右内边距（两者必须一致，否则右侧对不齐） */
  contentPadding: 16,
  /** 页签栏左右内边距 */
  tabsPadding: 12,
  /** 内容区上下内边距 */
  contentPaddingBlock: 12,
} as const;

/** Ant Design 主题令牌 */
export const antdTheme: ThemeConfig = {
  token: {
    colorPrimary: BRAND.primary,
    colorInfo: BRAND.primary,
    colorSuccess: '#16a34a',
    colorWarning: '#f59e0b',
    colorError: '#e5484d',
    borderRadius: 6,
    fontSize: 14,
    fontFamily:
      '"PingFang SC", "Microsoft YaHei", "Helvetica Neue", "Segoe UI", Roboto, Arial, sans-serif',
    colorBgLayout: '#f4f6fa',
  },
  components: {
    Layout: {
      headerBg: '#ffffff',
      headerHeight: LAYOUT_METRICS.headerHeight,
      headerPadding: '0 16px',
      bodyBg: '#f4f6fa',
      siderBg: BRAND.siderBg,
    },
    Menu: {
      darkItemBg: BRAND.siderBg,
      darkSubMenuItemBg: BRAND.siderBgDeep,
      darkItemSelectedBg: BRAND.primary,
      darkItemHoverBg: 'rgba(255, 255, 255, 0.08)',
      darkItemColor: 'rgba(255, 255, 255, 0.78)',
      itemHeight: 40,
      itemMarginInline: 8,
      iconSize: 16,
      collapsedIconSize: 18,
    },
    Table: {
      headerBg: '#f7f9fc',
      headerColor: '#334155',
      rowHoverBg: '#f5f8ff',
    },
    Card: {
      headerFontSize: 15,
    },
    Tabs: {
      cardGutter: 4,
    },
  },
};
