import { App as AntdApp, ConfigProvider } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import dayjs from 'dayjs';
import 'dayjs/locale/zh-cn';

import AppRouter from '@/router';
import { AuthProvider } from '@/store/auth';
import { TabsProvider } from '@/store/tabs';
import { antdTheme } from '@/styles/theme';

dayjs.locale('zh-cn');

/**
 * 应用根组件：Provider 装配与主题注入。
 *
 * 装配顺序的约束：会话必须早于路由，否则登录守卫读不到登录态；
 * 多页签必须早于主框架，否则主框架同步页签时上下文缺失；
 * 主题与中文 locale 必须包在最外层，保证登录页与主框架的组件样式一致。
 */
export default function App() {
  return (
    <ConfigProvider locale={zhCN} theme={antdTheme}>
      <AntdApp>
        <AuthProvider>
          <TabsProvider>
            <AppRouter />
          </TabsProvider>
        </AuthProvider>
      </AntdApp>
    </ConfigProvider>
  );
}
