import axios, { type AxiosRequestConfig } from 'axios';

import { readStorage, STORAGE_KEYS } from '@/utils/storage';

/** 后端统一返回体：{ code, message, data } */
export interface ApiResponse<T> {
  code: number | string;
  message: string;
  data: T;
}

/** 成功码集合：兼容后端不同风格的成功码 */
const SUCCESS_CODES = new Set(['0', '200', 'SUCCESS', 'OK']);

/** 基础地址：环境变量未设置时回退为 /api，开发环境由 Vite 代理转发到后端 */
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

/** 未授权事件名：由 AuthProvider 监听并清理会话 */
export const UNAUTHORIZED_EVENT = 'psnmgr:unauthorized';

/** 统一异常：页面只需处理 message 与 code */
export class ApiError extends Error {
  readonly code: number | string;
  readonly status?: number;

  constructor(message: string, code: number | string = 'ERROR', status?: number) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
  }
}

export const http = axios.create({
  baseURL: API_BASE_URL,
  timeout: 20000,
  headers: { 'Content-Type': 'application/json' },
});

http.interceptors.request.use((config) => {
  const token = readStorage<string | null>(STORAGE_KEYS.token, null);
  if (token) {
    config.headers.set('Authorization', `Bearer ${token}`);
  }
  return config;
});

http.interceptors.response.use(
  (response) => {
    const body = response.data as ApiResponse<unknown> | unknown;

    // 统一返回体：按 code 判定成功与否，解包 data 部分
    if (body && typeof body === 'object' && 'code' in (body as Record<string, unknown>)) {
      const wrapped = body as ApiResponse<unknown>;
      if (SUCCESS_CODES.has(String(wrapped.code))) {
        return (wrapped.data ?? wrapped) as never;
      }
      throw new ApiError(wrapped.message || '业务处理失败', wrapped.code, response.status);
    }

    // 非统一返回体（如登录接口直接返回令牌对象）直接透传
    return body as never;
  },
  (error: unknown) => {
    if (axios.isAxiosError(error)) {
      const status = error.response?.status;

      if (status === 401) {
        // 派发全局未授权事件，保证并发 401 只触发一次会话清理
        window.dispatchEvent(new CustomEvent(UNAUTHORIZED_EVENT));
        return Promise.reject(new ApiError('登录状态已失效，请重新登录', 401, status));
      }

      if (status === 403) {
        return Promise.reject(new ApiError('无权限访问该资源', 403, status));
      }

      const payload = error.response?.data as ApiResponse<unknown> | undefined;
      return Promise.reject(
        new ApiError(payload?.message || error.message || '网络请求失败', payload?.code ?? status ?? 'NETWORK', status),
      );
    }

    return Promise.reject(error instanceof Error ? error : new ApiError('未知错误'));
  },
);

async function request<T>(config: AxiosRequestConfig): Promise<T> {
  const result = (await http.request(config)) as unknown as T;
  return result;
}

export function get<T>(url: string, params?: Record<string, unknown>): Promise<T> {
  return request<T>({ url, method: 'GET', params });
}

export function post<T>(url: string, data?: unknown): Promise<T> {
  return request<T>({ url, method: 'POST', data });
}

export function put<T>(url: string, data?: unknown): Promise<T> {
  return request<T>({ url, method: 'PUT', data });
}

export function del<T>(url: string, params?: Record<string, unknown>): Promise<T> {
  return request<T>({ url, method: 'DELETE', params });
}
