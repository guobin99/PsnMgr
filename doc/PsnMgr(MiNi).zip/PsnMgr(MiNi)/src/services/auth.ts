import { buildDemoUser, buildDemoUserByAccount, DEMO_PASSWORD, demoAccounts } from '@/config/roles';
import type { LoginPayload, LoginResult, SessionUser } from '@/types/navigation';

import { ApiError, post } from './http';

/** 演示登录开关：仅开发环境开启，生产构建恒为 false */
export const DEMO_LOGIN_ENABLED = import.meta.env.VITE_ENABLE_DEMO_LOGIN === 'true';

/** 后端返回的原始登录结果（兼容不同后端版本的字段命名） */
interface RawLoginResponse {
  token?: string;
  access_token?: string;
  accessToken?: string;
  expires_in?: number;
  user?: Record<string, unknown>;
  st_userinfo?: Record<string, unknown>;
  st_UserInfo?: Record<string, unknown>;
  [key: string]: unknown;
}

/** 从原始用户对象中取出第一个存在的字段 */
function pick(source: Record<string, unknown> | undefined, keys: string[]): string | undefined {
  if (!source) return undefined;
  for (const key of keys) {
    const value = source[key];
    if (typeof value === 'string' && value.trim()) return value;
  }
  return undefined;
}

/** 从原始用户对象中取出权限码集合 */
function pickPermissions(source: Record<string, unknown> | undefined): string[] | undefined {
  if (!source) return undefined;
  for (const key of ['permissions', 'Permissions', 'permissionCodes', 'RightCodes']) {
    const value = source[key];
    if (Array.isArray(value)) return value.map((item) => String(item));
  }
  return undefined;
}

/**
 * 把后端返回的用户对象映射为前端会话用户。
 *
 * 权限码优先取后端下发的权限集合（后端按 CS 的 ST_RoleRight / ST_RightInfo / ST_MenuInfo 映射）；
 * 后端尚未下发权限码时，按账号匹配内置演示角色，保证布局与导航阶段可独立验收。
 */
function mapSessionUser(raw: Record<string, unknown> | undefined, payload: LoginPayload): SessionUser {
  const account = payload.userName.trim();
  const userName = pick(raw, ['User_No', 'UserNo', 'userNo', 'userName', 'UserName']) ?? account;
  const displayName = pick(raw, ['User_Name', 'UserName', 'userName', 'DisplayName']) ?? account;

  const permissions = pickPermissions(raw) ?? buildDemoUserByAccount(account)?.permissions;

  return {
    userId: pick(raw, ['User_No', 'UserNo', 'userId']) ?? `U_${account.toUpperCase()}`,
    userName,
    displayName,
    roleNo: pick(raw, ['Role_No', 'RoleNo', 'roleNo']) ?? '',
    roleName: pick(raw, ['Role_Name', 'RoleName', 'roleName']) ?? '',
    deptName: pick(raw, ['Dept_Name', 'DeptName', 'deptName']) ?? '',
    permissions: permissions ?? [],
  };
}

/** 归一化登录返回体：兼容 { token, user } 与 { access_token, st_userinfo } 两种形态 */
function normalizeLoginResult(raw: RawLoginResponse | undefined, payload: LoginPayload): LoginResult {
  const token = raw?.token ?? raw?.access_token ?? raw?.accessToken;
  const userSource = raw?.user ?? raw?.st_userinfo ?? raw?.st_UserInfo;

  if (!token || !userSource) {
    throw new ApiError('登录接口返回数据不完整', 'BAD_RESPONSE');
  }

  return { token, user: mapSessionUser(userSource, payload) };
}

/** 演示账号离线登录：后端未就绪时保证前端布局与导航可独立验收 */
function demoLogin(payload: LoginPayload): LoginResult {
  const account = demoAccounts.find((item) => item.userName === payload.userName.trim());
  if (!account || payload.password !== DEMO_PASSWORD) {
    throw new ApiError('账号或密码错误（演示账号密码为 123456）', 'AUTH_FAILED');
  }
  const user = buildDemoUser(account);
  if (!user) {
    throw new ApiError('演示角色配置缺失', 'ROLE_NOT_FOUND');
  }
  return { token: `demo-token.${account.userName}.${Date.now()}`, user };
}

/**
 * 登录：优先调用 .NET RESTful 后端 /api/auth/login。
 *
 * 后端现网签名为 POST api/auth/login，请求体 UserNo / Password，返回 access_token / st_userinfo；
 * 本层同时兼容设计文档约定的 userName / password 与 token / user，并同时提交 userNo 字段，
 * 使两种后端实现都能正确绑定参数。
 *
 * 开发环境（VITE_ENABLE_DEMO_LOGIN=true）在后端网络不可用时回退到本地演示角色；
 * 后端明确返回鉴权失败或返回体异常时不回退，避免掩盖真实问题。
 */
export async function loginRequest(payload: LoginPayload): Promise<LoginResult> {
  try {
    const data = await post<RawLoginResponse>('/auth/login', {
      userName: payload.userName.trim(),
      userNo: payload.userName.trim(),
      password: payload.password,
    });
    return normalizeLoginResult(data, payload);
  } catch (error) {
    if (!DEMO_LOGIN_ENABLED) throw error;

    // 鉴权失败或返回体结构异常时不回退，直接暴露真实错误
    if (error instanceof ApiError && (error.status === 401 || error.status === 403 || error.code === 'BAD_RESPONSE')) {
      throw error;
    }

    return demoLogin(payload);
  }
}

/** 拉取当前登录用户与权限（后端不可用时保留本地会话） */
export async function fetchProfileRequest(): Promise<SessionUser> {
  const data = await post<RawLoginResponse>('/auth/profile');
  const source = data?.user ?? data?.st_userinfo ?? data?.st_UserInfo;
  if (!source) {
    throw new ApiError('用户档案接口返回数据不完整', 'BAD_RESPONSE');
  }
  return mapSessionUser(source, { userName: '', password: '' });
}

/** 退出登录：后端失败不阻塞前端会话清理 */
export async function logoutRequest(): Promise<void> {
  try {
    await post<void>('/auth/logout');
  } catch {
    /* 退出登录失败不阻塞前端会话清理 */
  }
}
