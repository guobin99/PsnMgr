import type { ReactNode } from 'react';

/** 权限码：采用「业务域:资源:操作」三段式，如 card:account:view */
export type PermissionCode = string;

/** 导航节点：分组节点仅含 children，叶子节点含 path */
export interface NavNode {
  /** 唯一键，全树内不得重复；分组节点与同层叶子须区别命名 */
  key: string;
  /** 菜单显示名称，同时用作面包屑与页签标题 */
  label: string;
  /** 叶子节点路由路径；分组节点为空表示不可跳转 */
  path?: string;
  /** 业务域图标，由总装文件统一注入 */
  icon?: ReactNode;
  /** 访问所需权限码；叶子为页面级权限码，业务域为域级查看权限 */
  permission?: PermissionCode;
  /** 功能说明，用于占位页描述与菜单提示 */
  description?: string;
  /** 是否在菜单中隐藏（仍可路由访问） */
  hidden?: boolean;
  /** 子节点；有子节点即视为分组或业务域 */
  children?: NavNode[];
}

/** 业务域元信息 */
export interface DomainMeta {
  key: string;
  label: string;
  icon: ReactNode;
  /** 域级权限码（域:view），当前仅作域级授权语义与兜底字段 */
  permission: PermissionCode;
  description: string;
  /** 业务域入口路径（第一个叶子节点） */
  entryPath: string;
}

/** 面包屑条目 */
export interface CrumbItem {
  key: string;
  label: string;
  path?: string;
}

/** 多页签条目 */
export interface TabItem {
  /** 与菜单节点 key 一致，保证同一页面只开一个页签 */
  key: string;
  path: string;
  title: string;
  /** 所属业务域名称 */
  domain: string;
  /** 是否可关闭：工作台页签固定为 false */
  closable: boolean;
}

/** 占位页渲染元信息 */
export interface ModulePageMeta {
  path: string;
  title: string;
  domain: string;
  description: string;
  primaryAction: string;
  permission?: PermissionCode;
}

/** 全局搜索索引条目 */
export interface MenuSearchItem {
  /** 路由路径 */
  path: string;
  /** 菜单名称 */
  label: string;
  /** 所属业务域名称 */
  domain: string;
  /** 层级链路（业务域 / 分组 / 页面） */
  trail: string;
  /** 链路层级数，用于排序与展示 */
  depth: number;
}

/** 登录用户 */
export interface SessionUser {
  /** 用户主键，演示态以 U 加账号大写构造，正式态取 CS 操作员编号 */
  userId: string;
  /** 登录账号 */
  userName: string;
  /** 显示姓名 */
  displayName: string;
  /** 角色编号 */
  roleNo: string;
  /** 角色名称，用于顶栏角色标签 */
  roleName: string;
  /** 所属部门 */
  deptName: string;
  /** 权限码集合，前端权限判定的唯一依据 */
  permissions: PermissionCode[];
}

/** 登录请求参数 */
export interface LoginPayload {
  userName: string;
  password: string;
}

/** 登录结果 */
export interface LoginResult {
  token: string;
  user: SessionUser;
}
