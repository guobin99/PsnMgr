# 人脸通 BS 管理平台 · 布局与导航及权限控制

> 工程目录：`E:\zhimen\2026Ant\PsnMgr(MiNi)`
> 技术栈：React 18.3 + TypeScript 5.6 + Vite 5.4 + Ant Design 5.29 + React Router 6.30 + axios

本工程实现人脸通 BS 一体化管理平台的**前端布局、导航与权限控制**，覆盖需求文档 4.1「布局与导航」与
《人脸通 BS 系统-布局与导航及权限控制详细设计文档》的导航（第 4 章）、路由（第 5 章）、
权限控制（第 6 章）、关键流程（第 7 章）、状态与存储（第 8 章）、接口约定（第 9 章）。

设计文档的第三章「布局详细设计」在本次交付口径中已被移除，**布局部分按需求文档 4.1 重新设计**，
设计条文见 [`doc/布局与导航及权限控制实现说明.md`](doc/布局与导航及权限控制实现说明.md)。

---

## 一、快速开始

```bash
npm install          # 安装依赖
npm run dev          # 开发服务（默认 http://127.0.0.1:5276）
npm run typecheck    # TypeScript 类型检查
npm run build        # 类型检查 + 生产构建
npm run verify       # 权限与导航逻辑一致性校验（112 项）
npm run verify:ui    # 浏览器端验收（32 项，需先启动 dev）
```

### 环境变量

| 变量 | 开发环境 | 生产环境 | 说明 |
| --- | --- | --- | --- |
| `VITE_API_BASE_URL` | `/api` | `/api` | 请求基础地址，开发期由 Vite 代理转发 |
| `VITE_PROXY_TARGET` | `http://localhost:5187` | — | 开发代理目标（PsnMgrService） |
| `VITE_ENABLE_DEMO_LOGIN` | `true` | `false` | 演示登录回退开关，生产必须关闭 |

> 端口说明：本机 5273 / 5274 已被同机其他前端工程占用，本工程开发端口固定为 **5276**。

### 演示账号（仅开发环境）

`admin` / `cashier` / `hr` / `security` / `canteen` / `viewer`，密码统一 `123456`。
后端未就绪时自动回退到本地演示角色；后端明确返回鉴权失败时不回退，直接提示真实错误。

---

## 二、目录结构

```
src/
├─ App.tsx                    应用根组件：Provider 装配与主题注入
├─ main.tsx                   入口：createRoot 挂载与全局样式引入
├─ config/
│  ├─ menu.tsx                导航树总装与派生工具（单一数据源）
│  ├─ menu/card.tsx           卡务中心（5 分组 / 29 页）
│  ├─ menu/consume.tsx        消费管理（4 分组 / 26 页）
│  ├─ menu/attendance-access.tsx   考勤管理（5/26）与门禁管理（7/37）
│  ├─ menu/meal-visitor-utility.tsx 订餐（4/19）、访客（4/10）、水控巡更（2/15）
│  ├─ menu/report-system.tsx  报表中心（2/9）与系统管理（3/16）
│  └─ roles.ts                六个演示角色、演示账号与会话用户构造
├─ layouts/
│  ├─ AdminLayout.tsx         主框架：侧边栏 / 顶栏 / 多页签 / 内容区
│  └─ components/             BrandLogo、SideMenu、HeaderBar、GlobalSearch、UserMenu、AppBreadcrumb、TabsBar
├─ router/
│  ├─ index.tsx               路由总装：登录、鉴权、域重定向、187 条叶子路由、403/404
│  ├─ RequireAuth.tsx         登录守卫
│  └─ PermissionGate.tsx      页面级权限守卫
├─ pages/                     LoginPage、DashboardPage、ModulePage（占位页）、ForbiddenPage、NotFoundPage
├─ services/                  http.ts（axios 实例与拦截器）、auth.ts（登录与演示回退）
├─ store/                     auth.tsx（会话）、tabs.tsx（多页签）
├─ hooks/usePermission.ts     权限判定 Hook
├─ utils/                     permission.ts（匹配算法）、storage.ts（本地存储）
├─ styles/                    global.css（布局类与 CSS 变量）、theme.ts（品牌常量与主题令牌）
└─ types/navigation.ts        导航、权限、页签、会话类型定义
```

---

## 三、导航与权限要点

### 3.1 单一数据源

菜单树既是导航展示的来源，也派生路由表、面包屑、搜索索引与占位页元信息，避免两处维护、两处走样。
规模口径与设计文档 4.3 一致，已由 `npm run verify` 自动校验：

| 统计项 | 数量 |
| --- | --- |
| 菜单节点总数 | 233（工作台 1 + 业务域 9 + 分组 36 + 叶子 187） |
| 业务域节点 | 9 |
| 子功能分组 | 36 |
| 叶子页面 | 187 |
| 可路由路径 | 188（含工作台） |
| 权限码字面量 | 197 |
| 重复节点键 / 重复路由 | 0 / 0 |

**187 条「路由路径 — 权限码」与设计文档附录 A 全量对照表逐条一致**（已由脚本比对确认）。

### 3.2 三层递进控制

| 层级 | 职责 | 实现 |
| --- | --- | --- |
| 菜单级 | 看不看得见 | `filterMenuByPermission` 渲染前裁剪，子项全被过滤则父节点隐藏 |
| 页面级 | 进不进得去 | `PermissionGate` 拦截直连地址，输出 403 结果页并保留主框架 |
| 操作级 | 能不能改 | `usePermission` + `deriveOperationPermission`（`:view` 派生 `:edit`）控制按钮可用性 |

权限码为三段式「业务域:资源:操作」，匹配算法支持全局通配 `*`、精确匹配与前缀通配 `card:*`。

### 3.3 前后端职责边界

前端只做表现层控制。后端必须对每个业务接口独立鉴权，越权返回 403；
数据范围权限（本人 / 本部门 / 本机台 / 全部）由后端按 CS 的 `ST_DeptRight`、`ST_MOCRight` 执行，前端不做数据裁剪。

---

## 四、与后端的对接口径

需求文档 14.3.1 要求前端请求层统一带 `/api` 前缀。本工程的请求层同时兼容两种后端形态：

| 环节 | 设计文档口径 | 现有后端 `AuthController` 实际形态 | 本工程处理 |
| --- | --- | --- | --- |
| 登录路径 | `POST /auth/login` | `POST api/auth/login` | 请求层统一 `/api` 前缀 |
| 请求体 | `userName`、`password` | `UserNo`、`Password` | 同时提交 `userName` 与 `userNo`，两种后端都能绑定 |
| 响应体 | `token`、`user` | `access_token`、`st_userinfo` | `services/auth.ts` 归一化为 `{ token, user }` |
| 权限集合 | `user.permissions` | 尚未下发 | 后端下发 `permissions` 优先；未下发时按账号匹配内置演示角色（开发期临时口径） |

登录失败且失败原因属于网络异常、超时或服务未启动时，开发环境回退到本地演示角色；
后端明确返回鉴权失败或返回体结构异常时不回退，避免掩盖真实问题。

---

## 五、验证结论

| 验证 | 手段 | 结果 |
| --- | --- | --- |
| 导航与权限逻辑 | `npm run verify` | 112 项全部通过（规模口径、匹配算法、六个角色可见范围、派生工具一致性） |
| 浏览器端行为 | `npm run verify:ui` | 32 项全部通过（登录守卫、菜单裁剪、顶栏几何、面包屑、页签回退、搜索、403/404、折叠、响应式） |
| 类型检查 | `npm run typecheck` | 通过（strict + noUnusedLocals + noUnusedParameters） |
| 生产构建 | `npm run build` | 通过，3128 个模块，约 16 秒 |

顶栏右对齐在 1440 / 1100 视口下实测：内容行宽度恒等于外壳宽度（1200 = 1200），
右侧动作区右边缘距容器右沿恒为 **16px**，弹性占位元素宽度 355px，无横向溢出。
截图见 [`doc/screenshots`](doc/screenshots)。

---

## 六、已知限制

1. 187 个业务路由均指向同一个占位页模板，页面暂无真实业务能力；后续逐页替换为真实业务页面时，
   路由、菜单、面包屑、页签与权限判定均不需要改动。
2. 通知角标与待办数量为静态演示数据，未接入真实待办接口。
3. 菜单搜索为包含匹配，暂无拼音与首字母支持。
4. 界面仅简体中文；页签不做持久化，刷新后重置为当前页。
5. 后端尚未下发权限码集合前，前端按账号匹配内置演示角色，属于开发期临时口径，正式部署前必须由后端补齐。
