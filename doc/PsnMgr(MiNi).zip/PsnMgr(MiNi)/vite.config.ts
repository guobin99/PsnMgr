import { fileURLToPath, URL } from 'node:url';
import react from '@vitejs/plugin-react';
import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const proxyTarget = env.VITE_PROXY_TARGET || 'http://localhost:5187';

  return {
    plugins: [react()],
    resolve: {
      alias: {
        // 路径别名 @ 指向 src，跨目录引用一律用别名
        '@': fileURLToPath(new URL('./src', import.meta.url)),
      },
    },
    server: {
      host: '127.0.0.1',
      // 5273 / 5274 已被同机其他前端工程占用，本工程默认使用 5276
      port: 5276,
      open: false,
      proxy: {
        // 开发环境转发到 .NET RESTful 后端（默认 PsnMgrService http profile）
        '/api': {
          target: proxyTarget,
          changeOrigin: true,
          secure: false,
          ws: true,
        },
      },
    },
    build: {
      outDir: 'dist',
      sourcemap: false,
      chunkSizeWarningLimit: 1500,
      rollupOptions: {
        output: {
          manualChunks: {
            'vendor-react': ['react', 'react-dom', 'react-router-dom'],
            'vendor-antd': ['antd', '@ant-design/icons'],
          },
        },
      },
    },
  };
});
