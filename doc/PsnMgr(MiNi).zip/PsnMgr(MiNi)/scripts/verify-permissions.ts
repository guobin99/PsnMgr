/**
 * 权限与导航一致性校验脚本（不依赖浏览器，直接跑导航树与权限判定逻辑）。
 *
 * 运行：npm run verify
 * 校验内容：
 *   1. 导航树规模与设计文档附录 A 的口径（233 节点 / 36 分组 / 187 叶子 / 197 权限码）；
 *   2. 权限码匹配算法（全局通配、精确匹配、前缀通配、空要求、空集合）；
 *   3. 六个演示角色的菜单过滤结果与设计文档附录 B 的「实际可见范围」一致；
 *   4. 菜单、路由、面包屑、搜索索引的派生工具一致性。
 */
import {
  buildDomainEntries,
  buildMenuSearchIndex,
  filterMenuByPermission,
  findNodeByPath,
  flattenLeaves,
  flattenMenu,
  getBreadcrumbs,
  getDomainOf,
  getMenuTrail,
  getModulePageMeta,
  getOpenKeys,
  navigation,
} from '@/config/menu';
import { roleDefinitions } from '@/config/roles';
import { deriveOperationPermission, describePermission, hasAnyPermission, hasPermission } from '@/utils/permission';

let failed = 0;

function check(title: string, condition: boolean, detail = ''): void {
  if (condition) {
    console.log(`  [通过] ${title}`);
  } else {
    failed += 1;
    console.log(`  [失败] ${title}${detail ? ` —— ${detail}` : ''}`);
  }
}

function section(title: string): void {
  console.log(`\n${title}`);
}

/* ---------------------------------------------------------------- 1. 规模 */
section('一、导航树规模（对齐设计文档 4.3）');
const all = flattenMenu();
const allLeaves = flattenLeaves();
/** 叶子页面口径：工作台单独计数，不计入 187 个业务页面 */
const leaves = allLeaves.filter((n) => n.path !== '/dashboard');
const groups = all.filter((n) => n.children?.length && n.key !== 'dashboard').length - 9;
const domains = navigation.filter((n) => n.key !== 'dashboard').length;
const permissionCodes = new Set<string>([
  ...leaves.map((n) => n.permission).filter(Boolean),
  ...navigation.filter((n) => n.key !== 'dashboard').map((n) => n.permission).filter(Boolean),
  'dashboard:view',
]);

check('节点总数为 233（工作台 1 + 业务域 9 + 分组 36 + 叶子 187）', all.length === 233, `实际 ${all.length}`);
check('业务域为 9 个', domains === 9, `实际 ${domains}`);
check('分组为 36 个', groups === 36, `实际 ${groups}`);
check('叶子页面为 187 个', leaves.length === 187, `实际 ${leaves.length}`);
check('权限码字面量为 197 个', permissionCodes.size === 197, `实际 ${permissionCodes.size}`);
check('节点键全局唯一', new Set(all.map((n) => n.key)).size === all.length);
check('路由路径全局唯一', new Set(leaves.map((n) => n.path)).size === leaves.length);
check(
  '工作台权限码为 dashboard:view',
  navigation[0].permission === 'dashboard:view' && navigation[0].path === '/dashboard',
);

/* ------------------------------------------------------------ 2. 匹配算法 */
section('二、权限码匹配算法（对齐设计文档 6.3）');
check('无权限要求视为公开', hasPermission([], undefined) === true);
check('空权限集合拒绝任何要求', hasPermission([], 'card:person:view') === false);
check('全局通配 * 命中任意权限', hasPermission(['*'], 'card:person:view') === true);
check('精确匹配命中', hasPermission(['card:person:view'], 'card:person:view') === true);
check('前缀通配 card:* 命中 card:person:view', hasPermission(['card:*'], 'card:person:view') === true);
check('前缀通配不跨域命中', hasPermission(['card:*'], 'consume:record:view') === false);
check('两级前缀通配 consume:record:* 命中 consume:record:view', hasPermission(['consume:record:*'], 'consume:record:view') === true);
check('两段权限 card:person 不命中 card:person:view', hasPermission(['card:person'], 'card:person:view') === false);
check('hasAnyPermission 任一命中即通过', hasAnyPermission(['report:*'], ['card:person:view', 'report:overview']) === true);
check('deriveOperationPermission 由 view 派生 edit', deriveOperationPermission('card:person:view', 'edit') === 'card:person:edit');
check('deriveOperationPermission 对非 view 权限原样返回', deriveOperationPermission('card:report:cashier', 'edit') === 'card:report:cashier');
check('describePermission 生成可读文案', describePermission('card:person:view') === 'card · person · view');

/* ------------------------------------------------ 3. 演示角色菜单可见范围 */
section('三、演示角色菜单过滤（对齐设计文档附录 B「实际可见范围」）');

interface Expectation {
  roleNo: string;
  /** 该角色应当可见的业务域 */
  domains: string[];
  /** 该角色至少应看到的叶子页面路径 */
  mustSee: string[];
  /** 该角色不应看到的叶子页面路径 */
  mustNotSee: string[];
}

const expectations: Expectation[] = [
  {
    roleNo: 'R_ADMIN',
    domains: ['card', 'consume', 'attendance', 'access', 'meal', 'visitor', 'utility', 'report', 'system'],
    mustSee: ['/card/person', '/consume/records', '/attendance/daily', '/access/controller', '/meal/order', '/visitor/apply', '/utility/water/card-type', '/report/overview', '/system/operator'],
    mustNotSee: [],
  },
  {
    roleNo: 'R_CASHIER',
    domains: ['card', 'consume', 'report', 'system'],
    mustSee: ['/card/person', '/card/recharge', '/card/report/cashier', '/consume/records', '/consume/report/normal', '/consume/summary/dept', '/report/overview', '/system/log/system'],
    mustNotSee: ['/attendance/daily', '/access/controller', '/meal/order', '/visitor/apply'],
  },
  {
    roleNo: 'R_HR',
    domains: ['attendance', 'card', 'visitor', 'report'],
    mustSee: ['/attendance/daily', '/attendance/report/month', '/card/person', '/card/dept', '/card/face', '/card/report/roster', '/visitor/apply', '/report/overview', '/report/attendance'],
    mustNotSee: ['/consume/records', '/access/controller', '/meal/order', '/system/operator'],
  },
  {
    roleNo: 'R_SECURITY',
    domains: ['access', 'visitor', 'card', 'report'],
    mustSee: ['/access/controller', '/access/record/normal', '/visitor/apply', '/card/person', '/card/face', '/report/access'],
    mustNotSee: ['/consume/records', '/attendance/daily', '/meal/order', '/system/operator'],
  },
  {
    roleNo: 'R_CANTEEN',
    domains: ['consume', 'meal', 'card', 'report'],
    mustSee: ['/consume/records', '/consume/report/normal', '/meal/order', '/card/person', '/report/consume', '/report/meal'],
    mustNotSee: ['/attendance/daily', '/access/controller', '/system/operator'],
  },
  {
    roleNo: 'R_VIEWER',
    domains: ['report'],
    mustSee: ['/report/overview', '/report/template', '/report/export-task'],
    mustNotSee: ['/card/person', '/consume/records', '/attendance/daily', '/access/controller', '/meal/order', '/visitor/apply', '/system/operator'],
  },
];

for (const expectation of expectations) {
  const role = roleDefinitions.find((r) => r.roleNo === expectation.roleNo);
  if (!role) {
    check(`${expectation.roleNo} 角色定义存在`, false);
    continue;
  }
  const tree = filterMenuByPermission(navigation, role.permissions);
  const visibleDomains = tree.filter((n) => n.key !== 'dashboard').map((n) => n.key);
  const visiblePaths = new Set(flattenLeaves(tree).map((n) => n.path));

  check(
    `${role.roleNo}（${role.roleName}）可见业务域为 ${expectation.domains.join('/')}`,
    JSON.stringify([...visibleDomains].sort()) === JSON.stringify([...expectation.domains].sort()),
    `实际 ${visibleDomains.join('/')}`,
  );
  for (const path of expectation.mustSee) {
    check(`${role.roleNo} 应可见 ${path}`, visiblePaths.has(path));
  }
  for (const path of expectation.mustNotSee) {
    check(`${role.roleNo} 不应可见 ${path}`, !visiblePaths.has(path));
  }
  check(`${role.roleNo} 工作台始终可见`, visiblePaths.has('/dashboard'));
}

/* ---------------------------------------------------- 4. 派生工具一致性 */
section('四、派生工具一致性（菜单 / 路由 / 面包屑 / 搜索同源）');
check(
  '业务域展示顺序为 卡务→消费→考勤→门禁→订餐→访客→水控巡更→报表→系统',
  navigation
    .filter((n) => n.key !== 'dashboard')
    .map((n) => n.key)
    .join(',') === 'card,consume,attendance,access,meal,visitor,utility,report,system',
);
check('工作台位于导航树首位', navigation[0].key === 'dashboard');
const samplePath = '/card/report/roster';
const trail = getMenuTrail(samplePath);
check('链路为 业务域 / 分组 / 页面 三级', trail.length === 3, `实际 ${trail.length}`);
check('链路首节点为业务域', trail[0]?.key === 'card');
check('所属业务域可反查', getDomainOf(samplePath)?.key === 'card');
check('面包屑与链路一致', getBreadcrumbs(samplePath).length === trail.length);
check('面包屑首项为业务域', getBreadcrumbs(samplePath)[0]?.label === '卡务中心');
check('展开键为父级链路', getOpenKeys(samplePath).join(',') === trail.slice(0, -1).map((n) => n.key).join(','));
check('按路径可反查节点', findNodeByPath(samplePath)?.label === '人员花名册');
check('占位页元信息可派生', getModulePageMeta(samplePath)?.title === '人员花名册');
check('报表类页面主操作为导出数据', getModulePageMeta('/consume/report/normal')?.primaryAction === '导出数据');
check('普通页面主操作为新增页面名', getModulePageMeta('/card/person')?.primaryAction === '新增人员档案');
check('业务域入口指向首个叶子', buildDomainEntries()[0]?.entryPath === '/card/person');
check('搜索索引覆盖全部可路由页面', buildMenuSearchIndex().length === 188, `实际 ${buildMenuSearchIndex().length}`);
check('未知路径链路为空', getMenuTrail('/not-exist').length === 0);
check('未知路径无占位页元信息', getModulePageMeta('/not-exist') === undefined);

/* ------------------------------------------------------------------ 汇总 */
console.log('');
if (failed === 0) {
  console.log('全部校验通过。');
} else {
  console.log(`存在 ${failed} 项校验失败。`);
  process.exit(1);
}
