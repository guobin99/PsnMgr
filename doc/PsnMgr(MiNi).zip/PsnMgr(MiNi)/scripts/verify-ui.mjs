/**
 * 浏览器端验收脚本（Playwright + 本机 Edge/Chromium）。
 *
 * 运行前先启动开发服务：npm run dev
 * 运行：npm run verify:ui
 *
 * 可用环境变量：
 *   VERIFY_BASE_URL      默认 http://127.0.0.1:5276
 *   VERIFY_BROWSER_PATH  浏览器可执行文件路径，默认取本机 Edge
 *
 * 校验内容：登录跳转、演示登录、菜单规模与权限裁剪、顶栏右对齐几何、
 * 面包屑与页签联动、全局搜索、越权 403、侧边栏折叠、响应式与 404 兜底。
 */
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { chromium } from 'playwright-core';

const BASE = process.env.VERIFY_BASE_URL || 'http://127.0.0.1:5276';
const OUT = resolve(dirname(fileURLToPath(import.meta.url)), '../doc/screenshots');
const BROWSER = process.env.VERIFY_BROWSER_PATH || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
mkdirSync(OUT, { recursive: true });

const results = [];
function check(title, ok, detail = '') {
  results.push({ title, ok, detail });
  console.log(`${ok ? '[通过]' : '[失败]'} ${title}${detail ? ' —— ' + detail : ''}`);
}

const browser = await chromium.launch({ executablePath: BROWSER, headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await context.newPage();

/* ---------------------------------------------------- 1. 登录页与登录守卫 */
await page.goto(BASE + '/dashboard', { waitUntil: 'networkidle' });
await page.waitForURL('**/login', { timeout: 10000 }).catch(() => undefined);
await page.waitForTimeout(500);
check('未登录访问受保护路径被重定向到登录页', page.url().includes('/login'), page.url());
check('登录页渲染品牌标题', (await page.locator('.login-page__title').innerText()).includes('人脸通'));
const demoTags = await page.locator('.login-card .ant-tag').count();
check('开发环境展示 6 个演示账号', demoTags === 6, `实际 ${demoTags}`);
await page.screenshot({ path: OUT + '/01-login.png' });

/* ---------------------------------------------------- 2. 登录与菜单规模 */
await page.locator('.login-card .ant-tag', { hasText: 'admin' }).first().click();
await page.locator('.login-card button[type="submit"]').click();
await page.waitForURL('**/dashboard', { timeout: 15000 });
await page.waitForTimeout(900);
check('管理员登录后进入工作台', page.url().endsWith('/dashboard'));

/** antd inline 菜单按需渲染子级，需逐级展开后才能统计全部节点 */
async function expandAll() {
  for (let i = 0; i < 120; i += 1) {
    const subs = page.locator('.app-sider__menu li.ant-menu-submenu');
    const n = await subs.count();
    let clicked = false;
    for (let j = 0; j < n; j += 1) {
      const li = subs.nth(j);
      if ((await li.locator('ul').count()) === 0) {
        await li.locator('.ant-menu-submenu-title').click();
        await page.waitForTimeout(150);
        clicked = true;
        break;
      }
    }
    if (!clicked) break;
  }
}

await expandAll();
const leafCount = await page.locator('.app-sider__menu .ant-menu-item').count();
const groupCount = await page.locator('.app-sider__menu ul.ant-menu-sub > li.ant-menu-submenu').count();
const domainCount = await page.locator('.app-sider__menu > ul > li.ant-menu-submenu').count();
check('管理员可见 9 个业务域', domainCount === 9, `实际 ${domainCount}`);
check('管理员可见 36 个子功能分组', groupCount === 36, `实际 ${groupCount}`);
check('管理员可见全部 187 个业务页面（不含工作台）', leafCount - 1 === 187, `实际 ${leafCount}`);

/* ------------------------------------------- 3. 顶栏右对齐几何（10.2 约束） */
const geo = await page.evaluate(() => {
  const shell = document.querySelector('.app-header');
  const bar = document.querySelector('.app-header-bar');
  const spacer = document.querySelector('.app-header__spacer');
  const last = bar?.lastElementChild;
  const shellRect = shell.getBoundingClientRect();
  const barRect = bar.getBoundingClientRect();
  const lastRect = last.getBoundingClientRect();
  return {
    shellWidth: shellRect.width,
    barWidth: barRect.width,
    spacerWidth: spacer ? spacer.getBoundingClientRect().width : -1,
    rightGap: shellRect.right - lastRect.right,
    shellHasDisplayFlex: getComputedStyle(shell).display,
    sameClass: shell.className === bar.className,
    barPaddingLeft: getComputedStyle(bar).paddingLeft,
  };
});
check('顶栏外壳与内容行未复用同一类名', !geo.sameClass);
check('顶栏外壳不参与横向排布', geo.shellHasDisplayFlex !== 'flex', geo.shellHasDisplayFlex);
check('内容行宽度等于外壳宽度', Math.abs(geo.barWidth - geo.shellWidth) < 1, `${geo.barWidth} vs ${geo.shellWidth}`);
check('右侧动作区贴住右边界（间距 16px）', Math.abs(geo.rightGap - 16) < 1.5, `实际 ${geo.rightGap}px`);
check('弹性占位元素存在且宽度为正', geo.spacerWidth > 0, `实际 ${geo.spacerWidth}px`);
check('顶栏内容行左内边距为 16px', geo.barPaddingLeft === '16px', geo.barPaddingLeft);

/* ------------------------------------------- 4. 导航联动：菜单 → 页面 → 面包屑 */
await expandAll();
await page.locator('.app-sider__menu .ant-menu-item', { hasText: '消费流水' }).first().click();
await page.waitForURL('**/consume/records', { timeout: 10000 });
await page.waitForTimeout(600);
const crumbs = (await page.locator('.app-crumbs .ant-breadcrumb-link').allInnerTexts())
  .map((t) => t.trim())
  .filter(Boolean);
check('面包屑为 首页/消费管理/业务处理/消费流水', crumbs.join('/') === '首页/消费管理/业务处理/消费流水', crumbs.join(' | '));
check('页面标题由占位页元信息派生', (await page.locator('.module-page__title').innerText()) === '消费流水');

const tabTitles = await page.locator('.app-tabsbar .ant-tabs-tab').allInnerTexts();
check('多页签已打开工作台与消费流水', tabTitles.length === 2, tabTitles.join(' | '));
check(
  '工作台页签不可关闭',
  (await page.locator('.app-tabsbar .ant-tabs-tab').first().locator('.ant-tabs-tab-remove').count()) === 0,
);

/* ------------------------------------------- 5. 全局搜索 */
await page.locator('.app-header__search input').fill('考勤日报');
await page.waitForTimeout(500);
const candidates = await page.locator('.ant-dropdown-menu-item').allInnerTexts();
check('全局搜索命中考勤日报表', candidates.some((t) => t.includes('考勤日报表')), candidates.join(' | '));
await page.keyboard.press('Escape');
await page.waitForTimeout(300);

/* ------------------------------------------- 6. 页签关闭与回退策略 */
await expandAll();
await page.locator('.app-sider__menu .ant-menu-item', { hasText: '人员档案' }).first().click();
await page.waitForTimeout(600);
await page.locator('.app-tabsbar .ant-tabs-tab', { hasText: '消费流水' }).locator('.ant-tabs-tab-remove').click();
await page.waitForTimeout(500);
check('关闭非激活页签后当前页面不变', page.url().includes('/card/person'), page.url());

await page.locator('.app-tabsbar .ant-tabs-tab', { hasText: '人员档案' }).locator('.ant-tabs-tab-remove').click();
await page.waitForTimeout(600);
// 人员档案为最后一个页签，右侧无相邻项，按「右侧相邻 → 左侧相邻 → 工作台」回退
check('关闭最后一个激活页签回退到工作台', page.url().endsWith('/dashboard'), page.url());
const tabsAfter = await page.locator('.app-tabsbar .ant-tabs-tab').count();
check('页签回退后仅剩工作台', tabsAfter === 1, `实际 ${tabsAfter}`);

/* ------------------------------------------- 7. 页面级权限（管理员全部可进） */
await page.goto(BASE + '/system/log/system', { waitUntil: 'networkidle' });
await page.waitForTimeout(600);
check('管理员可访问系统日志页面', (await page.locator('.module-page__title').innerText()) === '系统日志');
await page.screenshot({ path: OUT + '/02-dashboard-admin.png' });

/* ---------------------------------------------------- 8. 切换到运营查看角色 */
await page.locator('.app-header__action', { hasText: '系统管理员' }).click();
await page.waitForTimeout(300);
await page.locator('.ant-dropdown-menu-item', { hasText: '退出登录' }).click();
await page.waitForURL('**/login', { timeout: 10000 });
await page.waitForTimeout(500);

await page.locator('.login-card .ant-tag', { hasText: 'viewer' }).first().click();
await page.locator('.login-card button[type="submit"]').click();
await page.waitForURL('**/dashboard', { timeout: 15000 });
await page.waitForTimeout(900);
await expandAll();

const viewerDomains = await page.locator('.app-sider__menu > ul > li.ant-menu-submenu').count();
const viewerLeaves = await page.locator('.app-sider__menu .ant-menu-item').count();
check('运营查看仅可见 1 个业务域（报表中心）', viewerDomains === 1, `实际 ${viewerDomains}`);
check('运营查看仅可见 9 个报表页面（不含工作台）', viewerLeaves - 1 === 9, `实际 ${viewerLeaves}`);
check(
  '运营查看可见业务域为报表中心',
  (await page.locator('.app-sider__menu .ant-menu-submenu-title').first().innerText()).includes('报表中心'),
);

/* ---------------------------------------------------- 9. 越权直连 → 403 */
await page.goto(BASE + '/card/person', { waitUntil: 'networkidle' });
await page.waitForTimeout(800);
const is403 =
  (await page.locator('.ant-result-title').count()) > 0 &&
  (await page.locator('.ant-result-title').innerText()).includes('403');
check('越权直连访问被 403 拦截', is403);
check('403 页面保留主框架（侧边栏仍可见）', (await page.locator('.app-sider').count()) === 1);
const forbiddenText = await page.locator('.ant-result-subtitle').innerText();
check('403 页面展示所需权限码', forbiddenText.includes('card:person:view'), forbiddenText.replace(/\s+/g, ' ').slice(0, 120));
await page.screenshot({ path: OUT + '/03-403-viewer.png' });

/* ---------------------------------------------------- 10. 折叠与响应式 */
await page.goto(BASE + '/dashboard', { waitUntil: 'networkidle' });
await page.waitForTimeout(600);
await page.locator('.app-header__trigger').first().click();
await page.waitForTimeout(500);
const siderWidth = await page.locator('.app-sider').evaluate((el) => el.getBoundingClientRect().width);
check('折叠后侧边栏宽度为 64px', Math.abs(siderWidth - 64) < 1, `实际 ${siderWidth}px`);
await page.locator('.app-header__trigger').first().click();
await page.waitForTimeout(400);

await page.setViewportSize({ width: 1100, height: 800 });
await page.waitForTimeout(500);
const geo1100 = await page.evaluate(() => {
  const shell = document.querySelector('.app-header').getBoundingClientRect();
  const bar = document.querySelector('.app-header-bar').getBoundingClientRect();
  const last = document.querySelector('.app-header-bar').lastElementChild.getBoundingClientRect();
  return { barWidth: bar.width, shellWidth: shell.width, rightGap: shell.right - last.right };
});
check('1100px 视口下内容行仍撑满外壳', Math.abs(geo1100.barWidth - geo1100.shellWidth) < 1);
check('1100px 视口下右间距仍为 16px', Math.abs(geo1100.rightGap - 16) < 1.5, `实际 ${geo1100.rightGap}px`);
await page.screenshot({ path: OUT + '/04-responsive-1100.png' });

await page.setViewportSize({ width: 1440, height: 900 });
await page.waitForTimeout(400);

/* ---------------------------------------------------- 11. 404 兜底 */
await page.goto(BASE + '/not-exist-page', { waitUntil: 'networkidle' });
await page.waitForTimeout(600);
check('未知路径渲染 404', (await page.locator('.ant-result-title').innerText()).includes('404'));

await browser.close();

const failed = results.filter((r) => !r.ok);
console.log('');
console.log(
  failed.length === 0
    ? `浏览器验收全部通过（${results.length} 项）`
    : `浏览器验收存在 ${failed.length} 项失败（共 ${results.length} 项）`,
);
if (failed.length) {
  failed.forEach((f) => console.log('  - ' + f.title + ' :: ' + f.detail));
  process.exit(1);
}
